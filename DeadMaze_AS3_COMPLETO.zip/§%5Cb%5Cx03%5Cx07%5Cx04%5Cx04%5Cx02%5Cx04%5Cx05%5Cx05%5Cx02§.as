package
{
   public class §\b\x03\x07\x04\x04\x02\x04\x05\x05\x02§
   {
      
      public static const §\x03\b\x05\b\x04\x05\x03\x03\x06\b\x03\x05§:int = 9998 + -9998;
      
      public static const §\x05\x02\x01\x02\x02\b\x03\x07\x02\x06\x05\x05§:int = 6042 + -6041;
      
      public static const §\x01\b\x01\x06\x03\b\b\x03\x04\x05\x03\x05\x05§:int = 4618 + -4616;
      
      public static const §\b\x06\x06\x05\x02\x07\x06\b\x02\x06\x01§:int = 5380 + -5377;
      
      public static const §\b\x03\x03\x04\x06\x02\x01\x06\x04\x02§:int = 3844 + -3840;
      
      public function §\b\x03\x07\x04\x04\x02\x04\x05\x05\x02§()
      {
         super();
      }
   }
}

