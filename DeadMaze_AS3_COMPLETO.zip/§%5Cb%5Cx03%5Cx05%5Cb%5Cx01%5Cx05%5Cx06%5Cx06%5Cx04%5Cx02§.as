package
{
   import flash.utils.ByteArray;
   
   public class §\b\x03\x05\b\x01\x05\x06\x06\x04\x02§ extends §\x04\x01\x07\x07\x01\x05\x01\x02\x02\x03§
   {
      
      public var §\x03\x07\x02\x06\x06\b\b\x03\x03\x07\x06\b\x03§:int;
      
      public function §\b\x03\x05\b\x01\x05\x06\x06\x04\x02§(param1:ByteArray)
      {
         super(param1);
         this.§\x03\x07\x02\x06\x06\b\b\x03\x03\x07\x06\b\x03§ = param1.readShort();
      }
   }
}

