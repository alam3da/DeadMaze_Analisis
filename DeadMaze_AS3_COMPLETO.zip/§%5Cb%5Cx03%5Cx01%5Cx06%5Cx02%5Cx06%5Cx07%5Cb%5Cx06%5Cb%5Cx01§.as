package
{
   public class §\b\x03\x01\x06\x02\x06\x07\b\x06\b\x01§
   {
      
      public static const §\x05\x03\x01\x05\x05\x04\x01\x02\x03\x04\b§:int = 9220 + -9219;
      
      public function §\b\x03\x01\x06\x02\x06\x07\b\x06\b\x01§()
      {
         super();
      }
   }
}

