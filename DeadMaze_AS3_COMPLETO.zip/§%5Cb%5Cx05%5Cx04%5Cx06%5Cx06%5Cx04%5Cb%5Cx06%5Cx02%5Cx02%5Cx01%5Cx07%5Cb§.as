package
{
   public class §\b\x05\x04\x06\x06\x04\b\x06\x02\x02\x01\x07\b§
   {
      
      public static var §\b\x02\x07\x07\b\x01\x06\x01\x01\x07§:String;
      
      public function §\b\x05\x04\x06\x06\x04\b\x06\x02\x02\x01\x07\b§()
      {
         super();
      }
   }
}

