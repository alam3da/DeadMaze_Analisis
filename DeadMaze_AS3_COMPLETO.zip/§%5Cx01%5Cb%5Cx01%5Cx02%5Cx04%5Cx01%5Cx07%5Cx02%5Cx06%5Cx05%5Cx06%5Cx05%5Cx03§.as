package
{
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   
   public class §\x01\b\x01\x02\x04\x01\x07\x02\x06\x05\x06\x05\x03§ extends §\x04\x01\x07\x07\x01\x05\x01\x02\x02\x03§
   {
      
      public var §\x07\x05\x05\x02\x02\x02\x03\x07\x03\x04\x01§:Vector.<String> = new Vector.<String>();
      
      public var §\x01\b\x07\x01\x04\x06\x01\x06\x06\x05\x02§:Dictionary = new Dictionary();
      
      public function §\x01\b\x01\x02\x04\x01\x07\x02\x06\x05\x06\x05\x03§(param1:ByteArray)
      {
         var _loc4_:String = null;
         var _loc5_:int = 0;
         super(param1);
         var _loc2_:int = int(param1.readUnsignedByte());
         var _loc3_:int = §\b\x07\b\x06\x05\x01\x05\x02\x04\x07§.§\x05\x02\x07\x06\x06\x07\x06\x04\b\x04\x07§(§\x03\b\x01\x07\x07\x01\x07\x07\x04\x01\x02\x02§.§\x05\x03\x07\x07\x05\b\x04\x04\x07\x05\x05\b\x05§);
         while(_loc3_ < _loc2_)
         {
            _loc4_ = param1.readUTF();
            _loc5_ = int(param1.readUnsignedByte());
            this.§\x07\x05\x05\x02\x02\x02\x03\x07\x03\x04\x01§.push(_loc4_);
            this.§\x01\b\x07\x01\x04\x06\x01\x06\x06\x05\x02§[_loc4_] = _loc5_;
            _loc3_++;
         }
      }
   }
}

