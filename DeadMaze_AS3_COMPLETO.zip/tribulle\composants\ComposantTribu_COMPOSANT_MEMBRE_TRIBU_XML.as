package tribulle.composants
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/1_tribulle.composants.ComposantTribu_COMPOSANT_MEMBRE_TRIBU_XML_tribulle.composants.ComposantTribu_COMPOSANT_MEMBRE_TRIBU_XML.bin", mimeType="application/octet-stream")]
   public class ComposantTribu_COMPOSANT_MEMBRE_TRIBU_XML extends ByteArrayAsset
   {
      
      public function ComposantTribu_COMPOSANT_MEMBRE_TRIBU_XML()
      {
         super();
      }
   }
}

