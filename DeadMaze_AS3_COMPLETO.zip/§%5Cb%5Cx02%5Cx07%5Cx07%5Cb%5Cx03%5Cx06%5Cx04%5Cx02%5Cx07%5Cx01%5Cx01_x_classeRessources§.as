package
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/5_§%5Cb%5Cx02%5Cx07%5Cx07%5Cb%5Cx03%5Cx06%5Cx04%5Cx02%5Cx07%5Cx01%5Cx01_x_classeRessources§.bin", mimeType="application/octet-stream")]
   public class §\b\x02\x07\x07\b\x03\x06\x04\x02\x07\x01\x01_x_classeRessources§ extends ByteArrayAsset
   {
      
      public function §\b\x02\x07\x07\b\x03\x06\x04\x02\x07\x01\x01_x_classeRessources§()
      {
         super();
      }
   }
}

