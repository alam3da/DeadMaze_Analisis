package
{
   import flash.utils.ByteArray;
   import lapitchnet.crypto.SHA256;
   import lapitchnet.crypto.SHA256_faux;
   
   public class §\b\x02\b\x07\x05\x07\b\x03\x01\x07\x05\x06\x07§
   {
      
      public static const §\x07\x02\x01\x07\x03\x01\x07\x05\x05\x06\x05§:Vector.<int> = new <int>[-(6361 + -6352),3272 + -3246,-(8460 + -8370),-(187 + -153),-(5330 + -5217),8681 + -8658,8447 + -8329,-(2185 + -2097),201 + -198,-(5668 + -5569),6703 + -6653,-(8581 + -8509),-(9369 + -9274),8777 + -8691,-(4003 + -3925),-(3011 + -2924),2014 + -1952,-(1097 + -1062),7845 + -7778,-(601 + -502),-(9448 + -9389),-(7268 + -7233),-(4946 + -4896),3111 + -3025,-(8312 + -8267),-(9227 + -9154),-(3 + 89),4055 + -4050,5099 + -5025,9789 + -9776,1477 + -1469,-(159 + -79)];
      
      public function §\b\x02\b\x07\x05\x07\b\x03\x01\x07\x05\x06\x07§()
      {
         super();
      }
      
      public static function §\x01\x05\x06\x07\x03\x02\x05\x04\x01\x04\x05\x07§(param1:String) : String
      {
         var _loc2_:String = §\b\x02\b\x07\x05\x07\b\x03\x01\x07\x05\x06\x07§.§\x03\x05\x06\b\x02\x07\x01\b\b\x07§(param1);
         return §\b\x02\b\x07\x05\x07\b\x03\x01\x07\x05\x06\x07§.§\x02\x03\x02\x05\x07\x03\x05\x02\x02\x03\b\x02\b§(_loc2_);
      }
      
      public static function §\x02\x03\x02\x05\x07\x03\x05\x02\x02\x03\b\x02\b§(param1:String) : String
      {
         var _loc3_:int = 0;
         var _loc4_:ByteArray = null;
         var _loc5_:String = null;
         var _loc2_:ByteArray = new ByteArray();
         _loc2_.writeUTFBytes(param1);
         for each(_loc3_ in §\b\x02\b\x07\x05\x07\b\x03\x01\x07\x05\x06\x07§.§\x07\x02\x01\x07\x03\x01\x07\x05\x05\x06\x05§)
         {
            _loc2_.writeByte(_loc3_);
         }
         _loc4_ = new SHA256().x_hash(_loc2_);
         return §\x06\x05\x07\b\x01\x07\x07\x07\x04\x01\x05\x02§.§\x06\x02\x01\x01\x05\x06\x02\x05\x05\x01\x04§(_loc4_);
      }
      
      public static function §\x03\x05\x06\b\x02\x07\x01\b\b\x07§(param1:String) : String
      {
         return SHA256_faux.x_hash(param1);
      }
   }
}

