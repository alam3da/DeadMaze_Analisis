package
{
   public class §\b\x01\x01\x02\x05\x02\x02\x05\x05\x06§
   {
      
      public static var §\b\x02\b\x06\b\x06\x04\x01\x03\x03\x05§:int = 8658 + -8656;
      
      public static var §\x05\x07\x04\x07\b\x01\x03\x01\x06\x05\x05§:int = 1810 + -1809;
      
      public static var §\b\x06\x01\x05\x05\x01\x07\x02\x03\x03\x04\x05§:int = 4759 + -4756;
      
      public function §\b\x01\x01\x02\x05\x02\x02\x05\x05\x06§()
      {
         super();
      }
   }
}

