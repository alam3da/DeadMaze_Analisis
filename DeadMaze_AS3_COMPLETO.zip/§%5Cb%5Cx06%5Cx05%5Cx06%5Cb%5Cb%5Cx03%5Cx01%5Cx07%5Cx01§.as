package
{
   import flash.utils.ByteArray;
   
   public class §\b\x06\x05\x06\b\b\x03\x01\x07\x01§ extends §\b\x03\x02\x02\x05\x05\x03\x07\x01\x04\x01\x05\x02§ implements §\x05\b\x05\x02\x02\x05\x03\x04\x05\x06\x07§
   {
      
      public var idSequence:int;
      
      public var §\x04\x05\x03\x02\x04\b\x01\x01\b\x06\x07§:String;
      
      public var §\x06\b\x02\x06\x01\x02\x03\x06\x06\x04\x07\b\x02§:§\x02\x04\x03\b\x04\b\x03\b\b\x02\x05§;
      
      public function §\b\x06\x05\x06\b\b\x03\x01\x07\x01§(param1:int, param2:String)
      {
         super();
         this.idSequence = param1;
         this.§\x04\x05\x03\x02\x04\b\x01\x01\b\x06\x07§ = param2;
      }
      
      public function getIdSequence() : int
      {
         return this.idSequence;
      }
      
      public function get §\x05\x03\x01\b\x05\x04\x06\x01\x04\x02\b§() : String
      {
         return §\x01\x03\x04\x07\x07\x04\x05\b\x06\x01\x07\x04§.§\b\x01\b\x07\x04\x04\x03\x07\x02\x05\x07\x06\x01§;
      }
      
      public function get typeTaille() : int
      {
         return §\x05\x04\x07\x04\x02\b\x04\x06\x03\x04§.§\x07\x04\x07\b\x02\x02\x01\x02\x07\x07\b\x03\x01§;
      }
      
      public function §\x07\x07\b\x06\x04\x03\x02\x01\b\x07\x07§() : Boolean
      {
         return false;
      }
      
      override public function §\x07\x03\x04\x02\b\x05\x01\x02\x02\x07\x06\x03\x01§() : int
      {
         return §\x04\x01\b\b\x06\x05\x06\x01\x01\b\x04§.§\x06\b\b\x03\x01\x07\x07\x03\x06\x06\x06§ + this.§\x04\x05\x03\x02\x04\b\x01\x01\b\x06\x07§.length;
      }
      
      override public function ecriture(param1:ByteArray) : void
      {
         param1.writeInt(this.idSequence);
         param1.writeUTF(this.§\x04\x05\x03\x02\x04\b\x01\x01\b\x06\x07§);
      }
   }
}

