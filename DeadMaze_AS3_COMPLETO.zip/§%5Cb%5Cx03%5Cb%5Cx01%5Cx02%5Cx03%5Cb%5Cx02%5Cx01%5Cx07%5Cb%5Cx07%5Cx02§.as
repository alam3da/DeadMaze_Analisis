package
{
   import flash.utils.ByteArray;
   
   public class §\b\x03\b\x01\x02\x03\b\x02\x01\x07\b\x07\x02§ extends §\x04\x01\x07\x07\x01\x05\x01\x02\x02\x03§
   {
      
      public var §\b\x05\x06\x07\x06\x02\x05\x03\x04\x06\x07\b\x04§:int;
      
      public var §\x04\x01\x05\x06\x07\x06\b\x02\x06\x02\x03§:Array;
      
      public function §\b\x03\b\x01\x02\x03\b\x02\x01\x07\b\x07\x02§(param1:ByteArray)
      {
         var _loc3_:int = 0;
         var _loc4_:int = 0;
         var _loc5_:int = 0;
         var _loc6_:Array = null;
         var _loc7_:int = 0;
         super(param1);
         this.§\x04\x01\x05\x06\x07\x06\b\x02\x06\x02\x03§ = new Array();
         this.§\b\x05\x06\x07\x06\x02\x05\x03\x04\x06\x07\b\x04§ = param1.readShort();
         var _loc2_:int = §\x03\b\x01\x07\x07\x01\x07\x07\x04\x01\x02\x02§.§\x05\x03\x07\x07\x05\b\x04\x04\x07\x05\x05\b\x05§;
         while(_loc2_ < this.§\b\x05\x06\x07\x06\x02\x05\x03\x04\x06\x07\b\x04§)
         {
            _loc3_ = param1.readInt();
            _loc4_ = param1.readInt();
            _loc5_ = param1.readByte();
            _loc6_ = new Array();
            _loc7_ = §\b\x07\b\x06\x05\x01\x05\x02\x04\x07§.§\x05\x02\x07\x06\x06\x07\x06\x04\b\x04\x07§(§\x03\b\x01\x07\x07\x01\x07\x07\x04\x01\x02\x02§.§\x05\x03\x07\x07\x05\b\x04\x04\x07\x05\x05\b\x05§);
            while(_loc7_ < _loc5_)
            {
               _loc6_.push(param1.readUTF());
               _loc7_++;
            }
            this.§\x04\x01\x05\x06\x07\x06\b\x02\x06\x02\x03§.push(new §\x07\x02\x07\x03\b\x07\x02\x01\x03\x03\b\x05§(_loc3_,_loc4_,_loc6_));
            _loc2_++;
         }
      }
   }
}

