package
{
   import mx.core.FontAsset;
   
   [Embed(source="/_assets/9_§%5Cb%5Cx02%5Cx07%5Cx07%5Cb%5Cx03%5Cx06%5Cx04%5Cx02%5Cx07%5Cx01%5Cx01_%5Cx07%5Cx03%5Cx04%5Cx02%5Cx04%5Cx03%5Cx05%5Cx01%5Cx03%5Cx07%5Cx06%5Cx05§_police_chiffre.ttf",
   fontName="police_chiffre",
   fontFamily="04b_19",
   mimeType="application/x-font",
   fontWeight="normal",
   fontStyle="normal",
   unicodeRange="U+0020-0021,U+002A-007A",
   advancedAntiAliasing="false",
   embedAsCFF="false"
   )]
   public class §\b\x02\x07\x07\b\x03\x06\x04\x02\x07\x01\x01_\x07\x03\x04\x02\x04\x03\x05\x01\x03\x07\x06\x05§ extends FontAsset
   {
      
      public function §\b\x02\x07\x07\b\x03\x06\x04\x02\x07\x01\x01_\x07\x03\x04\x02\x04\x03\x05\x01\x03\x07\x06\x05§()
      {
         super();
      }
   }
}

