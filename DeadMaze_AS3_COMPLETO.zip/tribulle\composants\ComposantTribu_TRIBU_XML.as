package tribulle.composants
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/2_tribulle.composants.ComposantTribu_TRIBU_XML_tribulle.composants.ComposantTribu_TRIBU_XML.bin", mimeType="application/octet-stream")]
   public class ComposantTribu_TRIBU_XML extends ByteArrayAsset
   {
      
      public function ComposantTribu_TRIBU_XML()
      {
         super();
      }
   }
}

