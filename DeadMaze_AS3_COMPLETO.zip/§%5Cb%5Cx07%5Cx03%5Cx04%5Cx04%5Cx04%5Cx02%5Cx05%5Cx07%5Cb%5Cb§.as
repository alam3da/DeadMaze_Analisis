package
{
   import flash.utils.ByteArray;
   
   public class §\b\x07\x03\x04\x04\x04\x02\x05\x07\b\b§
   {
      
      public var §\x03\b\x03\x01\b\x01\x01\x05\x03\x04\x03§:String;
      
      public var §\x06\x04\x07\x04\x02\x04\x04\x04\x07\x04\x04\x02\x06§:String;
      
      public function §\b\x07\x03\x04\x04\x04\x02\x05\x07\b\b§(param1:String, param2:String)
      {
         super();
         this.§\x03\b\x03\x01\b\x01\x01\x05\x03\x04\x03§ = param1;
         this.§\x06\x04\x07\x04\x02\x04\x04\x04\x07\x04\x04\x02\x06§ = param2;
      }
      
      public static function §\x03\x04\x07\x06\b\x01\x03\x06\x02\x05\x01\x05\x06§(param1:ByteArray) : §\b\x07\x03\x04\x04\x04\x02\x05\x07\b\b§
      {
         var _loc2_:String = param1.readUTF();
         var _loc3_:String = param1.readUTF();
         return new §\b\x07\x03\x04\x04\x04\x02\x05\x07\b\b§(_loc2_,_loc3_);
      }
   }
}

