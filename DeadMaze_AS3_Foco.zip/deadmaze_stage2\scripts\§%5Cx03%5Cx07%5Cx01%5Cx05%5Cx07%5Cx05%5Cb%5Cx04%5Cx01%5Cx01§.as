package
{
   public class §\x03\x07\x01\x05\x07\x05\b\x04\x01\x01§
   {
      
      public static var §\x01\x01\x03\x06\x01\x02\x06\x03\b\x05\b\x06\b§:String = "ajout objet : 5_1";
      
      public static var §\x07\x02\x04\x01\x05\x05\x01\x05\x07\x04\x03\x01\x06§:String = "0.2";
      
      public static var §\x07\x01\x01\x02\x05\x01\x03\x04\x07\x02\b\x03\x05§:String = "$Fenetretag";
      
      public static var §\x02\x02\x02\x03\b\x05\x07\x05\x02\b\x03\x06§:int = 7018 + -4514;
      
      public static var §\x06\x05\x01\x02\x04\x02\x06\x04\x04\x04\b\x05§:String = "<ROSE>Atelier 801";
      
      public static var §\x01\x01\x07\x07\x05\x04\x07\x03\x02\x07\x07\x04\x06§:String = "$Election";
      
      public static var §\x02\b\x03\x01\x02\b\x03\b\x06\b\x01\x05\x06§:String = "https://store.steampowered.com/app/1040240/Transformice_Adventures/";
      
      public static var §\x04\x04\x04\x01\x03\x06\x04\b\x06\x04\x01\x02\b§:String = "x_tfma_";
      
      public static var §\x03\x07\x03\b\x01\x03\x06\x07\x02\x06\x06\x03\x02§:String = "x_transformice/x_interface/croix.png";
      
      public static var §\x06\b\x06\x02\x01\x03\x07\x07\b\b\x04\b§:Number = (5947 + -5902) / (2747 + -2737);
      
      public static var §\x05\x01\x07\b\x04\x04\x03\x06\b\x03\x06\x07§:String = "$Craie";
      
      public static var §\x06\x07\b\x06\x06\x07\x05\x06\x06\x01\x04\x01§:Number = (358 + -171) / (5005 + -4905);
      
      public static var §\x05\x01\x03\x07\b\x02\x03\b\x02\x02\x04\x07\x04§:String = "x_transformice/x_evt/x_evt_19/svtrixcv/bateau.png";
      
      public static var §\x04\x06\x05\x07\x04\b\x07\x06\x06\x06\x02\x07\x05§:String = "magique_fleur.png";
      
      public static var §\x02\x05\x02\x06\x07\x03\x03\x05\x05\x04\x04\b\x02§:int = 3059 + -741;
      
      public static var §\b\x06\x06\x04\x04\x07\b\x04\x04\b\x01\x04§:int = 2801 + -2226;
      
      public static var §\x04\x07\x01\b\x07\x01\x07\x04\x05\x04\x03§:String = "% : ";
      
      public static var §\x01\x07\x03\x01\x07\x06\x05\x05\x01\x05\b§:String = "$Sauvegarder";
      
      public static var §\x02\x03\x01\x03\x03\x07\b\x03\b\x05\x02§:String = "^stop|off$";
      
      public static var §\x07\x06\x06\x02\x05\b\x04\x06\x07\b\x04\x05§:String = "couleurs";
      
      public static var §\x02\x03\b\x06\x01\b\x03\b\x01\x01\x07§:int = 3475 + -1265;
      
      public static var §\b\b\x04\x04\x05\b\x05\b\b\x01\x03\x02\x06§:String = "$competence/astrophysicienne";
      
      public static var §\x01\x02\x03\x02\x06\b\x04\x02\x06\x02\b§:String = "$Valider_Et_Payer_Fromage";
      
      public static var §\x04\x02\b\x04\x04\x02\x02\x02\x06\x06\x07\x03\x07§:String = "<font color=\'#27db97\'>&gt; ";
      
      public static var §\x05\b\x02\x05\x04\b\x06\b\x07\x02\x06\x05§:String = "<font color=\'#009D9D\'>";
      
      public static var §\x03\x05\x07\x06\x07\x07\x07\x06\x01\x05\x07\x03\x01§:String = "M_Fraise.png";
      
      public static var §\x03\x02\x02\x04\x07\x07\x02\x02\x03\x01\x02\x05\x02§:String = "badges";
      
      public static var §\b\x02\x01\x02\b\x07\x03\x04\x03\x02\x05\x02§:String = "$iconeFantome";
      
      public static var §\b\x06\x06\x07\x01\b\x07\x03\x02\x07\x07\x06\x07§:String = "$Badge_";
      
      public static var §\x02\x06\x06\x07\b\x07\x04\x03\x06\x07\x01§:String = " : <J>";
      
      public static var §\x07\x06\x02\x01\x06\x02\b\x01\b\x05\x05\x03§:String = "x_transformice/x_interface/coffres/x_rarete_";
      
      public static var §\b\x06\x07\x06\x07\x06\b\x04\x04\b\x07\x03§:String = "x_i_80.png";
      
      public static var §\x06\x03\x07\x05\x03\x04\b\x05\b\x03\b\x06\x02§:String = "x_i_68.png";
      
      public static var §\x06\b\x05\x02\x07\x04\x03\x02\x05\x02\x02§:String = "x_i_43.png";
      
      public static var §\x02\b\x04\x05\x07\x04\b\x06\b\x04\b§:String = "x_i_27.png";
      
      public static var §\x06\x07\x06\x07\x01\x05\b\x06\x04\x01\x04\x04§:String = ":<N> ";
      
      public static var §\x06\x03\x04\x06\x05\x07\b\b\x07\x07\x02§:String = "DernierSaut";
      
      public static var §\x05\x02\x03\x01\x07\x07\x05\x07\x07\x06\x01\b\x03§:String = "$Tutorial_2";
      
      public static var §\x02\x01\x04\x02\b\x02\x01\x07\x01\x02\x07\x04\x03§:String = "$Tutorial_0";
      
      public static var §\b\x02\x06\x01\x01\x01\x07\b\x03\x02\x02\x05§:String = "CAD";
      
      public static var §\x05\x05\x04\x01\x07\x05\x02\x07\x02\x01\x06\x03\x07§:String = "TS";
      
      public static var §\b\x02\x02\x03\x05\x02\x06\x04\x04\x02\x03\x01§:String = "loop";
      
      public static var §\x04\x02\x05\x07\x04\b\x06\x01\x04\x04\x02\x01§:String = "$Echec_Tour";
      
      public static var §\x06\x02\x03\x04\x06\x03\x01\x05\x01\x04\x04\x06§:int = 4487 + -4096;
      
      public static var §\x07\b\x03\x01\x06\x07\x06\x07\b\x07\x06\x02§:String = "effetSelectionEditeur";
      
      public static var §\x05\x05\x01\x06\x01\x03\b\x04\x03\b\x02§:String = "reporterJoueur";
      
      public static var §\x05\x05\b\x02\x04\b\x07\b\x06\x04\b\x01§:String = "pasAA";
      
      public static var §\x06\x04\x04\x02\x05\x03\b\x04\x04\x05\x04\x01\x05§:String = "cliqueFullscreen";
      
      public static var §\x02\b\x03\x05\x04\x01\x07\x04\x05\x04\x02\b\x03§:Number = (1079 + -944) / (9879 + -9779);
      
      public static var §\x07\x03\x02\x02\b\x06\x04\x07\x03\x02\x03\x07§:String = "$RecupMDPEntrerInfos";
      
      public static var §\b\b\x03\x02\x05\x03\x02\x02\x03\x01\x06§:String = "couleur";
      
      public static var §\x01\x05\x02\b\x01\x02\x03\x02\x06\x04\b\x03\x04§:String = ".....";
      
      public static var §\x01\x02\x05\x01\x05\b\b\x07\x06\x05\b\x02\x01§:String = " --&gt; ";
      
      public static var §\x05\x07\x06\x07\x02\x07\b\x05\x06\x07\x04\x04\x01§:int = 4304 + -3905;
      
      public static var §\x04\x01\x01\x06\x03\x03\x04\x05\x03\x01\x07\x04\x07§:int = 663 + -430;
      
      public static var §\x06\x07\x05\b\b\x07\x05\x07\x04\x05\x02\x05§:String = "$J";
      
      public static var §\x06\x07\x01\x02\x07\x03\x03\x02\x04\x05\x03\x04\x03§:String = "<FC>• [Funcorp] MESSAGE</FC>";
      
      public static var §\x05\x06\x01\x02\x06\b\x01\x01\x05\x02\x07\x05\x04§:String = "<font color=\'#12DA8A\'>• [JOUEUR] <b>MESSAGE</b></font>";
      
      public static var §\x05\x06\x07\x04\x07\x03\x07\x01\x06\b\x03§:String = "réelle";
      
      public static var §\x06\x07\x05\x01\b\x05\x06\x07\x02\x01\x06§:String = "combat/feu";
      
      public static var §\x07\x01\x06\x02\x01\x01\x04\b\x06\x03\x02\x04\b§:String = "$FX_9";
      
      public static var §\x01\x05\x02\x01\x05\x01\x03\x04\x03\x02\x02§:String = "$FX_36";
      
      public static var §\x05\x07\b\x02\x07\x04\b\x06\b\x05\x03§:Number = (8578 + -8245) / (6233 + -5233);
      
      public static var §\x04\x03\b\x02\x07\x06\x06\x07\b\x07\x03\x06\x05§:String = "combat/gel";
      
      public static var §\x04\x02\x06\x01\x05\x04\x04\x03\x07\x03\x03§:String = "_mort";
      
      public static var §\x05\x05\x06\b\x03\x05\x06\x01\x01\x03\b\x02§:String = "$AnimAttaqueMN_F_1";
      
      public static var §\b\x04\b\x03\x03\b\x01\x04\x07\x06\x05\x01§:String = "$AnimAttaqueMN_H_1";
      
      public static var §\x06\x07\x06\x01\x02\x04\x06\b\x02\x01\b\b\x02§:String = "$AnimAttaque_F_3";
      
      public static var §\x01\x01\x03\x03\x02\b\x02\x06\b\x07\x05§:String = "marche/pas";
      
      public static var §\x05\x05\b\x06\x01\x04\x02\x05\x07\x02\x02\x01§:String = "$AnimPistolet";
      
      public static var §\b\b\x03\x03\x03\x05\x02\x02\x02\x06\x03\x01\x03§:String = "comp_3";
      
      public static var §\x04\x04\x04\x01\x01\b\b\x07\x05\x04\x05\b§:int = 1834 + -539;
      
      public static var §\x04\x01\x07\x02\x04\x02\x07\x03\x03\x01\b\x05§:String = "$NouvelleRecette";
      
      public static var §\x03\x04\x04\b\x03\x01\b\x07\x04\x05\x06\b\x04§:String = "cel_sol";
      
      public static var §\x01\b\x06\x05\x07\x02\x03\x02\x04\x03\x02§:Number = (3767 + 170766) / (5572 + 9994428);
      
      public static var §\x05\x02\b\x07\x03\x06\x02\x06\x03\x04\x03§:int = 576 + -113;
      
      public static var §\b\x02\x02\x01\x04\x04\x04\x01\x06\x06\x05\x07§:String = ".map";
      
      public static var §\x01\x03\x05\x05\x06\b\x07\x06\x07\x05\x02§:String = "$AucunProjetRecherche";
      
      public static var §\x02\x06\x01\x06\x01\x07\x01\x05\x07\b\x05§:String = "objet ";
      
      public static var §\b\x02\x06\x04\b\x06\x07\x07\x04\x03\x06§:String = "$AmeliorationCampement";
      
      public static var §\x05\x07\x04\x07\x02\x07\x07\x02\x06\b\x03\b\x07§:String = "posture_after_end";
      
      public static var §\b\b\x07\x01\x02\x01\x07\x07\x04\x01\x02\b\x06§:String = "<O>move down";
      
      public static var §\x06\x07\x06\x07\x07\x04\x02\x07\x02\x06\x02§:String = "<O>new event";
      
      public static var §\x06\x03\x04\x07\b\x06\x02\x03\x04\x02\x04\x05\b§:String = "disable";
      
      public static var §\x02\x07\x06\b\x01\x01\x03\x07\x03\x07\x05\x03\x02§:String = "target_cell";
      
      public static var §\x01\x02\x05\x07\x04\x06\x02\x03\x05\x01\x05\b\b§:String = "$Revendiquer";
      
      public static var §\x04\x05\b\x04\x02\x04\x01\x02\x06\x02\x01\b\x03§:String = "x_deadmeat/x_interfaces/divers/recompenses.png";
      
      public static var §\x01\x01\x06\x04\x06\x04\x02\x07\b\x05\x01\x04§:String = "x_deadmeat/x_interfaces/divers/discord.png";
      
      public static var §\x05\x06\x05\x03\x02\x02\x07\b\x07\x02\x05\x06\x04§:String = "x_deadmeat/x_interfaces/divers/options.png";
      
      public static var §\x04\x02\x06\x01\x05\x01\x01\x07\x02\x06\x04\x04§:String = "$Option_16";
      
      public static var §\x04\x07\x02\x05\b\x07\x06\b\b\x05\b\x02§:String = "140 %";
      
      public static var §\x05\x07\x05\x06\x07\x02\x06\x06\x02\x07\x03\x05§:String = "Neige";
      
      public static var §\x03\x07\x07\x05\x01\x07\x05\x04\x06\x04\x05\x03\x03§:String = "Aucun effet météo";
      
      public static var §\x02\x01\x03\x01\x04\x07\x06\b\x02\x02\x05\x02§:String = "x_deadmeat/x_interfaces/totems/";
      
      public static var §\x02\x04\x05\x02\x06\x04\x01\x06\b\x06\x04\b\x01§:String = "#JOSH_NOLAN: Here’s some water for you babe.";
      
      public static var §\x04\x07\x07\x03\x06\x04\x05\x04\x05\x01\x03\b\b§:String = "$Cinematique_";
      
      public static var §\x06\x02\x07\x06\b\x04\x01\x04\b\x01\b\x03§:int = 5611 + -4841;
      
      public static var §\x02\x05\b\b\x04\x07\x02\x01\x06\x07\x01§:String = "x_deadmeat/x_campement/repos_ap.png";
      
      public static var §\x02\x01\x05\x05\x06\x06\x06\x02\x01\x03\x07\b\x04§:String = "\\[IMG,(\\d+),(\\d+),(\\d+)\\]\\s*";
      
      public static var §\x06\x06\x02\x05\x07\b\x06\x02\b\x06\x04§:String = "</i></font>";
      
      public static var §\b\x04\x02\x04\x01\x02\x07\x01\x06\x05\x04\x07§:String = "x_deadmeat/x_interfaces/coffres/coffre-ferme.png";
      
      public static var §\x03\x05\b\x06\x06\x06\x01\b\x06\x01\x04§:String = "x_deadmeat/x_interfaces/principale/barre_menace.png";
      
      public static var §\x03\x05\x07\x06\x07\x04\x05\x07\b\x07\x03§:String = "$VitesseAttaqueRapide";
      
      public static var §\x04\b\b\b\b\x01\x04\x04\x05\x03\x07\x04§:String = "x_deadmeat/x_interfaces/principale/selection.png";
      
      public static var §\x04\x04\x02\x07\x03\x03\x04\x07\x07\x03\x06\x01§:String = "x_deadmeat/x_interfaces/monde/zones/";
      
      public static var §\x01\x03\x02\x06\x05\x01\x06\x03\x03\x06\x06\x01\x06§:String = "<font size=\'20\'>";
      
      public static var §\x05\x05\x06\b\x03\x06\x04\x06\x06\x03\x04\x06§:String = "x_deadmeat/x_zone/";
      
      public static var §\x02\x04\x07\x02\x04\x07\x07\x07\x06\x06\x01§:int = 8427 + -7877;
      
      public static var §\x02\x07\x04\x04\x02\b\b\x05\x04\x04\x04\x04\x05§:String = "x_deadmeat/x_interfaces/divers/goutte.png";
      
      public static var §\x06\x04\x01\x05\x03\b\x05\x03\x01\x01\x05\x04\x04§:String = "ips=";
      
      public static var §\x07\x03\x07\x05\x01\x04\x07\x04\x05\x06\x05\x01§:String = "$zone_nommee.";
      
      public static var §\x03\x03\x06\x01\b\x02\x04\x05\x02\x03\b\x03§:String = " > ";
      
      public static var §\x07\x02\x02\x04\x06\x06\x04\x03\b\x02\x07§:String = "align";
      
      public static var §\x06\x01\x04\x06\x07\b\x05\x07\x07\x05\x06\x05\b§:String = "alwaysInFront";
      
      public static var §\x05\x02\x07\x07\x04\x01\x02\x05\x02\x01\x02\x07\x06§:String = "x_deadmeat/editeur/outils/";
      
      public static var §\x03\x02\b\x03\x06\x03\x01\x05\b\b\x03\x04§:String = "difficulte";
      
      public static var §\b\x06\x07\x02\b\x06\x07\x04\x01\x07\x07\b§:String = "Required item";
      
      public static var §\x05\b\x06\x05\b\x07\x06\b\x07\x07\x01§:String = "$EditeurTitreEntreesTraductions";
      
      public static var §\x07\x03\x07\x01\x07\b\x03\b\x05\x03\b\x07\x03§:String = "✓";
      
      public static var §\x05\x07\b\x02\x03\x07\x03\x03\x04\x03\x05\x02\x01§:String = "$langue.italien";
      
      public static var §\x04\b\x02\x03\x02\x07\x02\x01\x06\b\x04\x04\x06§:String = "$langue.francais";
      
      public static var §\x01\x01\x02\x06\x01\x07\x03\x04\x02\x03\x06\x01\x01§:String = "point_accroche_x";
      
      public static var §\b\x05\x06\x03\x04\x03\x03\x01\x04\x04\x05\x03§:String = "g_";
      
      public static var §\x04\x04\x05\x06\b\x07\b\x03\x05\x01\x07§:String = "Rendu monde";
      
      public static var §\x01\x05\x05\b\b\x04\x03\b\x04\x03\x07\x04\x06§:String = "$CadrillageInterieur2";
      
      public static var §\x03\x04\x06\x07\x04\x04\b\x02\x02\b\x01\x01\x03§:String = "$CadrillageInterieur";
      
      public static var §\x03\x01\x01\x03\x02\x02\x05\x04\x02\x01\b\b§:String = "Chaussures_01.swf";
      
      public static var §\x06\x05\x04\b\x02\x02\x04\x04\x04\x06\x05\x07§:String = "$FX_34";
      
      public static var §\x04\x04\x07\x06\x05\x05\x04\b\x04\x05\x02\x01§:String = "sons/";
      
      public static var §\x02\x07\x02\x04\x04\x06\x06\x04\x06\x06\x06\x07\b§:String = "etourdissement";
      
      public static var §\b\x02\x05\x04\x06\x04\x02\x03\x02\x06\x02\x02§:String = "\n<font size=\'11\'>";
      
      public static var §\x05\b\x04\x02\x02\x06\x01\b\x07\x04\x04\x02\x01§:String = "$haut_fait.";
      
      public static var §\x06\x03\x04\x02\x05\x03\x05\x01\x02\x07\x05\x06§:String = "$batiment.";
      
      public static var §\x06\x02\b\x02\x05\x07\x02\x01\x06\x04\x05§:String = "] introuvable.";
      
      public static var §\b\x02\x05\x01\x06\x02\x04\x02\x01\x07\x07\x02§:Number = (5174 + 11492) / (1648 + 98352);
      
      public static var §\x07\x06\x05\x05\x04\x02\x01\x01\x04\x06\x05\x02§:String = "ClipGrosse";
      
      public static var §\x07\b\x02\x06\x02\x01\x01\x03\x07\x07\x05\x03\b§:String = "AnimInvoc";
      
      public static var §\x03\x07\x02\x03\x01\x03\x03\x03\x04\x06\x02§:String = "AnimRondoudou";
      
      public static var §\x04\x06\x05\x07\x02\x02\b\x02\x06\x05\x07\x02\x03§:String = "<N> / <R>";
      
      public static var §\b\b\x04\x03\x02\x06\x04\x05\x01\x05\x04\x04§:String = "$Message_Ban";
      
      public static var §\x07\x04\x02\x03\x06\x05\x01\x05\x03\x05\x03§:String = "<font color=\'#C565FE\'>• ";
      
      public static var §\x02\x04\b\x05\x05\x01\x06\x04\x03\b\x04\x06\x05§:String = "$PasCarteMaison";
      
      public static var §\x01\b\x01\x05\x04\x02\x02\x04\x07\x06\x06\x04\x05§:String = "$E_ErreurChargement";
      
      public static var §\x02\x02\x05\x02\b\x02\x01\x05\x03\x05\x07\x02§:String = "$Connexion_Ami";
      
      public static var §\x04\x03\x02\x05\x03\b\x05\x05\b\x01\x01§:String = "$Info_Fromage_Chamane";
      
      public static var §\x06\x01\x02\x04\b\b\x02\x04\x06\x05\b\x05§:String = "<font color=\'#CB546B\' />DECONNEXION !</font>";
      
      public static var §\x04\b\x06\x06\x05\x03\x02\b\b\x05\x01\x02\x02§:String = ") [Monde:";
      
      public static var §\x02\x05\x06\x07\x07\b\x06\x07\x03\b\x03§:String = "tigrou";
      
      public static var §\x06\x03\b\x02\b\x02\x06\x05\b\x03\x03\x02§:String = "x_commandes";
      
      public static var §\x04\x06\x01\x06\x03\x01\x03\x06\x06\x03\x03\b§:String = "Id de paquet inexistant : ";
      
      public static var §\x07\x05\x05\b\x06\x03\x03\x01\x06\x02\x04\x03\x07§:String = " }";
      
      public static var §\x02\x02\x05\x05\b\b\x05\x01\x05\x04\x05\x01\b§:String = "$chat.message.compteTropRecentPourChuchotement";
      
      public static var §\x07\x03\x05\x04\x04\b\x02\x06\x05\x02\x02\b§:String = "$chat.message.antiFlood";
      
      public static var §\x04\x07\b\x01\x07\x07\x06\x07\x01\x06\x05\x02\x05§:int = 3410 + -2670;
      
      public static var §\x05\b\x05\x03\x06\x06\x05\x05\x02\x07\x05\x04\b§:String = "_T";
      
      public static var §\x04\x05\b\b\b\x07\x06\x03\x06\x05\b\b\x06§:String = "Youtube.init";
      
      public static var §\x01\x06\x02\x05\x04\b\x03\x03\b\x05\x02\x05§:String = "Suomi";
      
      public static var §\x04\x07\x03\x04\x02\x07\x01\x03\x07\x01\x05\x06§:String = "http://audio.atelier801.com/transformice/";
      
      public static var §\x04\x03\x02\x02\x05\x03\b\x04\x01\x01\x02\x03\b§:String = "<a href=\'event:x_mj;";
      
      public static var §\x02\x04\x02\x04\x01\x06\b\x02\x07\x06\x06\x06\x07§:String = "\' ";
      
      public static var §\x01\x03\x03\x04\b\x06\b\b\x01\b\x07§:String = "^([^[]+)\\(\\)\\[.*\\]$";
      
      public static var §\x03\x02\x06\b\x06\x02\b\x01\x05\x04\x01\x01§:String = "defActiviteDiscord";
      
      public static var §\x03\b\x05\x02\x06\b\x02\x02\x06\b\x05\b\x03§:String = "chargeur-electron";
      
      public static var §\x05\x02\x03\x03\x02\x02\x06\x07\x03\x01\x04§:String = "silent";
      
      public static var §\x05\x05\x06\b\x07\b\x01\x07\x04\x02\x04\x03\x01§:String = "http://avatars.atelier801.com/image-module";
      
      public static var §\x06\x02\x05\x02\b\x03\x07\x05\x03\x02\x04\x06§:String = "$Commentaire";
      
      public static var §\x02\x05\x06\x03\x03\x07\x05\x05\b\x04\x07\x02\b§:String = "$interface.amis.bouton.listeNoire";
      
      public static var §\x05\x05\x03\b\x04\x06\x06\x03\x02\x04\x07\x01\x03§:String = "$popup.amis.resultatDemandeEnMariage.titre";
      
      public static var §\x01\x03\x01\b\x03\x06\x03\x07\x03\x04\x04\x05§:String = "&~";
      
      public static var §\x07\x01\x02\b\b\x05\x06\b\b\x01\x05\x07§:String = "lm";
      
      public static var §\x06\x01\x07\x06\x06\b\b\b\x01\x06\x01\x03\b§:String = "\'><VP>";
      
      public static var §\x01\x02\x04\x02\x07\x03\x07\x04\x07\b\x04\x05\x07§:String = "0,-1,4,9,5,0,-1,8,6,7,66";
      
      public static var §\x04\x07\x06\x04\x04\x02\b\x06\x07\x05\x01\x03\x03§:int = 8382 + 127635778491;
      
      public static var §\x03\x07\x01\x03\x03\x04\x07\x02\x06\x04\x01\x04§:String = "int";
      
      public static var §\x07\x06\b\x06\x01\x04\x04\x01\x06\x04\x05§:String = "<font color=\'#5BA783\'>• ";
      
      public static var §\x04\b\x05\x06\x05\x06\b\x05\b\x03\x04\x07§:String = "$Chat_Fermer";
      
      public static var §\x01\x06\b\b\x02\x03\x07\x04\x01\x03\x06\x04§:String = "$Chat_Bas2";
      
      public static var §\x03\x07\x05\x05\x07\x05\x03\x04\x04\x04\x07\b§:String = "<BL>@";
      
      public static var §\x01\x07\b\x07\x04\b\x06\x03\x01\x05\x07\x02\x04§:String = "chat";
      
      public static var §\x07\x03\b\x02\x04\x04\x05\x07\x01\x03\x06\x02\x02§:String = "_editeur";
      
      public static var §\x01\x06\x05\x07\x03\x01\x01\x03\x02\x02\x07§:String = "$bouton.connexion";
      
      public static var §\x07\x07\x04\x04\x01\x03\x03\x04\x02\x02\x04§:String = "$authentification.erreur.1";
      
      public static var §\x04\x05\x01\x02\x04\x04\b\x06\x05\x02\x02\x04§:String = "$Facebook";
      
      public static var §\x06\x03\x03\x01\x07\x05\x06\x05\x03\x06\x01\x06\x02§:String = "$TelechargerJeu";
      
      public static var §\x01\x01\x04\x02\x05\x02\x06\b\x04\x04\x01§:String = "divers/twitch-noisette.png";
      
      public static var §\x06\x06\x03\x07\x02\x04\b\x05\x04\b\x07§:String = "https://www.transformice.com/divers/rules_of_conduct.html";
      
      public static var §\x07\x06\x07\x06\x04\x04\x02\x05\x02\x01\x05\x07§:int = 7328 + -6923;
      
      public static var §\x02\x01\x01\x01\x05\x02\x02\x07\b\x02\x07§:String = "$Magasin";
      
      public static var §\x02\x01\x06\x03\x07\b\x05\b\x01\x02\x06\x06§:String = "<G>(passworded)</G>";
      
      public static var §\x03\x07\x06\x01\x04\x07\x03\x01\x06\x06\x06\x04\x05§:String = "watch";
      
      public static var §\x06\x03\x01\x05\x07\x03\b\b\b\x05\b\x03\x02§:String = "(Deleted by ";
      
      public static var §\x05\x05\x06\x03\x06\x03\x05\x03\x03\x06\x04\b\x06§:String = "(Banned for ";
      
      public static var §\x07\x03\x04\x06\x03\x04\x04\x02\x06\x01\x07\x02\x06§:String = "</N2>";
      
      public static var §\b\x03\x07\x05\x03\x06\x01\x04\x07\x07\b\b\x06§:String = "$ModeJeu_Vanilla";
      
      public static var §\x06\b\x03\x03\x05\x02\x05\x07\x04\x05\x07\x01\x06§:String = "Son introuvable : ";
      
      public static var §\x02\x05\x06\x05\x05\x03\x03\x03\x01\x07\x02\x05§:String = "$Menu_2";
      
      public static var §\x03\b\x06\x04\x07\x04\x03\x07\x07\x05\x06§:String = "<li>$1</li>";
      
      public static var §\b\x04\x07\x01\x04\x02\b\x06\x02\x03\x07\x05\x07§:String = "\\*(.*?)\\*";
      
      public static var §\x03\x07\x02\x03\x01\x06\x07\x02\x07\x05\x05\x04§:int = 1991 + -1737;
      
      public static var §\x02\x04\x04\x02\x01\x03\x06\b\x02\x05\x07\x05§:Number = (5222 + 66947) / (9397 + 990603);
      
      public static var §\x01\x06\b\x04\x03\x01\x07\x01\x01\b\x04\x05\b§:String = "Key ";
      
      public static var §\x04\x02\b\x03\b\x03\x02\x06\x07\x04\x05\x05\x02§:String = "Numpad 4";
      
      public static var §\x01\x03\x05\x02\x05\x01\x05\x03\x01\x01\x04\x05§:String = "3";
      
      public static var §\b\x05\x01\x01\b\x02\x03\x07\x04\x07\x05§:String = "Numpad Multiply";
      
      public static var §\x05\b\x01\x04\x07\x07\x04\x06\x02\x03\x05\x04\b§:String = "Escape";
      
      public static var §\x05\b\x03\x04\x02\x03\x03\x01\x05\x07\b§:String = "stats";
      
      public static var §\x01\x07\x04\x07\x01\x01\x01\x06\x07\x04\x02§:String = "connect";
      
      public static var §\x04\x07\x02\x03\x07\x04\x07\x05\x01\x04\x01§:String = "&bg=";
      
      public static var §\x01\x02\x03\x05\x02\x06\x01\x02\b\x06\x07\x06\x07§:int = 5681 + -4829;
      
      public static var §\x01\b\x02\x02\x03\x01\b\x07\x02\b\x01§:int = 7449 + -7243;
      
      public static var §\x02\x05\x03\x05\x03\x02\b\x02\x02\x03\b\x05§:int = 6215 + -6074;
      
      public static var §\x07\b\x07\x04\x01\x07\x02\x01\b\x06\x01§:int = 9902 + -9772;
      
      public static var §\x05\x07\x05\x07\x06\x02\x02\x02\x06\x05\x07\b§:int = 4965 + -4837;
      
      public static var §\x07\x03\x02\x07\x05\x05\x02\b\x03\x06\b\x07\x07§:int = 8335 + -8236;
      
      public static var §\x04\b\x07\x04\x01\x03\x06\x05\x05\x05\x06§:int = 4098 + -4001;
      
      public static var §\x03\x06\x07\x03\b\b\x04\b\x01\x06\x04§:int = 5340 + -5281;
      
      public static var §\x06\x04\x04\x03\x05\x01\x05\x03\x02\x05\x02§:int = 4487 + 395513;
      
      public static var §\x05\x05\x06\x07\x07\x03\x02\x01\x07\x03\x02\x03§:int = 9093 + -8758;
      
      public static var §\x05\x04\x06\x05\x03\x04\x07\x06\b\x05\x03\x01§:int = 3105 + -2730;
      
      public static var §\x03\x07\b\x03\x07\x02\x03\x01\x03\x02\x04\x07§:int = 4159 + -4043;
      
      public static var §\x03\x01\x06\x05\b\b\x04\x01\x04\x05\x04\x03\x06§:String = "mou";
      
      public static var §\x03\x07\x05\x01\x07\x03\x05\x07\x04\b\b\x04§:String = "_peche";
      
      public static var §\x06\b\x01\x05\b\x02\x05\x01\x07\x03\x03§:String = "x_transformice/x_interface/paiements/boleto.jpg";
      
      public static var §\x01\x04\x05\x04\x06\x02\x01\x06\x07\b\b\x06\x03§:String = "success";
      
      public static var §\x01\b\x03\b\x03\x04\x06\x06\x03\x02\x05\x05§:int = 1687 + -1640;
      
      public static var §\b\x03\x04\x02\x02\x03\x03\x05\b\x07\x05§:String = "faux";
      
      public static var §\x02\x06\x04\x07\x06\x01\x05\x06\x03\x05\b\x03§:int = 7969 + -4969;
      
      public static var §\x02\x01\x07\x03\x06\x05\x05\x02\x05\x02\x04\x02\x05§:int = 9796 + -9390;
      
      public static var §\x06\x02\x05\x06\x05\x03\x01\x03\x06\x02\x05§:int = 4425 + -3931;
      
      public static var §\x05\b\x05\x01\b\b\x03\x02\x07\b\x03\b§:int = 3997 + -3805;
      
      public static var §\b\x06\x03\x06\x07\x03\x06\x01\x04\x04\x03§:String = "$Btn";
      
      public static var §\x03\b\x05\x06\b\x04\x01\x02\x06\x04\x04§:String = "CL";
      
      public static var §\x03\x03\b\x07\x02\x06\b\x06\x04\x05\x02§:String = "#F0A78E";
      
      public static var §\x03\x02\b\x04\x03\x05\x05\x02\b\x03\x04\x01\x02§:String = "a";
      
      public static var §\x01\x04\b\b\x03\x02\b\b\x07\x04\x04\x06\x01§:String = "127.0.0.1:11801";
      
      public static var §\x03\x07\x07\x02\x05\x01\x07\x06\x07\x05\x04\b\x05§:String = "recupLangue";
      
      public static var §\x02\x07\x02\x05\x03\b\x05\x06\x04\x02\x04\x01§:int = 4940 + -4912;
      
      public static var §\x07\x07\x03\x04\x07\x03\x04\b\x03\x01\x01\b§:int = 8040 + -8015;
      
      public static var §\x05\x05\x06\x07\x04\x06\x04\x03\x01\x02\x04\x07§:int = 3844 + -3399;
      
      public static var §\b\x06\b\x07\b\x01\x01\x04\x07\x03\x01\x02§:String = "!";
      
      public static var §\x07\x07\x04\b\x06\x07\x01\x05\b\x01\x03\x07\x03§:String = "w ";
      
      public static var §\x07\x07\x04\x04\x04\x06\x07\x01\x06\b\x02\x04§:String = "nu";
      
      public static var §\x01\x01\x02\x02\x06\x03\x01\x06\b\x01\x07\x07§:String = "p";
      
      public static var §\x01\x04\x06\x06\x06\x04\x06\x01\x05\x04\x02\x05\x04§:String = "suppr";
      
      public static var §\x02\x06\x01\x04\x03\x03\x01\x06\x02\x03\x01\x04\x04§:String = "Depart2 : ";
      
      public static var §\x01\b\x01\x02\x04\x07\x07\x07\x02\x01\x07\x04§:int = 3972 + 58520181;
      
      public static var §\x05\x07\x06\b\x03\x05\x07\x03\x05\x06\x04§:String = "=";
      
      public static var §\x04\x03\x04\x02\x04\x07\x05\x07\b\x06\b§:String = "Steam AIR";
      
      public static var §\b\x07\b\x04\x04\x04\x03\x06\b\x01\x06§:String = "son/chamane2";
      
      public function §\x03\x07\x01\x05\x07\x05\b\x04\x01\x01§()
      {
         super();
      }
      
      public static function §\b\x04\b\x01\b\x02\x03\x02\b\x01\x04\b\x04§() : int
      {
         return 828 + -528;
      }
      
      public static function §\x01\x03\b\x04\x05\x05\x01\x01\x04\x04\x02§() : Number
      {
         return (4046 + -4041) / (827 + -817);
      }
      
      public static function §\x01\x02\b\x04\x02\x04\x06\x04\x03\x02\x01\x02\x03§() : Number
      {
         return (3715 + -3713) / (6487 + -6477);
      }
      
      public static function §\x07\x01\x01\x06\x02\x03\x04\x04\x05\x07\x03\x01§() : int
      {
         return 836 + -805;
      }
      
      public static function §\b\x01\x05\x07\x01\x05\x01\x04\x05\x06\x01\x05§() : int
      {
         return 5595 + -5467;
      }
      
      public static function §\x02\b\x06\x07\x06\x03\x06\x06\x02\b\x03§() : int
      {
         return 5420 + -5339;
      }
      
      public static function §\x04\x03\x04\x05\x04\x05\x05\x01\x05\x03\x07\x07§() : int
      {
         return 6984 + -6924;
      }
      
      public static function §\x07\x07\x01\x06\x05\x06\x06\x03\x04\x07\x03§() : int
      {
         return 834 + -703;
      }
      
      public static function §\x02\x02\b\x07\x05\x05\x07\x05\x01\x04\x01\x01\x02§() : int
      {
         return 3395 + -3259;
      }
      
      public static function §\x03\x03\b\x02\x02\x07\x07\x01\x06\x04\x05\x06\x03§() : int
      {
         return 739 + -723;
      }
      
      public static function §\x03\x06\x01\x06\x02\b\x06\x07\x05\x01\x06§() : int
      {
         return 7037 + -6968;
      }
      
      public static function §\x03\x02\x02\b\x02\x06\x03\x05\x07\x01\b\x03§() : int
      {
         return 258 + -233;
      }
      
      public static function §\x06\x02\x07\x06\b\x03\x03\x01\b\x05\x05§() : int
      {
         return 6369 + -6367;
      }
      
      public static function §\x07\x02\x06\b\b\b\x06\x07\x05\x02\x06\x01§() : int
      {
         return 1938 + -1925;
      }
      
      public static function §\x04\x06\x05\x03\x02\x03\x02\x01\x07\x04\x04\x06§() : int
      {
         return 4490 + -4315;
      }
   }
}

