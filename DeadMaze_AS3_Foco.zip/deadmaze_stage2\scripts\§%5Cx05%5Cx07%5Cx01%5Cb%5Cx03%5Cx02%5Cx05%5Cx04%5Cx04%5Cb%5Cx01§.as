package
{
   public class §\x05\x07\x01\b\x03\x02\x05\x04\x04\b\x01§
   {
      
      public static var §\b\x03\x06\x06\x06\b\x07\x03\x06\x02\x01\x06§:int = 8829 + -75;
      
      public static var §\x06\x01\x04\x03\x03\x07\x07\b\x03\x05\x06\x06§:Number = (6742 + -6710) / (7522 + -7422);
      
      public static var §\x05\b\x03\x02\x06\x03\x03\x05\x04\x07\b\x02§:String = "<font size=\'12\'>";
      
      public static var §\x01\x01\x01\b\x07\x05\x04\x06\x03\x05\x06\x07§:String = "flyer_2022-15.jpg";
      
      public static var §\x05\x02\x02\x06\x02\b\x02\x06\x06\x03\b§:int = 9798 + -9585;
      
      public static var §\x06\x01\x01\x02\x02\x01\x07\x07\x05\b\x02\x07§:Number = (9094 + -8657) / (2683 + -2583);
      
      public static var §\x05\x07\b\x02\x03\x02\x02\x05\x02\x01\x02§:int = 3508 + -1189;
      
      public static var §\x06\x02\x06\x07\b\x06\x01\x06\x01\x03\x05\x06§:String = "editeur_sans_limite";
      
      public static var §\b\x05\x02\x03\b\x02\x04\x03\x06\x02\b\x07§:String = "colornick";
      
      public static var §\x03\x03\x04\x04\x05\x04\x06\x05\x01\b\x04\x03§:int = 5505 + -5098;
      
      public static var §\x07\x04\x05\b\x07\x02\x03\b\x07\x07\b\x04\x01§:String = "x_transformice/x_divers/x_mc8.jpg";
      
      public static var §\x03\b\x06\x06\x01\x06\x04\b\x06\x07\x01\x03\x04§:String = "$Redistribuer";
      
      public static var §\x06\x04\x04\x01\x03\x02\x06\x04\x01\x07\x01\x04\x07§:String = "$TaperTexteIci";
      
      public static var §\x06\x05\x06\x06\b\x03\x04\x03\b\b\x02\x07§:String = "idGenre";
      
      public static var §\x02\x03\b\x06\x03\x02\x01\x04\x02\x06\x02\b§:String = "$pointsSucces";
      
      public static var §\x07\x02\x05\x03\x04\x07\x03\b\x06\x02\x06\b\x02§:String = "x_i_86.png";
      
      public static var §\x06\x07\x01\x06\x05\x02\x05\x04\x02\x01\x06\x07\x06§:String = "x_i_67.png";
      
      public static var §\x02\b\x03\b\x03\x07\x02\x02\x01\x03\x03\b§:String = "x_i_12.png";
      
      public static var §\x04\x04\x01\x07\x07\x01\x01\x03\x02\x06\x06\x05\x01§:String = "x_i_32.png";
      
      public static var §\x03\x02\x06\x03\x05\x02\x06\x05\x03\x05\x06\x07§:String = "x_i_44.png";
      
      public static var §\x01\x01\x02\x04\x05\x01\x04\x06\x05\x05\x07\x07§:String = "x_i_24.png";
      
      public static var §\x06\x06\x07\b\x07\b\x07\x07\x02\x07\x05§:int = 8786 + -8460;
      
      public static var §\x03\x02\x07\x04\x07\x04\x01\b\x02\x04\x01\b§:String = "son/dash2";
      
      public static var §\x04\x04\x03\x03\x05\x05\x04\x04\x01\x03\b\x04§:String = "MAJ_Saut";
      
      public static var §\x07\x02\x06\x06\x07\b\x05\x04\b\x07\b\x06\b§:String = "posY";
      
      public static var §\x01\x02\x05\x06\x01\x03\x05\x02\x06\x07\x02\x05\x06§:int = 4248 + 195752;
      
      public static var §\x05\x05\x06\x05\x06\x01\x01\x02\x05\b\x06§:String = "JR";
      
      public static var §\x04\x07\x02\x06\x07\b\x03\x02\x04\x04\x03\x06\x05§:String = "contact";
      
      public static var §\x04\x01\b\x02\x03\x02\x06\x02\x03\x06\x05\x02§:String = "Ca";
      
      public static var §\x03\x03\x02\x03\x02\x04\x07\x01\x07\x02\x01\x07\b§:String = "#Module";
      
      public static var §\x05\x07\x06\x04\x04\x06\x04\x02\x04\x02\x02\x03§:String = "$Echec_Roi";
      
      public static var §\x04\x02\b\x07\b\x05\x02\x06\x07\x05\x02\x01§:String = "$Echec_Fou";
      
      public static var §\x02\x02\x04\x02\x04\x05\b\x05\b\x01\x05§:String = "x_nombreBonusDefilante";
      
      public static var §\x04\x03\x05\x01\x01\x02\b\x06\x07\x07\b\x05§:String = "Costumes ";
      
      public static var §\b\b\x03\x01\x05\x06\b\x03\b\x02\x01\x03§:String = "$EcrireMessage";
      
      public static var §\x06\x02\x02\x03\x05\x04\x05\x01\x05\x05\x04\x07\x01§:String = "$MagasinFraise";
      
      public static var §\x05\b\x02\x05\x01\x07\x06\x04\x03\b\x05\x01\x01§:String = "$Mains";
      
      public static var §\x01\x01\x03\x05\x01\x03\x05\x04\b\b\x01\x05\b§:String = "eye";
      
      public static var §\x07\x05\x07\x03\x05\x05\x06\x04\x02\x03\x04\b§:String = "$EmailNecessaire";
      
      public static var §\x02\b\x04\b\x01\x03\x02\x01\x07\x02\x04\x03§:String = "<p align=\'right\'><CL>";
      
      public static var §\x07\x01\x07\x05\x05\x02\x06\x04\x06\x04\x07\b§:int = 9500 + -7964;
      
      public static var §\x07\x01\x06\x06\x07\x02\x02\x07\x03\x02\x04§:String = "$D_Activation";
      
      public static var §\x01\b\x07\x03\x02\x06\b\b\x04\x07\x03\x05\x05§:String = "combat/elec";
      
      public static var §\x05\b\x06\x03\b\x01\x05\x04\b\b\x02§:String = "$FX_froid_1";
      
      public static var §\x01\x05\x06\x04\x02\x03\x03\x04\x07\x02\x06§:String = "$FX_tranchant_2";
      
      public static var §\x06\x03\b\x07\x05\x02\b\x03\x07\x03\b\x03\x06§:String = "sort_1";
      
      public static var §\x01\x05\x01\x04\x06\x02\x04\x03\x04\x07\x07\x01§:String = "$AnimZombieCourse";
      
      public static var §\x02\x04\x04\b\x07\x01\x02\x03\x07\x06\b\x03\x02§:String = "$AnimZombieStatique";
      
      public static var §\x01\x04\x04\x04\x07\x05\x03\x04\b\x01\x07\x07§:String = "_attaque";
      
      public static var §\b\x04\b\x07\x05\x05\x07\x02\x01\x04\x03§:String = "x_deadmeat/x_interfaces/divers/statut_interface_perso.png";
      
      public static var §\x05\x05\x03\x07\x04\x05\x07\x01\x01\x01\x04\x04\x04§:String = "$AnimAttaqueMN_F_2";
      
      public static var §\x04\x01\x05\x01\x07\x02\x04\x07\x02\b\x07\b§:String = "$AnimAttaqueMN_H_3";
      
      public static var §\x03\x05\x05\x01\x01\x06\x03\x05\x04\x02\x07§:String = "$AnimAttaque_H_1";
      
      public static var §\b\x05\b\x03\x06\x02\x01\x03\x04\x06\x05\x06\x06§:String = "$FX_73";
      
      public static var §\x05\x06\x05\x04\x01\x02\x06\x06\x06\x06\x06\b§:String = "$AnimCourse";
      
      public static var §\b\x01\b\x07\x06\x03\x02\x01\x01\x04\x02\x04§:String = "$AnimLancer";
      
      public static var §\b\x03\x01\x06\x06\x02\x06\x04\x03\x07\x05\x05§:String = "$AnimBoire";
      
      public static var §\x07\x07\x07\x02\x04\b\x01\x05\x06\x02\x06\b§:String = "x_deadmeat/x_interfaces/divers/b1.png";
      
      public static var §\x02\b\x06\x05\x04\x03\x04\x06\x01\b\x05\x05\x01§:String = "cel_equipe";
      
      public static var §\x04\x02\x01\x07\x01\x06\x05\b\x02\x01\x01\x03§:String = "objectif";
      
      public static var §\x03\x07\x04\x06\x04\b\x04\x02\x02\b\x06\x04\b§:String = "x_deadmeat/x_interfaces/steam/fond-compte-atelier801.png";
      
      public static var §\x02\b\x04\x07\x07\x06\x04\x03\x05\x01\x02\x07§:String = "Armor Games";
      
      public static var §\x07\x02\x01\x05\x05\x01\x07\x01\x07\x04\x07\x04\x05§:String = "timer";
      
      public static var §\x05\x01\x06\x06\b\x02\x01\x02\x04\x06\x01\x06§:String = "$AventureQuitter";
      
      public static var §\b\x06\x03\x06\x06\x02\x05\x05\b\b\x03§:String = "$EditeurSupprimerCarte";
      
      public static var §\x06\x04\b\x01\b\x01\x05\x01\x04\x01\x04\x02§:String = "x_deadmeat/x_interfaces/monde/ptivelo.png";
      
      public static var §\x07\x05\x05\b\x04\x02\x07\x05\x04\b\x03\x03§:String = "famfamfam/cup_go.png";
      
      public static var §\x04\x04\x05\x03\x05\x02\x05\x03\b\x04\x01\x02§:String = "<O>reset";
      
      public static var §\x04\b\x03\x06\x02\x01\x01\x03\x06\x05\x04\x02§:String = "New event";
      
      public static var §\x04\x02\x01\b\b\x01\x02\x04\b\x06\x06\x03\x07§:String = "$MQ_";
      
      public static var §\x05\b\x06\x01\x07\x02\x01\x01\x03\x07\x03§:String = "x_deadmeat/x_objets/338.png";
      
      public static var §\x03\x03\x05\x01\x03\x03\x06\x01\x07\x02\x01§:String = "$FondAstuce";
      
      public static var §\x05\x03\b\x01\x03\x04\x06\x04\x03\x01\x07\x05\x05§:String = "NOM";
      
      public static var §\x02\x02\x02\x02\x01\b\x03\x01\x06\x03\x07\x05\x02§:String = "$ETM_6";
      
      public static var §\x02\x02\x01\b\x01\x05\x05\x03\x01\x01\x02\x05§:String = "$Cuisine";
      
      public static var §\x07\x03\b\x05\x07\x07\x02\x01\x01\b\b\x04\x02§:String = "$Feu";
      
      public static var §\x03\x06\x04\x02\x01\x02\x03\x03\x04\x06\x03\x01\x06§:String = "Chloe";
      
      public static var §\x04\x07\x02\x07\x01\b\x07\x02\x01\x04\x01\x07\x06§:String = "cinematique/";
      
      public static var §\x05\x03\x07\x05\x05\x07\b\x01\x06\x03\x03\x05\x06§:String = "voiture";
      
      public static var §\b\x03\x01\x01\x03\x07\x05\x07\b\x02\x02\x07\x04§:String = "#(.+?)\\s*:\\s*(.*?)()$";
      
      public static var §\x04\x07\x04\x04\x03\b\x05\b\x03\b\x03\b§:String = "\\[son_(\\w+)\\]\\s*";
      
      public static var §\x05\x04\x06\x02\x03\x05\b\b\b\b\x06§:String = "x_deadmeat/x_campement/fond3.png";
      
      public static var §\x01\x05\x01\x06\x07\x01\x02\b\x06\x01\b\x01\x04§:String = "clique_objet";
      
      public static var §\x01\x02\x03\b\x03\x01\b\x06\x02\b\b\x02\x05§:String = "$TutoManger";
      
      public static var §\x03\x06\x07\b\x05\x05\x01\b\x07\x01\x04§:String = "$TutoRepos_1";
      
      public static var §\x05\b\x03\x05\b\x07\b\x05\b\x01\x01\x01§:String = "campement_feu";
      
      public static var §\x05\x07\x02\x02\b\x05\x07\x03\x04\x02\x03\x07\x01§:String = "_P_";
      
      public static var §\x07\x02\x07\x02\x02\x01\x04\x04\b\b\x07§:String = "x_aiguille";
      
      public static var §\b\x06\x01\x02\x06\x04\x03\x04\x02\x04\x04\b§:String = "x_deadmeat/x_interfaces/divers/boussole1.png";
      
      public static var §\x05\x04\x06\x04\x05\x03\x07\x07\x04\x05\x06§:String = "</O>]";
      
      public static var §\x04\x07\x02\x02\x01\x05\x04\x06\x04\x02\x07\x07\x02§:String = "<V> / ";
      
      public static var §\b\x06\x03\x01\x04\x06\x01\x01\x02\x05\x04§:String = "x_deadmeat/x_objets/x__fond_0.jpg";
      
      public static var §\x01\x03\x02\x04\x04\x02\x03\x05\x02\x04\x07\x07\x03§:String = "x_deadmeat/x_interfaces/x_symptomes/";
      
      public static var §\x07\x06\x07\x06\x01\x01\x02\x04\x05\x04\x01\x03\x04§:String = "$journal.";
      
      public static var §\x05\x01\x04\x01\x02\x06\x05\x07\x07\b\x06\x03\x01§:int = 9723 + -8733;
      
      public static var §\x05\x06\x06\x07\x03\x01\x01\x01\x07\x03\x01\x02\x05§:String = "$ETM_2";
      
      public static var §\x01\b\x04\b\x04\x04\x06\x06\x02\x04\x03\x04\x02§:String = "$VitesseAttaqueLente";
      
      public static var §\x02\x02\x07\b\b\x01\x06\x04\x03\x02\x03\x02\x02§:String = "\n<J>• Défraichie";
      
      public static var §\x05\x05\x06\x01\x02\x05\x06\x02\x07\x01\x01\x06\x04§:String = "\n<font color=\'#";
      
      public static var §\x06\x06\x07\x07\x05\x04\x03\x02\x03\x01\x04\x07\x03§:String = "$TooltipAventure";
      
      public static var §\x03\x07\x06\x07\x04\x07\x05\x01\x07\x05\x03\x01§:String = "x_deadmeat/x_interfaces/divers/feu.png";
      
      public static var §\x03\x06\x07\x01\x05\x05\x03\b\x03\x05\b\x04\x03§:String = "$Dechirure_";
      
      public static var §\x01\x06\x02\x07\x05\b\x05\x01\x04\x03\x07\x05§:String = "$OrInsuffisantAchat";
      
      public static var §\x05\x07\x07\x02\x03\x04\x06\x06\x06\b\x01\x05\x06§:String = "celousco/equipements/";
      
      public static var §\x03\x05\x07\x07\x06\x03\x02\x01\x01\x06\x06\x06§:String = "celousco/equipements/cadre.png";
      
      public static var §\x06\x03\x04\x04\x03\x06\x04\x05\x01\x05\x06\x06§:String = "Terreur";
      
      public static var §\b\x04\x01\x03\x05\x06\b\x05\x07\b\x01\x06§:String = "$EditeurSpawnDeplacementHorde";
      
      public static var §\x06\x06\x04\x04\b\x04\x05\x04\x05\x06\x01\x04§:String = "$EditeurSeuilReapparitionSpawn";
      
      public static var §\x07\x05\x03\x01\x05\x02\x03\x04\x05\x05\x07\x04\x06§:String = "$EditeurNomScriptExisteDeja";
      
      public static var §\x05\x02\x04\x04\x01\x03\b\x07\x02\x05\x05§:String = "Admin";
      
      public static var §\x04\x04\b\x01\x06\x06\x07\x06\x03\x04\x07\x06\x06§:String = "resizable";
      
      public static var §\x03\x06\x06\x03\x03\x02\b\x07\b\x01\x04\x02\x05§:String = "World options";
      
      public static var §\x04\x03\x01\x05\x02\x04\x02\x06\x03\x06\x07§:String = "toit";
      
      public static var §\x03\b\x03\x03\x06\x01\x06\x07\x04\x02\x01\x05§:String = "Rotate right";
      
      public static var §\x03\x04\x01\x01\x05\x02\x02\x05\x05\x05\x02\b§:String = "Transparent mode <V>(T)";
      
      public static var §\x02\x02\x04\x05\x06\x04\x04\x05\x04\x03\b§:String = "Random elevation";
      
      public static var §\x02\x02\x04\x01\x03\b\b\x06\b\x06\x02\x02§:String = "<D>Red\n<N>Mouse wheel to change\nPress <V>CTRL</V> to change globaly";
      
      public static var §\x07\x07\x05\x05\x03\x04\x02\x02\x01\x02\b\b\x04§:String = "Remove light";
      
      public static var §\x03\b\x07\x02\x06\x03\x06\x06\x04\x04\x06\b\x06§:String = "lumiere_2";
      
      public static var §\x03\x07\x07\x04\x05\x02\x05\x04\x04\x04\x03§:String = "$EditeurTypeNarrationTexteInterface";
      
      public static var §\x05\x06\x03\x07\x05\x05\x04\x03\x04\x07\x07\x02\x07§:String = "$langue.lituanien";
      
      public static var §\x07\b\x03\x07\x01\x07\x01\x03\x02\b\x05\x05\x03§:String = "NO";
      
      public static var §\b\x03\x04\x01\b\x04\x05\x02\x06\x04\x05\x04\x02§:String = "$langue.polonais";
      
      public static var §\x07\x05\x02\x04\x06\x06\x05\x01\x03\x05\x03\x04\x01§:String = "FR";
      
      public static var §\x01\x07\x06\x04\x06\x03\x02\x05\b\x03\x04\x02\x07§:String = "<V>Current difficulty : <O>";
      
      public static var §\x01\x07\x05\x07\x03\x01\x07\x02\x06\b\x05§:String = "<N>E : ";
      
      public static var §\x04\x06\x05\x07\x03\x07\b\x01\x04\x07\x06\x06\x01§:String = ". Iterations: ";
      
      public static var §\x04\x03\x03\x05\x03\x01\x01\x01\x06\x06\x01§:String = "x_amb_neige";
      
      public static var §\x05\x05\b\x07\x04\x03\x07\x01\x03\x05\x03\x05§:String = "combat";
      
      public static var §\x01\x06\b\x03\x04\b\x04\x04\b\x06\x06\x05\x03§:int = 2289 + 999997711;
      
      public static var §\b\x01\x03\x04\x03\x02\x06\b\x06\x05\x05§:String = "$PDM_4";
      
      public static var §\x02\x07\x06\x07\x06\x03\x04\x05\x03\x01\x03\x06§:String = "$I_FondBouton_DM";
      
      public static var §\x04\x03\x02\b\x07\x01\x03\b\b\x03\b§:String = "deadmaze.com";
      
      public static var §\x04\x04\x07\x01\x05\x06\x04\x04\x06\x04\b\x02§:String = "$FX_30";
      
      public static var §\x06\x07\x05\x05\x03\x01\x03\x05\x06\x02\x04\x06\x07§:int = 7503 + -7001;
      
      public static var §\x01\x07\x07\x05\x02\x06\x06\b\x07\x05\x05\x03\x06§:String = "\n<BL>";
      
      public static var §\x03\x05\x07\x04\x01\x05\x02\x02\x05\x06\x06\x07§:String = "$DeblocageEquipement";
      
      public static var §\x02\x05\x03\x07\x07\x07\x07\x03\x06\x04\x02\x02§:String = "$competences.";
      
      public static var §\x02\x07\x04\x04\x01\x01\x02\x02\x03\x02\b§:String = "x_deadmeat/x_interfaces/divers/barbe.png";
      
      public static var §\x07\x01\x02\x03\x05\x05\b\b\x01\x06\x03\x03\x01§:String = ".description";
      
      public static var §\x06\x02\x07\x02\x06\x05\x06\x01\x07\x07\b\x03§:String = "<R>Image [";
      
      public static var §\x04\x03\x05\x03\x04\x06\x01\x03\x03\x05\x02\x05\x06§:String = "OreilleG_1";
      
      public static var §\x02\x04\x03\x06\x02\x04\b\x04\x07\b\b\x02§:String = "Initialisation des animations";
      
      public static var §\x07\x02\x04\x04\x03\x01\b\x01\x03\x06\x01\x02\b§:String = "x_transformice/familiers/";
      
      public static var §\x07\x01\x02\x03\x06\x03\x02\x02\x01\x05\x01\x02§:String = "$FD";
      
      public static var §\x03\b\x06\x06\x03\x03\x03\x01\x01\b\x04\x02§:String = "#1";
      
      public static var §\x03\x07\x01\x02\x03\x03\x06\x07\x05\x04\x07§:String = "$InvTribu_IgnorerTout";
      
      public static var §\b\x02\x02\x02\x05\x07\b\x02\x04\x01\x01\x03§:String = "<font color=\'#FEB1FC\'>";
      
      public static var §\x03\x07\x03\x06\x06\x05\x03\x04\x04\x02\x05\x06§:String = "$Tour";
      
      public static var §\x04\x03\x04\x05\x01\b\x05\x01\x06\x03\x06\x05§:String = "souris";
      
      public static var §\b\x07\x02\x06\x05\x05\x06\x03\b\x05\x03\b§:String = "[Allopass | ";
      
      public static var §\b\x05\b\x06\x07\x07\x07\x01\x06\b\x07\x06§:String = "Identification tardive";
      
      public static var §\x02\x01\x05\x01\x04\x02\x04\b\x06\x02\x01\x05§:String = "127.0.0.1";
      
      public static var §\x03\x06\x05\x05\x03\x02\x04\x06\x03\x06\x06§:int = 9849 + -9686;
      
      public static var §\x04\b\b\x01\x02\x04\b\x07\x05\b\x01\x06\x05§:String = ", details=";
      
      public static var §\x06\x05\x06\x01\b\b\x02\x02\b\x06\x04§:String = " {\n\tid=";
      
      public static var §\x07\x06\x04\x01\x02\x01\x07\x07\x02\x06\x06\x04§:String = ",\n\tpeutAffecterRangs=";
      
      public static var §\x06\x04\x02\x04\x03\x05\x04\b\x03\x01\x01\x02§:String = "$chat.message.nomInvalide";
      
      public static var §\x06\x06\x01\x04\x05\x03\x07\x03\x07\x03\x04\x05§:String = "$chat.tribu.signaleDepartMembre";
      
      public static var §\x01\x06\x03\x07\x07\x07\x06\b\x06\x04\x02\x01§:int = 9562 + -7550;
      
      public static var §\x03\x06\x05\x07\x07\x05\b\x03\x04\x05\x03\x03§:String = "\\$&";
      
      public static var §\x07\x04\b\x07\x01\x05\x02\x01\b\x06\x01§:String = "Youtube.API.chargerVideoParId";
      
      public static var §\b\x01\x04\x02\x02\b\x04\x01\x06\x06\x06\x05\x03§:String = "Română";
      
      public static var §\x04\x07\x04\x04\x02\x04\x04\b\x02\x07\x01\b§:String = "vk";
      
      public static var §\b\x06\x01\x02\x03\x02\x06\x01\b\b\x01\x06\x05§:String = "storage";
      
      public static var §\x07\x04\x03\x01\x02\x07\x03\x02\x04\x04\x07\x06§:String = "x_recupClipMultitouche";
      
      public static var §\x05\x02\x06\x02\x06\x07\x01\x06\x03\x02\b\b\x06§:String = "Initialisation version mobile";
      
      public static var §\x02\x01\x01\x06\x06\x03\x05\x03\x05\x02\x06\b§:int = 609 + 101;
      
      public static var §\x01\b\x05\x03\x02\b\x01\x05\x03\x06\x01\b\x04§:String = "stopVideo";
      
      public static var §\x06\x02\x05\x06\x07\b\x01\x04\x06\x01\x03\x05\x07§:String = "http://atelier801.com/user-images-home";
      
      public static var §\x03\x06\x03\x06\x02\x05\x02\x02\x02\x06\x02\x02\x03§:String = "ban ";
      
      public static var §\x05\x05\b\x02\x02\x04\x01\x02\x05\x07\x01\x03§:Number = (7928 + -7843) / (6649 + -6549);
      
      public static var §\x03\x03\x05\x03\b\x01\x07\x03\x01\x02\x03§:String = "join";
      
      public static var §\x03\x04\b\x04\x01\x04\x01\x05\b\x06\x01\x01§:String = " and ";
      
      public static var §\x03\b\b\x04\x07\x06\x02\x02\x04\x06\x01\x05§:String = "$popup.tribu.quitter.titre";
      
      public static var §\b\x05\x04\x07\x02\x07\x07\b\x06\x01\x02\x03§:String = "$popup.tribu.dissoudre.etiquette";
      
      public static var §\x06\x06\x05\x01\x01\x07\x07\x01\x01\x07\x07\x07\b§:String = "<font color=\'#6C77C1\'>[";
      
      public static var §\x03\x03\x07\x02\b\x05\x04\x05\x02\x05\x04\b§:String = "$interface.tribu.bouton.changerMessageJour";
      
      public static var §\b\x03\x01\x04\b\x06\x04\x03\x07\x04\x05§:String = "$popup.tribu.designerChefSpirituel.titre";
      
      public static var §\x01\x02\x06\x02\x06\x07\x01\x04\x02\x01\x02\x03\x04§:String = "$popup.tribu.choisirNouveauRang";
      
      public static var §\x03\x04\x05\x03\x07\x02\x01\x03\b\x03\x05\b\x06§:String = "…";
      
      public static var §\x01\x05\x04\x02\x03\x01\x05\x04\x05\b\x04\x06§:String = "$menu.contextuel.joueur.retirerAmi";
      
      public static var §\x01\x05\x07\b\x05\b\x07\x03\b\x07\b§:String = "$PlusTard";
      
      public static var §\x06\x03\x07\x01\x01\x07\x03\x05\b\x05\b§:String = "   <CS>[";
      
      public static var §\x04\x07\x05\b\x04\x07\x01\b\x05\x06\x04\x07§:String = "_maison";
      
      public static var §\x05\x05\x06\x02\x02\x03\b\x01\x01\b\x07\x06§:String = "$EmailOuPseudo";
      
      public static var §\b\x04\x01\x06\x05\x02\x05\x05\x01\x06\x02\x03§:int = 8417 + -7759;
      
      public static var §\b\x02\x05\x03\b\x06\x07\x07\x05\x05\x06\x07\x04§:String = "$EmailInvalide";
      
      public static var §\x07\x01\x01\x02\x04\x02\x06\x07\b\x02\x04\x02§:String = "$CreationCompteBloqueeTemps";
      
      public static var §\x01\x01\x07\b\x01\b\x07\x02\b\x03\x06\x02§:String = "https://www.transformice.com/divers/terms_and_conditions_of_use.html";
      
      public static var §\x04\x02\x01\x07\x01\x02\b\x01\x02\x07\x05\x02\x05§:String = "pro";
      
      public static var §\x06\x02\b\b\x02\x01\x07\x05\x06\x02\b\x07§:String = "h</G>";
      
      public static var §\x06\x02\x01\b\x06\b\x02\x05\x04\x02\x06\x01§:String = ")</G>";
      
      public static var §\x03\b\x03\x04\x02\b\x01\x03\x02\x06\x07\x01§:String = "mac os";
      
      public static var §\b\x05\x03\x05\x03\x01\x01\x06\x02\x07\x05\x03§:String = "</BL>\n";
      
      public static var §\x02\x06\b\x02\b\x01\x01\x02\x02\x03\b§:String = "_param";
      
      public static var §\x04\x04\x02\x06\x07\x04\x07\x02\x04\x04\x03\x07§:String = "x_commun/x_image_stat/x_cadre.png";
      
      public static var §\b\x04\x01\x01\x07\b\x04\x06\b\x01\x02\b§:String = "<BL>[$1]<N>";
      
      public static var §\b\x04\x03\x01\x03\x01\x02\x05\x03\b\x06\x07§:String = "<G> / ";
      
      public static var §\x02\x04\x04\x07\x03\x06\x06\x02\x07\x06\x04\x04§:String = "$Sondage_Lancer";
      
      public static var §\x06\x01\x07\x07\x06\x01\x01\x07\x01\x04\x06§:String = "modemusique";
      
      public static var §\x05\x02\x03\b\x05\x06\x05\b\x01\b\x07§:String = "p://";
      
      public static var §\x06\x07\x04\x01\x04\x01\x07\x05\x02\x02\x04\x03§:String = "$Chat_Cafe";
      
      public static var §\b\b\x01\x06\x05\x07\x02\x06\x03\x01\x06§:String = "Verdana";
      
      public static var §\x02\x05\x03\x03\x06\x06\x01\x04\x02\x06\x04\x03§:String = " <VP>+";
      
      public static var §\x07\x03\x02\x03\b\b\x01\x05\x01\x02\x06§:String = " <R>";
      
      public static var §\x02\x04\x05\x05\x04\x04\x02\x07\b\x04\x01\x03\x07§:String = "<i>$1</i>";
      
      public static var §\x07\b\x05\x05\b\x03\x04\x02\x02\x07\x06\x05§:String = "<ROSE>";
      
      public static var §\b\x02\x04\x01\x04\x04\x04\x03\x04\x01\x02\x04§:String = "recupTicketAuthentification";
      
      public static var §\x03\x06\x07\x06\x04\x05\x02\x03\x07\x01\x04\x07§:String = "rFrame";
      
      public static var §\x06\x01\x01\x06\x02\x01\x07\b\x07\x04\x03\x02§:String = "F8";
      
      public static var §\b\x04\x04\x07\x03\x06\x07\x05\x05\b\x04§:String = "-";
      
      public static var §\x07\x02\x01\x03\x07\x04\b\x04\x05\b\x02\x01§:String = "9";
      
      public static var §\b\x01\b\x02\x04\x01\x02\x04\x04\b\x06§:String = "4";
      
      public static var §\x03\x02\x02\x06\x06\b\b\x01\x06\x06\x02\x07\x01§:String = " // ";
      
      public static var §\x03\x03\x07\x05\x05\x04\x06\x05\x04\x01\x01\x07\x04§:String = "&amp;";
      
      public static var §\x07\x04\x03\x05\x01\x01\x03\x01\x01\x02\x06\b§:Number = (2661 + -916) / (5804 + 94196);
      
      public static var §\x05\x01\x03\b\x04\x07\x01\x07\x03\x07\x02\x03\x01§:String = "mouseOut";
      
      public static var §\x07\x06\x07\x07\b\x04\x02\x02\x02\x06\x02§:int = 9228 + -9026;
      
      public static var §\x07\x04\x06\b\x07\x02\x05\x06\x06\x05\x05\b§:int = 2744 + -2672;
      
      public static var §\x06\x06\x01\x07\x06\x02\x06\b\x05\x05\x03\x07\x07§:int = 3695 + -2195;
      
      public static var §\x06\x07\x07\x01\x07\x07\x02\x07\x04\x02\x03§:int = 5229 + -4749;
      
      public static var §\x02\x04\x07\x03\b\x05\b\x01\x01\x05\x05\x05§:int = 7485 + -7427;
      
      public static var §\x05\x05\b\x03\x06\b\x06\x05\x06\x01\x06\x05§:int = 2364 + -2104;
      
      public static var §\x04\x04\x07\x02\x07\x03\b\b\x06\x05\x04§:int = 9308 + -9279;
      
      public static var §\x06\x07\x05\x06\x05\x02\x05\x01\x07\x03\x04\x06\x03§:int = 7765 + -7650;
      
      public static var §\x06\x07\x02\x05\x06\x06\x03\x07\x01\x03\x02\b\x02§:String = "- ";
      
      public static var §\x01\b\x07\x04\x07\b\x06\x01\x03\x04\x07\x05\b§:int = 1918 + -1692;
      
      public static var §\x05\x06\x03\x01\x04\x07\x01\x06\x03\x03\x05\x01§:String = "eY";
      
      public static var §\x06\x02\x04\x05\x04\x05\b\x01\x01\x04\x03§:String = "target";
      
      public static var §\x03\x02\b\x05\b\x03\b\x06\x05\b\x02\x07\x05§:String = "inputSpeedBonus";
      
      public static var §\x02\x04\x06\b\x06\x03\x06\x03\x03\b\x02§:String = "defilante_vitesse.png";
      
      public static var §\x05\x01\x03\x03\x04\x05\x05\x07\x05\x05\x03\x03\x02§:int = 819 + -762;
      
      public static var §\b\x03\x03\x02\x05\x05\b\x04\x04\x02\x05§:String = "QCJJbkr+Jb";
      
      public static var §\x01\x03\x07\x05\b\x05\x06\x03\x01\x02\x03\x01§:String = "null";
      
      public static var §\b\x01\x04\x07\b\x04\x02\b\x03\x03\x01\x01\x04§:String = "hilebol";
      
      public static var §\x05\b\x05\x06\x05\x07\b\x01\x01\x01\b§:String = "wesh : ";
      
      public static var §\x03\x04\x04\x01\b\x04\x02\x01\x01\x05\x07\x02§:int = 2433 + -1783;
      
      public static var §\x04\x02\x05\x06\x04\x02\x01\x01\x05\x05\x06\x05§:String = "$M";
      
      public static var §\x05\x04\x05\x05\x02\x06\x07\x03\b\x01\x06§:String = "#E9E654";
      
      public static var §\x03\b\x07\x07\b\x07\b\x02\x02\x01\b§:String = "#FF8547";
      
      public static var §\x01\x05\x07\x06\x06\x02\x01\x02\x06\x03\x06§:String = "Lancement des interfaces";
      
      public static var §\x02\x02\x04\x06\x07\b\x05\x07\x06\x06\x02\x06§:String = "Erreur sur le texte : ";
      
      public static var §\x04\x02\x07\x02\x07\x02\x03\x03\x05\x02\x02\x02\x03§:String = "$Esprit";
      
      public static var §\x05\x03\x01\x03\x02\b\x03\x01\x01\x02\x02\x07\x07§:String = "$OC_ClouVert";
      
      public static var §\b\b\x06\x06\b\b\x02\x05\x03\x06\x03\x03\x01§:String = "$Trampoline";
      
      public static var §\x06\x04\b\x04\x05\x03\b\b\x03\x07\x06\x04§:String = "$Flèche";
      
      public static var §\x04\b\b\x03\x03\x01\x02\x07\b\x02\x06\b\x02§:String = "<font color=\'#FEB1FC\'>Crazy Cat Lady</font>";
      
      public static var §\b\x06\x03\b\x03\x06\x02\x01\b\x06\x03\x01§:String = "Erreur d\'ordre de la clef de chiffrement : ";
      
      public static var §\x01\x03\x01\x04\x02\x03\x05\x02\x07\x01\x07\x02§:String = "c*";
      
      public static var §\x01\x06\x01\x03\x03\x06\x05\x02\b\x06\x07\x07\x02§:String = " - ";
      
      public static var §\x05\x07\x02\x02\x06\x04\x04\b\x01\x06\x06\x01§:String = "bytes";
      
      public static var §\x03\x05\x01\b\x03\x04\b\x01\x02\x03\x01§:String = "me";
      
      public static var §\x07\b\x04\b\b\x04\x01\x01\x07\x02\x05\b\x04§:String = "salonauto";
      
      public static var §\x04\x06\x04\x04\x05\x03\b\x01\x05\x06\x06\b\x02§:int = 8561 + -7941;
      
      public static var §\x02\x01\x03\x03\x06\x03\x07\x01\x02\x05\b§:String = "Espèce de vieille souris.";
      
      public static var §\x02\x07\x01\x04\x04\x02\x04\b\b\x07\x04\x05\b§:String = "deco";
      
      public static var §\b\x06\b\x07\x01\x04\x03\x04\x02\x01\x03\x06§:String = "\'>";
      
      public static var §\x01\x02\x06\b\x01\x06\x04\x02\x07\x04\b\x04\b§:int = 6997 + -6935;
      
      public static var §\x06\x04\x06\x04\b\x04\x01\x01\x06\x02\b\b§:String = "http://img.atelier801.com/";
      
      public static var §\x03\x05\x07\x02\x06\x01\x05\x01\x04\b\x05\x07\x03§:int = 2004 + -1604;
      
      public static var §\b\x06\x02\x01\x01\x05\x04\x06\x07\x03\x07\x03§:int = 4423 + -3823;
      
      public static var §\x04\x06\x06\x06\b\x07\x05\x01\x05\x01\x06\x02\x03§:String = "C_KNG";
      
      public static var §\x06\x04\x02\x01\x03\x04\x03\x06\x07\x04\x01\x03\x07§:int = 2778 + -2428;
      
      public static var §\x02\x05\x07\x07\x05\x06\x02\x03\b\x03\x05§:int = 64 + -47;
      
      public function §\x05\x07\x01\b\x03\x02\x05\x04\x04\b\x01§()
      {
         super();
      }
      
      public static function §\b\x03\x04\x06\x04\x02\x04\x06\x06\x04\x04\x06§() : int
      {
         return 1943 + -1182;
      }
      
      public static function §\b\x01\x07\x04\x04\x04\x07\x01\x04\x04\x07§() : int
      {
         return 1117 + 20117;
      }
      
      public static function §\x01\x02\x02\x02\b\x04\x06\x02\x01\x01\x03\x01\x04§() : int
      {
         return 7765 + -6945;
      }
      
      public static function §\x03\x02\x05\x03\x02\x05\b\x01\x03\x01\x05\x02\x05§() : int
      {
         return 7804 + -2804;
      }
      
      public static function §\b\x02\x03\x03\x05\x04\x02\x04\x03\x04\x06\b§() : int
      {
         return 9993 + -9483;
      }
      
      public static function §\x06\x05\x04\x02\x01\x06\x02\x07\x03\x06\x04§() : int
      {
         return 3342 + -3094;
      }
      
      public static function §\x05\x04\x02\x02\x03\x07\x04\x02\b\x04\x07\b\x03§() : int
      {
         return 712 + -610;
      }
      
      public static function §\x07\x06\x02\x05\x05\x07\x04\x05\x05\x05\x03§() : int
      {
         return 4492 + -4445;
      }
      
      public static function §\x06\x02\b\x07\x05\x05\x07\x06\x05\b\x02\b\b§() : int
      {
         return 6706 + -6671;
      }
      
      public static function §\x01\x01\b\x07\b\x05\x02\x06\x03\x07\x02\x04§() : int
      {
         return 3250 + -3134;
      }
      
      public static function §\x02\x03\x03\x03\x06\x02\x02\x06\x01\x02\x01\b\x02§() : int
      {
         return 8858 + -8754;
      }
      
      public static function §\x03\x06\b\x06\x01\b\b\b\x05\x01\x01\x02§() : int
      {
         return 8174 + -8071;
      }
      
      public static function §\b\b\x04\x04\x01\x03\x05\x03\x06\x05\x02\x03\x02§() : int
      {
         return 3972 + -3795;
      }
      
      public static function §\x04\x06\x02\x05\x05\x06\x02\x06\x02\x04\b\x06\x07§() : int
      {
         return 1194 + -1153;
      }
      
      public static function §\x06\x04\x04\x05\b\x06\x01\x04\x03\x02\b§() : int
      {
         return 4060 + -3868;
      }
   }
}

