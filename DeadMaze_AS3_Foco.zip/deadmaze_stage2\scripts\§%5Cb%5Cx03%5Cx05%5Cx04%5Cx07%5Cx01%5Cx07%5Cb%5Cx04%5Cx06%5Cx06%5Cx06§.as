package
{
   public class §\b\x03\x05\x04\x07\x01\x07\b\x04\x06\x06\x06§
   {
      
      public static const §\x05\x07\x01\x03\x04\x05\x04\b\x01\x06\x01\x06§:int = 65535;
      
      public static const §\x03\x06\x03\b\b\x05\x02\x05\b\x02\x04\x05§:Number = Math.PI;
      
      public static const §\x06\x07\x01\b\x07\x04\x03\x07\x04\x07\x03§:int = 6423 + -6421;
      
      public static const §\x01\b\x02\b\x04\b\x05\x05\x03\x07\x02\x07\x07§:int = 8381 + -8373;
      
      public static var §\x03\x05\b\x03\x02\x02\x01\x06\x01\b\x05§:int = 8699 + -8187;
      
      public static var §\x05\b\b\x07\x02\x01\x03\x03\x01\x04\x07\x01§:int = 2859 + 1237;
      
      public static const §\x04\x02\x01\x05\x01\b\x04\b\x01\x03\x02\x03§:Number = (8634 + -8629) / (7091 + -6091) + Math.random() * ((2408 + -2407) / (8374 + 991626));
      
      public static const §\x03\x05\x07\x04\x01\x04\x03\x01\x01\b\x02\x01§:Number = (4940 + -4920) / (520 + -510) / ((930 + 870) / (1352 + -1342)) * §\b\x03\x05\x04\x07\x01\x07\b\x04\x06\x06\x06§.§\x03\x06\x03\b\b\x05\x02\x05\b\x02\x04\x05§ + Math.random() * ((6653 + -6652) / (7713 + 992287));
      
      public static const §\x02\x03\x02\x07\x07\x03\x07\x01\x04\b\x02§:Number = §\b\x03\x05\x04\x07\x01\x07\b\x04\x06\x06\x06§.§\x04\x02\x01\x05\x01\b\x04\b\x01\x03\x02\x03§ * ((3957 + -3877) / (789 + -779)) + Math.random() * ((2716 + -2715) / (8770 + 991230));
      
      public static const §\x01\x06\x07\b\x06\x07\x07\x06\x07\b\x07§:int = 700 + -696;
      
      public static const §\x03\x02\x05\x07\b\x04\x02\x02\x01\x02\b\x05\x07§:Number = (8159 + -8149) / (9598 + -9588) + Math.random() * ((3454 + -3453) / (6612 + 993388));
      
      public static const §\x01\x05\x03\x07\b\x01\x02\x04\x06\b\x01\x05§:Number = (4130 + -4128) / (3952 + -3942) + Math.random() * ((8591 + -8590) / (8913 + 991087));
      
      public static const §\x07\x05\x04\x04\x02\x06\x01\x02\x05\x02\x02§:Number = (1739 + -1659) / (511 + -501) / ((1032 + 768) / (3471 + -3461)) * §\b\x03\x05\x04\x07\x01\x07\b\x04\x06\x06\x06§.§\x03\x06\x03\b\b\x05\x02\x05\b\x02\x04\x05§ + Math.random() * ((3820 + -3819) / (4864 + 995136));
      
      public static const §\x04\x04\x02\b\x02\x04\x02\x03\x07\x03\x04\x02\b§:Number = (8191 + -6191) / (4442 + -4432) + Math.random() * ((5750 + -5749) / (4195 + 995805));
      
      public static const §\x06\x06\b\x02\b\x02\x05\x01\x05\x07\b\x05\x05§:Number = §\b\x03\x05\x04\x07\x01\x07\b\x04\x06\x06\x06§.§\x04\x04\x02\b\x02\x04\x02\x03\x07\x03\x04\x02\b§ * §\b\x03\x05\x04\x07\x01\x07\b\x04\x06\x06\x06§.§\x04\x04\x02\b\x02\x04\x02\x03\x07\x03\x04\x02\b§;
      
      public static const §\x05\b\b\x02\x02\x02\x04\x06\x01\x06\x07\x03\x06§:Number = (3103 + -603) / (2656 + -2646) + Math.random() * ((4958 + -4957) / (8994 + 991006));
      
      public static const §\x03\x06\x07\x05\x01\x05\x02\x05\x05\x07\x03\b§:Number = §\b\x03\x05\x04\x07\x01\x07\b\x04\x06\x06\x06§.§\x05\b\b\x02\x02\x02\x04\x06\x01\x06\x07\x03\x06§ * §\b\x03\x05\x04\x07\x01\x07\b\x04\x06\x06\x06§.§\x05\b\b\x02\x02\x02\x04\x06\x01\x06\x07\x03\x06§;
      
      public static const §\x01\x01\x01\x06\x01\x04\x02\x07\x07\x06\x01\x04§:Number = (5394 + -5389) / (952 + -942) + Math.random() * ((763 + -762) / (7833 + 992167));
      
      public static const §\x05\x02\b\x07\x07\x02\x04\x07\x06\b\x06\x04§:Number = (3624 + -3623) / (3456 + -3356) + Math.random() * ((9389 + -9388) / (7560 + 992440));
      
      public static const §\x03\x02\x07\x07\x06\x05\x01\x05\x03\x05\x02§:Number = (6632 + -6612) / (1615 + -1605) / ((998 + 802) / (1995 + -1985)) + Math.random() * ((7304 + -7303) / (9845 + 990155));
      
      public function §\b\x03\x05\x04\x07\x01\x07\b\x04\x06\x06\x06§()
      {
         super();
      }
      
      public static function §\x01\b\x06\x03\x02\x03\x05\x02\x07\x07\x07\x03\x01§(param1:Boolean) : void
      {
         var _loc2_:§\b\x05\x05\x06\x05\b\x02\x02\x07\x07\b\x02§ = null;
         if(!param1)
         {
            ++_loc2_.§\x01\b\x01\x05\x06\x05\x04\x02\x05\x05\b§;
         }
      }
   }
}

