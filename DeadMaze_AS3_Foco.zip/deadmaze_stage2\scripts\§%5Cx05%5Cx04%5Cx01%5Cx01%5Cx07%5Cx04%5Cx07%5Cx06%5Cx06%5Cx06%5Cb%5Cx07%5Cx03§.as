package
{
   public class §\x05\x04\x01\x01\x07\x04\x07\x06\x06\x06\b\x07\x03§
   {
      
      public static var §\x05\x07\x07\b\b\x05\b\x06\x02\b\x04\x01§:String = "ajout objet : 9";
      
      public static var §\x01\x01\x03\x04\x01\x07\x04\x07\x05\x04\x06\x04§:String = "<p align=\'right\'><BL>";
      
      public static var §\x04\x07\x02\x01\x03\x02\x06\x04\b\x03\x02\x04§:String = "x_fourrures.swf";
      
      public static var §\x07\b\x02\x06\x01\x05\x03\x04\x02\x06\x04\b\x07§:String = "youtubelast.jpg";
      
      public static var §\x04\x06\x03\x05\x06\x01\x01\x02\x07\x04\x01§:String = "$CarteMonde";
      
      public static var §\x07\x07\x07\x01\x02\x04\x03\b\x06\x06\x01\b§:Number = (9145 + -8910) / (9284 + -9184);
      
      public static var §\x04\x04\x04\x04\x06\x01\x01\x02\b\x06\x06\x06\b§:String = "piments_petite.png";
      
      public static var §\x03\b\x01\b\x05\x07\x01\b\b\b\x07\x07\x06§:String = "citrons.png";
      
      public static var §\b\x01\x06\x01\x01\x03\x04\x04\x01\x04\x01\x02§:String = "tomates_petite.png";
      
      public static var §\x03\x07\b\x02\b\x06\x05\x06\x02\x04\x01§:String = " (-";
      
      public static var §\b\x06\b\x01\x03\x05\x07\x07\x01\x07\b§:String = "transformice.com";
      
      public static var §\x02\x03\b\x02\x07\x03\x04\x06\x05\x02\x03§:String = "orage";
      
      public static var §\x03\b\x06\x03\x01\x03\x05\x06\x01\x05\x05\x03§:String = "kong";
      
      public static var §\b\x06\x03\x01\x05\x06\x06\x06\x07\x06\x04\x03§:String = "$DelaiConso";
      
      public static var §\b\x05\x05\x06\x05\x05\x04\b\x07\x04\x03\x06§:String = "$CatInvTFM_";
      
      public static var §\x05\x07\x03\x02\b\x03\x06\x01\x01\x04\x03\x06\b§:String = "x_transformice/x_divers/x_mc";
      
      public static var §\x02\x03\x02\x06\x02\x02\b\x03\x01\x02\x01\x02§:String = "$competence/mecanicienne";
      
      public static var §\x04\x06\x01\x07\b\x02\x02\x03\b\x02\x05\x03\x04§:String = "$competence/maitresse_du_vent";
      
      public static var §\x04\x07\b\x05\x07\x07\b\x06\x06\x05\x07\b\x07§:String = "sale amount";
      
      public static var §\x05\x01\x07\x01\x07\b\x07\x01\b\x01\b\x01\x01§:String = "item id";
      
      public static var §\x01\x03\x07\x05\x05\x07\x04\x06\x06\x03\x03\x01\x04§:String = "$Inventaire_EchangeTermine";
      
      public static var §\x01\x03\x06\x01\x06\x07\x01\x06\b\x02\x05§:String = "\'><G>";
      
      public static var §\b\x04\x03\b\x02\x07\x06\x04\x02\x03\x01\x01§:String = "[<a href=\'event:echange_non;";
      
      public static var §\x07\x02\x06\b\x06\x02\x01\x02\x03\x06\x07\x01\x05§:String = "$FondClou";
      
      public static var §\x04\x03\x01\x07\x04\x07\x04\x06\x01\x02\x05\x06\x03§:String = "<font color=\'#79ABBB\'>********</font>";
      
      public static var §\x05\b\x03\x07\x05\x04\x01\x01\b\x03\x05\x07\x01§:String = "$C_Mecanicienne";
      
      public static var §\x06\x04\b\x06\x03\x06\x07\x07\x07\x04\x01\x02§:String = "x_i_92.png";
      
      public static var §\x07\b\x02\x01\b\x02\x02\x02\x03\x01\x07\x01§:String = "x_i_85.png";
      
      public static var §\b\x05\x01\x03\b\x01\x01\x01\b\x02\x05§:String = "x_i_18.png";
      
      public static var §\x07\x07\x01\b\x01\x01\x03\x03\b\x05\x04\x07\x05§:String = "x_i_35.png";
      
      public static var §\x04\x02\x04\x02\x05\x01\b\x05\x02\x05\x05\x02\x07§:String = "$B";
      
      public static var §\x05\b\x04\b\b\b\x07\x06\x03\x02\x03\x04§:String = "m_linearVelocity";
      
      public static var §\x05\x05\x01\x01\x07\x04\x03\x07\x07\x03\x01\x06§:String = "_OptionValidation";
      
      public static var §\x05\x03\x01\x02\x07\x06\x04\x05\b\x06\x04\x02\b§:String = "SA";
      
      public static var §\x06\x05\x06\x05\x02\x06\x06\x02\x03\x06\b\x07§:String = "friction";
      
      public static var §\x07\x04\x06\x03\x05\x04\x05\x03\b\x04\x04\x07\x03§:String = "halloween";
      
      public static var §\x03\x01\b\x02\x05\x05\x02\x02\x02\x07\x03\x04\x01§:String = "archAcc";
      
      public static var §\b\x02\x01\x06\x07\b\x04\x07\x05\x03\x07\x02\x04§:String = "x_bouboum/x_interface/x_divers.png";
      
      public static var §\x07\b\x01\x04\x05\x02\x06\x07\b\x01\x04\x04\x04§:String = ". <V>";
      
      public static var §\x01\x04\b\x06\x07\x06\x01\x04\x06\x03\x05\x02\x07§:int = 7240 + -5050;
      
      public static var §\x03\x05\x04\x07\x03\x02\x07\x06\x01\x01\x03\x04§:String = "\' color=\'#FCDAA7\'>";
      
      public static var §\x03\x05\x04\x03\b\x06\x03\b\x06\x07\x03\x02\x07§:String = "fermerSelecteurCouleur";
      
      public static var §\x04\b\x05\x05\x01\x07\x04\x07\x03\x05\x03\x07§:String = "NomJoueur";
      
      public static var §\x04\x02\x03\x03\x07\x02\x01\x05\x01\x07\b\x06§:String = "Langue";
      
      public static var §\x01\x03\x05\b\b\x01\b\b\x05\x03\x03\x05\x03§:String = "$Lentilles";
      
      public static var §\x07\x04\x03\x07\x07\x03\x05\x07\x05\x04\x07§:String = "$BoutonAcheter";
      
      public static var §\x04\b\x02\x02\x05\x01\x04\x04\x02\x03\x04§:String = "cu_en.txt";
      
      public static var §\x06\x01\x06\x03\x05\x02\x05\x01\x04\x02\x05\x07§:String = "cu_fr.txt";
      
      public static var §\x07\x01\b\x03\b\b\x01\b\x01\x07\x03\x01\x03§:String = "$Validation_Email_Demande";
      
      public static var §\x01\x06\x01\x04\x05\x05\x05\x02\x01\x02\x05§:String = "chat_btn_fermer";
      
      public static var §\x06\x06\x07\b\x02\x06\b\x05\x03\x02\x01\x04\x07§:String = "btn_rejoindre_over";
      
      public static var §\x02\x02\x02\x02\x04\x06\x03\x03\x01\x01\x03\x02\b§:String = "<CL>";
      
      public static var §\x03\x04\x05\x04\x04\x05\x01\x01\x07\b\x06\x03\x03§:String = "$Couleur";
      
      public static var §\x05\x02\x07\x07\x02\b\b\b\x07\b\x03\x06\x03§:int = 920 + -589;
      
      public static var §\x04\x01\x04\x03\x07\b\x04\x05\x07\b\x04§:String = "x_transformice/x_interface/c2.png";
      
      public static var §\x04\x04\x05\x01\x04\x02\x02\x06\x01\x04\x07§:String = "link";
      
      public static var §\x02\x02\x04\x06\b\x03\x04\x07\x07\x02\b\x07§:String = "$TT_Zone";
      
      public static var §\x04\x03\x07\b\x06\x01\x03\x05\x06\x05\x02\x07§:String = "$Lire";
      
      public static var §\x01\x05\x02\x04\x02\x02\x05\x04\x04\x06\x01\x06\x01§:String = "<font color=\'#FFC66B\'>• ";
      
      public static var §\x07\x03\x05\x03\b\x07\x01\x07\x04\x02\x05\x02\x01§:String = "$FX_morsure_1";
      
      public static var §\x05\x03\b\x04\x07\x07\x07\x02\b\b\x01\x01\x06§:String = "\'>« ";
      
      public static var §\x05\x07\x03\x05\x02\x01\x02\x07\x03\x02\x04\x03\x03§:String = "AnimPistolet";
      
      public static var §\x04\x02\x04\x04\x03\x03\x03\x01\x07\x05\x06\x05\x02§:String = "AnimEsquive";
      
      public static var §\x04\x06\x05\x01\x02\x04\x06\x06\x06\x05\x07\x01\x07§:String = "$AnimAttaqueMN_H_2";
      
      public static var §\x05\x01\x03\x02\x05\x04\x04\x03\x03\x01\x07\x02§:String = "x_deadmeat/x_interfaces/menace/m";
      
      public static var §\x03\x03\b\x03\x07\x01\x07\x07\x07\x07\x02\x03\x05§:String = "$AnimAttaqueComp";
      
      public static var §\b\x05\x03\x07\x04\x04\x04\x06\x07\x05\x01§:String = "manger";
      
      public static var §\x02\x04\b\x05\x03\x06\x05\x04\x02\x05\x07§:String = "x_deadmeat/x_interfaces/principale/fond_ceinture.png";
      
      public static var §\x02\x01\x05\b\x02\b\x02\x03\x07\x03\x01\x05\x02§:String = "$StatDM_";
      
      public static var §\x05\x07\x05\x02\x03\x06\x07\x06\b\x05\x07\x06\x06§:String = "$RetourCamp";
      
      public static var §\x05\x05\x01\x04\x06\x02\x03\x02\x01\x05\x06\x07§:String = "$Supprimer";
      
      public static var §\x03\x01\x06\x02\x06\x02\x05\x05\b\x07\x02§:String = "$PlanZone";
      
      public static var §\x05\x03\x04\x06\x03\x06\x02\x03\b\x06\x01\x04\x01§:String = "$type_effet.18.nom";
      
      public static var §\x05\x04\x01\x05\x07\b\x02\x02\x02\x06\x07\x03\x03§:String = "$EditeurIdModele";
      
      public static var §\x03\x02\b\x02\b\x04\x03\x03\x06\x02\x01\x01\x07§:Number = (1177 + -1174) / (1574 + -1474);
      
      public static var §\x03\b\x03\x01\x01\b\x05\x03\x04\x03\x03§:String = "<R>Type doc inconnu : ";
      
      public static var §\b\x07\x06\x07\x02\x07\x04\x07\b\x02\x05\x04§:Number = (1566 + -1441) / (100 + 900);
      
      public static var §\x07\x01\x01\x01\b\x05\x03\b\b\x03\x03§:String = "$Renommee";
      
      public static var §\x03\x06\x02\b\x02\x04\x02\x04\x04\x05\x01§:String = "famfamfam/bullet_arrow_right.png";
      
      public static var §\x01\x03\x06\x05\x06\x05\x03\b\x04\x03\x07§:String = "<O>delete event";
      
      public static var §\x06\x06\x05\x04\x05\b\x06\x04\x04\b\x05\x07§:String = "compass";
      
      public static var §\x04\x01\x03\x07\x02\b\x06\x06\x07\x07\x01§:String = "cell";
      
      public static var §\x01\x07\b\b\x05\x06\x05\x04\x03\b\x05\x05\x06§:String = "comment";
      
      public static var §\x02\b\x07\x05\x05\x07\x05\b\x06\x05\x02\x02\x01§:String = "$AimeDM2";
      
      public static var §\x04\x04\b\x07\x07\b\x06\x07\b\x01\x06\x02§:String = "x_deadmeat/x_interfaces/divers/zone.png";
      
      public static var §\x07\x03\x05\x03\x07\x07\x02\x06\x05\x06\x01\x06§:String = "x_deadmeat/x_interfaces/divers/chevre.png";
      
      public static var §\x06\x02\x07\x04\x05\x07\x06\x07\b\x06\x06\x04\x02§:String = "$Victoire";
      
      public static var §\x02\b\x05\x01\x02\x03\x07\b\x02\x01\x05\x05§:String = "$Equipement";
      
      public static var §\x06\x01\x05\x02\x05\x03\x02\b\x05\x02\x06\b§:String = "+20%";
      
      public static var §\x07\x05\x06\x02\x02\x05\b\b\x04\x05\x03\x01§:String = "x_deadmeat/x_interfaces/vomi.png";
      
      public static var §\x04\x07\x02\x04\x07\x07\x07\x01\x03\x05\b\x06\x02§:String = "$OngletPlus";
      
      public static var §\x05\x05\x03\x03\x06\x04\x06\x03\x01\x01\x03\x06\x07§:String = "\\s*##\\s*";
      
      public static var §\x06\x01\x02\x02\x05\x03\b\x04\x04\b\x04\x05§:String = " xp";
      
      public static var §\x03\x05\x02\x04\x05\x03\b\x02\x06\x07\x05\x07\x05§:String = "x_deadmeat/x_interfaces/buffs/";
      
      public static var §\x06\x03\x02\x06\b\x04\x01\x06\x03\x04\x01\x01\x01§:String = "$Recette";
      
      public static var §\x07\b\x01\x03\x03\x07\b\x03\b\x05\x02\x05\x06§:String = "\n<ROSE>• ";
      
      public static var §\x01\x02\x04\x04\x06\x05\b\x05\x04\x01\x04\x03§:String = "a.png";
      
      public static var §\x02\b\x05\x02\x06\x05\x06\x02\x07\x04\x01\x02§:String = "$Ast_";
      
      public static var §\x06\x03\x04\x04\x06\x07\x05\x06\x01\x04\x04\x05§:Number = (1736 + -1646) / (3585 + -3485);
      
      public static var §\x01\b\x06\x01\x03\x07\x04\x06\x06\x07\x05\x02§:Number = (5497 + 21327836) / (7860 + 9992140);
      
      public static var §\x03\x01\x06\b\x07\x05\x04\b\x02\b\x03\x07§:String = "x_conteneur";
      
      public static var §\x02\x02\x05\x02\x07\x07\x01\x04\x02\x07\x05\x02\b§:int = 9357 + -8377;
      
      public static var §\b\x07\x03\x07\x03\x06\x04\b\x02\x02\x01§:String = "environment";
      
      public static var §\x04\x01\x04\b\x06\x06\x02\x05\x06\x04\x06\b§:String = "Mask wall <V>(I)";
      
      public static var §\x05\x06\x07\x01\x02\x04\x05\x06\x06\x01\x03\x07§:String = "$EditeurLienPartageGoogleSheets";
      
      public static var §\x01\x06\x06\x05\x06\x06\x05\b\x06\x02\x04\b§:int = 6834 + -6544;
      
      public static var §\x05\x04\x05\x02\x03\x06\x02\b\x01\x04\x05\x05§:String = "$EditeurTitreParametrageModEnv";
      
      public static var §\x06\x07\x01\x04\b\x01\x03\x06\x03\x03\x06\b\x07§:String = "SK";
      
      public static var §\x03\x05\x01\b\x03\b\x03\x02\b\x03\x07\x07§:String = "$langue.chinois";
      
      public static var §\x07\x05\x01\x03\x01\x04\b\x05\b\x03\x06\x01\b§:String = "$langue.turc";
      
      public static var §\b\x06\x03\b\x01\x06\x06\x05\x02\x03\x05\x05§:String = "\nC : ";
      
      public static var §\x06\x03\x04\x06\x03\x05\x02\x03\x06\x07\x03\x03§:String = "Erreur de chargement des informations sur les pictos éditeur.";
      
      public static var §\x03\b\x02\x01\x07\x05\x03\x06\x06\x01\x03\x05\x06§:String = "s_";
      
      public static var §\b\x07\x01\x05\x06\x01\x01\x03\x04\b\x02§:String = "Durée BoucleDeadmeat.boucle : ";
      
      public static var §\x03\x04\b\x03\x05\x05\x07\b\x01\x01\x04\x03\x06§:String = "http://www.transformice.com/images/x_deadmeat/x_pictos/d_";
      
      public static var §\x05\x07\x04\x05\x03\b\x01\x01\x02\x05\x02§:String = "$I_FondTitre_DM";
      
      public static var §\x01\x01\x03\x06\x04\x03\x07\x01\x03\x07\b\b§:String = "$MonnaieDM_0";
      
      public static var §\x03\x07\x03\x07\x07\x03\x06\x04\x05\x07\x05\x04§:String = "http://data.atelier801.com/x_deadmeat/x_musiques/";
      
      public static var §\x05\x04\x05\x05\x02\x02\b\x03\b\x01\x03\x06\x01§:String = "Accessoires_visage_01.swf";
      
      public static var §\x01\x04\x05\x01\b\x01\x04\x02\x07\x07\x01\x04§:String = "Loading external resources";
      
      public static var §\x04\x04\x06\x07\x07\x01\x02\x02\b\x02\x03\x03\x02§:String = "initialized";
      
      public static var §\x02\x03\x06\x04\x02\x03\x07\x03\x04\x01\x07\x05§:String = "$Echange_Proposer";
      
      public static var §\x01\x05\x05\x07\b\x06\x04\x02\x01\x05\x01\x06\x07§:String = "$effet_texte_";
      
      public static var §\x04\x05\x03\x05\x04\x04\x03\b\x07\x04\x06\x05§:String = "x_deadmeat/x_interfaces/xp30.png";
      
      public static var §\x06\x06\x07\x03\b\x01\x07\x06\b\x05\x06\x04§:String = "x_deadmeat/x_interfaces/coffres/icone30coffre.png";
      
      public static var §\b\x01\x04\x07\x06\x06\x07\x06\x05\x07\x07\x06§:String = "kikoo";
      
      public static var §\x07\x02\x06\x06\x07\x04\x06\x05\x05\x01\x03\x05\x01§:String = "Frame";
      
      public static var §\x02\x05\x01\x05\x07\x06\x04\x02\x04\x03\b\x05\b§:String = ";0,0,0,0,0";
      
      public static var §\x06\x03\x04\x06\x03\x05\x07\x02\b\b\x05§:String = "_accessoires";
      
      public static var §\x05\b\x02\x06\x06\x07\x07\x01\x07\x06\x01§:int = 4039 + -3091;
      
      public static var §\x01\b\x06\x05\b\x01\x06\x02\x07\x06\x03\x05\b§:String = "x_divers/x_drapeaux/";
      
      public static var §\x05\x05\x07\x04\x06\x06\x05\x04\x07\x03\x01§:String = "$BarreDinvoc";
      
      public static var §\x04\x05\x01\x01\x03\x01\x05\x03\x05\x07\x05\x04\x02§:String = "Erreur chargement look";
      
      public static var §\x03\x02\x01\x02\x05\x01\x04\x03\x04\x04\x03§:String = "$bullepierre";
      
      public static var §\x04\x07\x04\x06\x05\x04\x02\x04\x06\x07\x06\x06\x06§:String = "x_transformice/x_divers/icone_glace.png";
      
      public static var §\x01\x03\x02\x07\x06\x02\x03\x03\x02\x01\x07\x02\x02§:String = "$Fantome";
      
      public static var §\x02\x03\x04\x07\b\x06\x06\x04\x03\x04\x04\x06§:String = "multi_AnimHi5";
      
      public static var §\x03\x06\x06\x04\x07\b\x06\x03\x01\x01\x01\x01\b§:String = "AnimSelfie";
      
      public static var §\x04\x04\x07\x01\x07\b\x05\x05\x06\x07\x03\x05§:String = "AnimDrapeau";
      
      public static var §\x01\x06\x07\x01\b\x05\x03\x05\b\x02\x07\b§:String = "$Equipe_Gagne";
      
      public static var §\x06\x02\x07\x05\x02\x05\b\x05\x01\x06\x07\x04§:String = "watch ";
      
      public static var §\x04\x03\b\x06\x07\x04\b\b\x01\x01\x04\b§:String = "$C_GainNiveau";
      
      public static var §\x07\x05\x01\x04\x04\x07\x05\b\b\x03\x05§:String = " <J><a href=\'event:MT,";
      
      public static var §\x04\x06\x05\x04\x03\x03\x04\x04\x02\x07\b\x06§:String = "<a";
      
      public static var §\x02\x02\x05\x04\b\x07\x03\x06\x03\x02\b\x05§:String = "<BL> - @";
      
      public static var §\x02\b\x07\b\b\b\x01\x02\x07\b\x02\x06\x02§:String = "Code inconnu : ";
      
      public static var §\x01\x05\x03\x06\x01\x07\b\x05\x01\x02\x02\x03§:String = "$Tribu_Utilisée";
      
      public static var §\x01\x05\x02\x05\b\x05\x06\x05\x05\x05\x05\x07§:String = "11-";
      
      public static var §\x04\x03\x04\b\x05\x01\x07\x07\x04\x05\x06\x05\x02§:String = "<a href=\'event:";
      
      public static var §\x02\x07\x03\x04\b\b\x07\b\x02\x06\x05§:String = "Serveur satellite [<font color=\'#6C77C1\'>";
      
      public static var §\x03\x01\x02\x01\x05\x06\b\x02\x04\b\x01§:String = ",\n\tidAvatar=";
      
      public static var §\x05\x03\x02\x05\b\x06\b\x01\x04\x05\x05\x02§:String = "$chat.amis.signaleAuteurDivorce";
      
      public static var §\x02\x04\x03\x06\x01\x02\x02\x06\b\x05\x02\x07\x03§:String = "$NePlusAfficherPopupsJoueur";
      
      public static var §\b\x06\x05\x01\x05\x05\x02\x03\x07\x01\b\x02\x05§:String = "$texte.invitation.tribu.0";
      
      public static var §\x07\x02\x04\x02\x06\b\x06\x04\x03\b\x02§:String = "$popup.dejaDemande";
      
      public static var §\x05\x01\x04\x03\x02\b\x02\x02\x06\x01\x07\x06§:String = "x_bateaupirate.png";
      
      public static var §\x05\x04\b\x02\x02\x04\x07\x06\x06\x07\x06§:Number = (1119 + -519) / (6236 + -6226);
      
      public static var §\x05\b\x06\x02\x07\x07\x03\x03\x07\x05\x02§:String = "folds";
      
      public static var §\x07\x06\x04\x05\x02\x02\x01\x03\x05\x05\x05§:String = "Language selection ";
      
      public static var §\x05\x07\x02\x03\x04\x04\x04\x02\x04\b\x03\x01§:String = "ee";
      
      public static var §\x01\x07\x02\x02\x04\x01\x06\x07\b\x04\x03§:String = "Čeština/Slovenčina";
      
      public static var §\x01\x03\b\b\x05\x02\x06\x07\x02\x06\x05§:String = "drapeaux/";
      
      public static var §\x02\x05\x06\x06\x06\b\x01\x06\x01\x01\x03§:String = "RESPONSE_USER_CANCELLED";
      
      public static var §\x02\x06\x02\x02\x02\x02\x04\x06\x03\x05\x07\x05§:String = "isConnected";
      
      public static var §\b\x01\x05\x05\x04\x07\x07\x04\x05\x02\x03\b§:String = "$ParticuleColorisable";
      
      public static var §\x04\x04\x04\x01\x01\x01\x03\x07\x01\b\x01\x06§:String = "<font size=\'14\'>";
      
      public static var §\x07\x05\x03\x07\x07\x04\x01\x04\x03\b\x05\x06\x06§:String = "^\\s+(\\S+)\\s+\\S+?::";
      
      public static var §\x01\x06\x07\x06\x02\x03\x07\x06\x04\b\x03\b\x07§:String = "navigateur";
      
      public static var §\b\b\x03\x03\x04\x03\x03\x07\x03\x02\x02§:String = "x_transformice/x_interface/x_offrir.png";
      
      public static var §\x07\b\x06\b\x04\x02\x01\x04\b\x06\x01\x01\x05§:String = "$MDP_Definition";
      
      public static var §\x06\x07\x04\x03\x04\x06\x02\x01\b\b\x02\x04§:String = "$interface.tribu.bouton.quitterTribu";
      
      public static var §\b\x02\x03\x07\x04\x07\x02\x05\b\x01\x03§:String = "_50.jpg";
      
      public static var §\b\b\x04\x05\x05\x04\x01\x07\x06\x01\x01\x03§:int = 963 + -655;
      
      public static var §\x07\x01\x02\x06\x01\x02\x04\b\x01\x01\x03\x01§:String = "18";
      
      public static var §\x01\x03\b\b\x02\x04\x01\x02\b\x04\x05\x04§:String = "17";
      
      public static var §\x07\b\x05\x05\x04\x06\b\b\x01\x02\b\x03§:String = "10,10,10,10,10,10,10,24,24,11";
      
      public static var §\x01\x06\x04\x03\x02\x05\x07\x04\b\x06\x04\b§:String = "<N>)<G> | <R>";
      
      public static var §\x03\x06\x02\b\x01\x06\x07\x04\x06\x04\x04\x01\x06§:String = "   <G>|   <V>";
      
      public static var §\x04\x05\x02\x02\x07\x04\x01\x03\x04\b\x03§:String = "\'>[";
      
      public static var §\x02\x01\x01\x06\x06\x04\x07\x03\x01\x04\x05§:String = "<font color=\'#BABD2F\'>";
      
      public static var §\b\x03\x05\x02\x02\b\x01\x07\x05\x06\x02\b§:String = "tribu";
      
      public static var §\x07\x01\x01\x05\x06\x02\x03\x07\x02\x04\x06\b\x01§:String = "font";
      
      public static var §\x07\x04\x01\x05\b\b\x07\x06\b\x02\x02\x01\x05§:String = "who";
      
      public static var §\b\x01\x02\b\x01\x07\x05\x02\b\x05\x01\x02\x01§:String = "Reception message dans canal inconnu : ";
      
      public static var §\x06\x01\x03\b\x04\b\x01\x06\x05\x05\b\b§:String = "~";
      
      public static var §\x07\b\x05\b\x03\x05\x06\x04\x06\x04\x04\b\x02§:String = "$Monnaie_";
      
      public static var §\b\x06\x02\x03\x02\x01\x07\x02\x06\x04\x04§:String = "_normal";
      
      public static var §\b\x04\x03\b\x05\x03\x05\x06\x04\x01\x01§:String = "x_transformice/x_interface/kongregate/fond-tfm.png";
      
      public static var §\x03\x04\b\x05\x01\x01\x06\x05\x06\x05\x03\b§:String = "$LoginNekodancer";
      
      public static var §\x02\x02\x02\x03\x07\x06\x04\x01\x07\x07\x06\b\x01§:String = "$ContesterBan";
      
      public static var §\x06\x07\x04\x02\x03\x02\x03\x03\x07\b\x07§:String = "https://www.transformice.com/divers/privacy_policy.html";
      
      public static var §\x06\x03\x04\x04\x05\x06\x04\x06\x06\x02\x07§:String = "$Options";
      
      public static var §\x01\x01\x04\x07\x01\x01\b\x05\b\x03\x07§:String = "$Forum";
      
      public static var §\x07\x03\x04\x06\x03\x01\x06\b\x05\x06\x01\x03\x04§:String = "$jeu.description.fortoresse";
      
      public static var §\b\x05\x06\x02\b\x01\b\x04\x01\x07\b§:String = "file";
      
      public static var §\x04\x03\x02\x07\x07\b\x04\x01\x06\x04\x05§:String = "</G>";
      
      public static var §\x02\x05\x01\x03\b\x04\x03\x01\x05\x05\x07§:String = "\\[(.*)]";
      
      public static var §\x04\x03\x07\x07\x04\x05\x07\x05\x05\x05\x01\x04\x03§:String = "salonauto ";
      
      public static var §\x07\x01\x03\x03\x04\x07\x07\x06\x05\x01\x03\x02§:String = "x_transformice/x_minijeux/x_survivor.jpg";
      
      public static var §\x02\x06\x03\b\x03\x05\x04\b\x06\x07\x03\x04\x06§:String = "musique_jeu";
      
      public static var §\x06\x06\x02\x01\x05\x01\x05\x04\x03\x01\x03§:String = "pt/te";
      
      public static var §\b\b\x05\x06\x05\x05\b\x01\x03\b\x07\x04\x06§:String = "<G>";
      
      public static var §\x01\x01\x05\b\x04\x04\x03\x06\x06\x03\x02\x03\b§:String = "__(.*?)__";
      
      public static var §\x04\x02\x03\x02\x06\x06\x06\x04\b\x06\x04\x05\x01§:String = "$Titre";
      
      public static var §\x07\x05\x01\x06\x07\x02\x02\x02\x07\b\x06\x05\x05§:int = 5930 + -3916;
      
      public static var §\x03\b\x02\x05\x03\x04\x03\x03\b\x02\x03\x02\x01§:String = "ArmorGame.png";
      
      public static var §\x03\x01\x05\x04\x01\x06\x06\x01\b\x06\x01\x07§:Number = (5619 + -5553) / (5002 + -4902);
      
      public static var §\x01\x05\x06\b\x01\x06\x06\x05\x02\x07\x07\x05\x07§:String = "$Macaron_";
      
      public static var §\x07\x05\x01\x01\x05\x04\x01\x01\x02\x03\x02\b§:String = "0000";
      
      public static var §\b\x03\x05\x01\x05\x03\x05\x04\x02\b\x05\x06§:String = "demandeTicketAuthentification";
      
      public static var §\b\x06\x06\x07\x05\x06\x01\x07\b\x07\x01\x03§:String = "F7";
      
      public static var §\b\x04\x01\x03\x07\x01\x05\x05\x07\x01\b\x03\x04§:String = "Numpad 3";
      
      public static var §\x01\x06\x02\b\x01\x07\x01\x04\b\x05\x06\b\x07§:String = "Numpad 1";
      
      public static var §\x02\x05\x06\x07\x06\x03\x07\x06\x04\x01\x03\x01\b§:String = "M";
      
      public static var §\x04\x02\x03\x04\x04\x02\b\b\x04\b\x03\b§:String = "Up";
      
      public static var §\x07\x03\x02\x02\x04\x05\x03\x05\x01\x02\x02\b§:String = "://img.atelier801.com";
      
      public static var §\x03\x02\x06\x06\x02\x04\x07\x06\x03\x06\x05\b\b§:String = "cd ";
      
      public static var §\x02\x07\x04\x01\x05\x03\x07\x03\b\x01\x07\x03§:String = "Index ";
      
      public static var §\x06\x07\b\b\b\x05\x06\x06\x02\x07\x01\x04§:String = "</V> m";
      
      public static var §\b\x04\x02\b\x03\x07\x07\x02\x07\x07\x02\x03§:String = "Il existe déjà une action d\'id ";
      
      public static var §\x03\x03\x07\x02\x07\x06\x02\x02\b\x04\x04§:String = "Erreur chargement raccourcis";
      
      public static var §\x01\x05\x05\x03\x02\b\x04\x04\x02\x05\x02§:Number = (5433 + -5423) / (4876 + -4866);
      
      public static var §\x06\x04\x06\x01\b\x05\x03\x01\x04\x05\x04\b§:Number = (3652 + -3607) / (2054 + -1954);
      
      public static var §\x04\x07\x06\x04\x03\x04\x03\x02\b\x02\x05\x06\x04§:int = 1934 + -1081;
      
      public static var §\x02\x05\x06\b\x06\x06\b\x03\x06\x06\x02§:int = 9449 + -9245;
      
      public static var §\b\x05\x01\x02\x04\x07\x05\x01\x04\x07\x06\x03\x03§:int = 9997 + -9794;
      
      public static var §\x04\x05\b\b\x04\x03\x04\x01\b\x01\x07\x07§:int = 1811 + -1698;
      
      public static var §\x01\x02\x07\x02\b\x05\x02\x03\x04\x01\x02\x03\x02§:int = 4468 + -4365;
      
      public static var §\x02\x07\x05\x04\x04\x01\x05\b\x01\x06\b\x02§:int = 9412 + -9319;
      
      public static var §\b\x07\x05\x04\x04\x06\b\x03\x01\x06\x07\x02§:int = 7910 + -7545;
      
      public static var §\x03\x04\x07\x02\x04\b\x02\x02\x03\x04\x05§:int = 6796 + -6605;
      
      public static var §\x01\x04\x06\x05\x05\x01\x04\x07\x03\x02\x07\x02\b§:int = 9744 + -9555;
      
      public static var §\b\x04\x02\x01\x05\x05\x01\x06\x04\x02\x07\x07§:String = "X";
      
      public static var §\x04\x07\x07\b\x04\x05\x07\x07\x06\x07\x03\x02§:String = "addInputGroundSpeed";
      
      public static var §\x06\x01\x05\x02\x01\x05\x05\b\x02\b\x03\x04\x02§:String = "$texte.nom";
      
      public static var §\x06\b\x02\x05\x07\x07\x06\x04\x06\x07\x05§:String = "/t ";
      
      public static var §\b\x02\x05\x01\x06\x02\x01\x03\x02\x02\x06§:String = "$Valider";
      
      public static var §\x02\x04\x04\x05\b\x02\x01\x02\x05\x04\x01§:String = "$AcheterFraise2";
      
      public static var §\x02\x03\x01\x02\x02\x03\b\x04\x03\x04\x07\x01§:String = "$AvertissementValiditeAllopass";
      
      public static var §\x02\x02\x03\x04\x05\x07\x03\x01\x07\x03\x06\x05§:String = "x_transformice/x_interface/paiements/hipay.jpg";
      
      public static var §\x02\x05\x04\x02\b\x04\x05\x07\x03\b\x07\b§:String = "$LogoPaypal";
      
      public static var §\x03\x07\x01\x04\x04\x04\b\x07\x02\x05\x04§:String = "non";
      
      public static var §\x07\x03\x07\b\x05\x07\x01\x07\x01\x01\x05\b§:String = "g";
      
      public static var §\x05\x05\x02\x05\x07\x04\x07\x02\x05\x07\x05\x07\x04§:String = "Joueur : ";
      
      public static var §\x01\x07\x06\b\x04\x01\x06\x04\x05\x05\x01§:int = 1622 + 13378;
      
      public static var §\x07\x04\x04\x03\x01\b\b\x05\x04\x01\x06\x04§:int = 6796 + -6144;
      
      public static var §\x04\x05\x06\b\x07\x02\x05\x02\x03\x04\x06\x05§:String = "Initialisation du proxy des interfaces";
      
      public static var §\x04\b\x06\b\x03\x05\x05\b\b\b\x05§:String = "0";
      
      public static var §\x02\x03\x03\x04\x03\x04\x06\x07\x06\x06\b\x04§:String = "TG";
      
      public static var §\x05\x01\x06\b\x04\x07\x03\x07\x03\b\x05\x07\x06§:String = "FC";
      
      public static var §\x06\x03\x06\x06\x04\b\x01\b\x01\x07\x04\x07§:String = "#EFCE8F";
      
      public static var §\x01\x07\x06\b\x06\x04\x05\x05\x05\x01\x07\x06§:String = "#2EBA7E";
      
      public static var §\x07\x05\x01\x04\x05\x06\x01\x06\x06\x07\b\x05\x06§:String = "PT";
      
      public static var §\x07\x03\x04\x07\x01\x05\x05\x07\x06\x02\x04\x07§:String = "CH";
      
      public static var §\b\x07\b\x03\x04\x03\x03\x01\x02\x04\x03\x04\x05§:String = "$MenuBase";
      
      public static var §\b\b\x02\x07\x04\x02\x05\x06\x05\x07\x07\x07§:int = 1912 + -1885;
      
      public static var §\x04\x07\b\x05\x04\x05\x01\x07\x03\x04\x03\x04§:String = "$TP_0";
      
      public static var §\b\x04\x04\b\x04\x02\x07\x01\x07\x04\x01\x01§:String = "$Appât";
      
      public static var §\b\x07\x07\x07\x03\x04\x06\x03\x06\x07\x02\x03\x03§:int = 1526 + -1076;
      
      public static var §\x03\x05\x06\x05\x02\x02\x07\x02\x04\x04\x06§:String = "et";
      
      public static var §\x03\x01\x05\x07\x03\x04\x02\x06\x01\x03\x05\x07§:String = "^";
      
      public static var §\x06\x03\x05\x02\x03\x03\x05\x01\x03\b\x07\b§:String = "nue";
      
      public static var §\x03\x04\x06\x03\x04\x06\x01\x02\x06\x04\x07\x06§:String = "Debug mode : off";
      
      public static var §\x03\x05\x04\x04\x02\x02\x04\x02\x06\x02\b\x04\x04§:String = "kamer";
      
      public static var §\x01\x02\x07\x02\b\b\b\x07\x02\x05\x01§:String = "test";
      
      public static var §\x06\x05\x04\x06\x01\x07\x04\x06\x05\x01\x04§:String = "\'>• <font color=\'#2EBA7E\'>[";
      
      public static var §\x01\x03\x05\x01\x01\x06\x03\x04\x04\x04\x03\x07\x07§:String = "FondCarte";
      
      public static var §\x06\x03\x06\x04\x05\x04\x04\b\x01\x05\x04\x03§:Number = (4730 + -4729) / (2040 + -1940);
      
      public static var §\x07\x03\x05\x04\x01\x02\x03\x05\x05\x07\b\x02\x01§:String = "<font face=\'";
      
      public static var §\b\x07\x07\x03\b\x05\b\x02\x01\b\x02§:int = 640 + 65102193;
      
      public static var §\x07\x04\x05\x02\x04\x01\x06\x07\x02\b\b\x07\x06§:String = "Server connected";
      
      public static var §\x03\x07\x02\x02\b\x01\x04\b\b\x01\x04\x04\x05§:String = "&";
      
      public static var §\x05\x02\x07\x02\x02\x01\x02\x04\x05\x05\x05\x03\x07§:String = "bg";
      
      public static var §\x06\x05\x02\b\x05\x07\b\x03\x01\x05\x05§:String = "y";
      
      public static var §\x01\x07\x04\x06\x05\x03\x05\x03\x05\x01\x03\x06\x07§:int = 740 + -710;
      
      public static var §\x04\x06\x02\x07\b\x06\x02\x07\x05\x01\x01\x02\x01§:int = 2231 + -1231;
      
      public static var §\x01\x07\x06\x02\x01\x01\x03\x01\x04\x02\x04§:String = "C_NOU";
      
      public static var §\x05\b\x06\x03\x06\x01\x01\x07\x04\x05\x03§:String = "activé";
      
      public function §\x05\x04\x01\x01\x07\x04\x07\x06\x06\x06\b\x07\x03§()
      {
         super();
      }
      
      public static function §\x05\x04\x03\x06\x04\x05\x05\x02\x07\x06\x03§() : int
      {
         return 9115 + -8860;
      }
      
      public static function §\x03\x07\x07\x03\x01\b\b\x04\x02\x06\x06§() : int
      {
         return 3977 + -3477;
      }
      
      public static function §\x02\b\x07\x04\x07\x05\x02\x06\x05\x07\x05\x05\x02§() : int
      {
         return 4445 + 15555;
      }
      
      public static function §\x02\b\x05\b\b\x01\x02\b\x02\x04\x02\x04\b§() : int
      {
         return 7664 + 12489683;
      }
      
      public static function §\x01\x06\x03\x02\x06\x04\x06\x05\x02\x03\x01\x01§() : int
      {
         return 5907 + 1596317;
      }
      
      public static function §\x03\x05\x04\x07\x05\x02\x04\x01\x04\x02\x05\x02\b§() : int
      {
         return 2859 + -2697;
      }
      
      public static function §\x02\x07\x01\x03\x06\x06\x02\b\x03\x06\x05\x07\x06§() : int
      {
         return 1256 + -1253;
      }
      
      public static function §\x04\x04\x06\x02\b\x02\x05\x06\x01\x07\x07§() : int
      {
         return 3499 + -3437;
      }
      
      public static function §\x06\x03\x01\x03\x05\x01\x04\x04\x05\b\x01\x02\x07§() : int
      {
         return 5137 + -4942;
      }
      
      public static function §\x01\x04\x05\x06\x06\b\x03\x02\b\x07\x06§() : int
      {
         return 1429 + -1245;
      }
      
      public static function §\x03\x06\x07\x03\x06\x07\x01\x04\x05\x06\x01\x02\x05§() : int
      {
         return 7494 + -7402;
      }
      
      public static function §\x02\x01\x01\b\x03\x04\x02\x07\x07\x07\x06§() : int
      {
         return 7068 + -6944;
      }
      
      public static function §\x05\x01\x07\x03\x05\x03\x04\x04\x05\x02\x04\x04§() : int
      {
         return 3700 + -3655;
      }
      
      public static function §\x05\x06\x03\x06\x01\x04\x03\x06\x05\x06\x05\x07§() : int
      {
         return 2599 + -2416;
      }
      
      public static function §\x03\b\x01\x03\x03\x06\x03\x03\x03\x01\x04\x05\x07§() : int
      {
         return 3439 + -3361;
      }
      
      public static function §\x03\x01\x03\x04\x02\x02\x07\x06\b\b\x03\x06\b§() : int
      {
         return 4161 + -4082;
      }
   }
}

