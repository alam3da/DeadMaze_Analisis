package
{
   public class §\x01\x03\x04\x07\x07\x04\x05\b\x06\x01\x07\x04§
   {
      
      public static var §\x03\x03\b\x07\x07\x04\b\x05\x01\b\x07\x05\x02§:String = "ajout objet : 5_0";
      
      public static var §\x06\x07\x02\x07\x02\x04\x01\x02\x07\x01\x02\x03§:String = "ajout objet : 5";
      
      public static var §\x05\x03\x03\x03\x05\x07\x07\x03\x01\x04\x05§:int = 7695 + -5223;
      
      public static var §\b\x05\x02\x03\x02\x07\x04\x07\x01\b\x06\b§:int = 5252 + -2995;
      
      public static var §\x01\x05\x04\x02\x01\x05\b\b\b\x01\x05\x04\b§:String = "election";
      
      public static var §\b\x04\x05\x02\x02\x04\x01\x07\b\x01\x02\x04§:String = "$ReglesDuJeu";
      
      public static var §\x05\x04\x04\x02\x07\x02\x03\x01\x02\x03\b\x07\x02§:int = 3652 + -1387;
      
      public static var §\x02\x02\x06\x05\x02\x06\x03\x01\x06\x07\x05\x03\x04§:Number = (8882 + -8804) / (44 + 56);
      
      public static var §\x06\x01\x05\x05\x03\x07\x06\x03\b\x04\x07\x05\x03§:String = "$Menu_6";
      
      public static var §\x02\x04\x03\x06\x03\x04\x04\x02\x07\x03\x04\b\x01§:int = 7781 + -6838;
      
      public static var §\x01\x05\x01\x05\x01\x06\x02\x05\x05\x04\x05\x04§:String = "citrons_petite.png";
      
      public static var §\x01\x06\x06\x05\b\x03\x04\b\x03\x01\x05\x05§:String = "myrtilles.png";
      
      public static var §\b\x07\x03\x04\x05\x02\x04\x07\x02\x07\x07\x02§:String = "x_transformice/x_interface/coeur_plein.png";
      
      public static var §\x06\x02\x03\b\x07\b\b\x02\x02\x06\b\x07\x04§:int = 5307 + -4137;
      
      public static var §\x06\x03\x01\x05\x05\x07\x03\x03\x07\x02\x02§:String = "Non";
      
      public static var §\b\x03\b\b\x01\x06\x04\x06\x05\x02\x03\x03§:String = "$ModeChamane_DescriptionSuperDifficile";
      
      public static var §\b\x07\x01\x04\b\x03\x04\x03\x04\x04\x02\x04§:String = "$ModeChamane_DescriptionDifficile";
      
      public static var §\b\x05\x06\x02\x05\x05\x04\x04\x06\x01\x07\x02§:int = 6317 + -5970;
      
      public static var §\x01\x03\x03\x03\x04\x02\x07\x01\x06\x03\x03\x03§:String = "<J>10<N>";
      
      public static var §\x01\x03\x07\x07\x05\x04\b\x01\x04\x01\x05\b\x07§:String = "$BV";
      
      public static var §\x05\x07\x03\x01\x02\x01\x06\x04\x07\b\x01\x06\x02§:String = "$C_SourisSauvéesSansComp";
      
      public static var §\x07\x04\x03\x03\x02\x01\x03\x02\b\x05\b§:String = "\n<BL> • ";
      
      public static var §\x06\x04\x04\x03\x04\x04\x07\x06\x04\x02\x03\x05\x07§:String = "<CH2>";
      
      public static var §\x07\b\x07\x04\b\x06\x01\x02\x07\x06\x05\x05\x05§:String = "»</V>";
      
      public static var §\x05\b\x04\x07\x04\b\x02\x01\x05\x04\x03§:String = "$Titre_En_Cours";
      
      public static var §\x01\x06\x07\b\x02\x02\x04\x01\b\x02\x04\x02§:String = "$texte.genreInconnu";
      
      public static var §\x04\x01\x07\x01\x06\x03\x01\x03\x06\x03\x01\x07\b§:int = 7690 + 53111;
      
      public static var §\b\x04\x05\x04\x07\x06\x02\x04\x01\b\x03\x06§:String = "« <a href=\'event:";
      
      public static var §\x04\x07\b\b\x07\x02\b\x04\x07\x01\x02\b\x04§:String = "<font color=\'#AA8066\'>★</font>";
      
      public static var §\x07\x01\x07\x04\x04\x04\x05\x04\x04\b\x06\x04\x04§:String = "x_i_81.png";
      
      public static var §\x04\x03\x06\x04\b\x03\x01\x05\x03\b\b§:String = "x_i_73.png";
      
      public static var §\x02\x04\x05\x05\x01\b\x06\x06\x03\x06\x07\b\x06§:String = "x_i_66.png";
      
      public static var §\x02\x07\x01\b\x03\x06\x01\x07\x02\x07\x04\x01§:String = "x_i_84.png";
      
      public static var §\x04\x02\x03\x05\x01\x05\x04\x03\x05\x03\x01§:String = "x_i_62.png";
      
      public static var §\x06\x03\b\x01\x03\x02\x05\x07\x04\x01\x04\x04§:String = "x_i_5.png";
      
      public static var §\x03\x02\x05\x07\x06\x02\b\x05\x07\x03\x06\b\x05§:String = "$Playlist";
      
      public static var §\x03\x01\x03\x03\x01\x06\x03\x02\x01\x06\x03\x05\x07§:String = "majPositionJoueur";
      
      public static var §\x05\x02\b\x06\x03\b\x03\x06\x03\b\x03\x04\x05§:String = "Grosse";
      
      public static var §\b\x03\x05\x01\x02\x06\x04\x06\x05\x02\x04\b§:String = "$Cri_";
      
      public static var §\x07\x06\x06\x04\x04\x07\x06\b\x02\x01\x01\x06\b§:String = "S2";
      
      public static var §\x05\x05\x02\x06\x04\x07\x01\x07\x07\x01\x03\x06\x01§:String = "cI";
      
      public static var §\x07\b\x04\x07\x07\x04\x04\x07\x05\b\x01\x04§:String = "SB";
      
      public static var §\x05\x01\x04\x06\x03\x02\x06\x02\x05\x06\x01\x03\x03§:String = "col";
      
      public static var §\x03\x04\x02\x03\x02\x04\x05\x05\x04\x03\x02\b\x03§:String = "x_transformice/x_badges/x_7.png";
      
      public static var §\x02\x01\x03\x01\x04\x06\x03\x04\b\x07\x01\x07§:String = "120,77";
      
      public static var §\b\x03\x03\x07\x01\b\x02\x07\x04\b\x06\x02§:String = "?c=";
      
      public static var §\x03\x04\x03\x01\x04\x05\x01\x02\x01\x07\x07§:String = "angDampAcc";
      
      public static var §\x01\x07\x03\x06\x02\x05\x07\x02\x04\x01\x06\x01\b§:String = "-b";
      
      public static var §\x01\x01\x04\b\b\x07\x04\x03\b\x05\x02\x02§:String = "http://www.transformice.com/images/peche.jpg";
      
      public static var §\x06\x03\b\x06\x07\x04\x03\x06\x07\x07\x05\x02§:String = "ouvertureOptionSelection";
      
      public static var §\b\x07\x04\x07\x04\x02\x01\b\x06\x01\x07\x01\x03§:String = "modeBouboum";
      
      public static var §\x07\x04\x01\b\x02\x01\x04\x02\x07\x06\x04\x01\x01§:String = "NomObjet";
      
      public static var §\x05\x04\b\x07\x04\x04\x04\x01\x01\x05\x02\x05§:String = "deesse.png";
      
      public static var §\x07\x03\x05\b\x05\x06\x04\x06\x05\x07\x07\x07\x04§:String = "$MagasinVisionnerVideoFraises";
      
      public static var §\x01\x03\x04\x07\x01\x02\x07\x03\b\x05\x03\x04§:String = "x_transformice/x_interface/roue.png";
      
      public static var §\b\x06\x01\x07\x01\x02\x05\x03\b\x04\x03\x05\x01§:String = "trampoline";
      
      public static var §\x04\x02\x06\x02\x02\x05\x05\x04\b\b\x03§:String = "ballon";
      
      public static var §\x07\x03\x06\b\b\b\x03\x04\x04\x01\x05\x07\x02§:String = "earrings";
      
      public static var §\x04\x02\x02\x06\x01\x02\x04\b\x02\x03\b§:String = "$PrixTotal";
      
      public static var §\x06\x05\x02\x07\x01\b\x03\x03\b\x02\x05\b\x07§:String = "$Changement_MDP_ok";
      
      public static var §\x05\x05\x07\b\x01\x07\x05\x04\x03\x02\x06§:String = "$Info_Validation_Email";
      
      public static var §\b\b\x05\x06\x06\x03\x03\x04\x07\x07\x06\x06§:String = "M_5.png";
      
      public static var §\x05\b\x07\x01\x01\x01\x05\x02\x04\b\x01§:String = "x_evenements/x_machine_3.jpg";
      
      public static var §\x06\x06\x07\x06\x04\b\x03\x03\x07\x07\x05\x07\x03§:String = "fc";
      
      public static var §\b\x02\x01\x01\x02\x05\x07\x02\x07\b\x05\b\x03§:String = "mss";
      
      public static var §\x07\b\b\x05\x04\x06\x06\x04\x05\x07\x03\b§:String = "<ROSE>• [$Moderation] MESSAGE</ROSE>";
      
      public static var §\x06\x02\x03\x07\x03\x05\x03\x01\x03\b\x07§:String = "$FX_sang_";
      
      public static var §\x02\x03\x05\x03\x07\x03\x01\x02\x06\x05\x02\x01\b§:String = "combat/griffe";
      
      public static var §\x04\x07\x07\x02\b\x06\x04\x03\x04\x05\x05\x06\x06§:String = "$FX_23";
      
      public static var §\x06\x06\b\b\x01\x04\x05\x04\x07\b\b\x03§:String = "_sort_1";
      
      public static var §\x01\x03\x07\x03\x02\x03\x03\x04\b\x02\x05\x01§:String = "x_deadmeat/x_interfaces/divers/statut_feu.png";
      
      public static var §\x06\x05\x01\x04\x07\x04\b\b\x05\x05\x06\x06§:String = "x_deadmeat/x_interfaces/divers/statut_dialogue_pnj.png";
      
      public static var §\b\x05\x01\x03\x05\x06\x04\x05\x06\x02\x03\x04\b§:String = "$AnimStatique_F";
      
      public static var §\x03\x03\b\x06\b\x03\x01\x05\x01\x04\x04§:String = "$AnimAttaque";
      
      public static var §\x06\x02\x01\x06\x05\x04\b\x06\x04\x04\b\x05§:String = "course";
      
      public static var §\x01\b\x06\x04\x02\x05\x04\x07\x06\x07\x01\x04§:String = "esquive";
      
      public static var §\x02\x02\x03\x06\x03\x01\x02\x01\x07\x03\x01\x05\x01§:String = "$ObjetLivreAuCampement";
      
      public static var §\x04\x05\x01\x03\x02\x04\b\x01\x05\x04\x01\x06\x05§:String = "x_deadmeat/x_interfaces/divers/b4.png";
      
      public static var §\x05\x07\x03\x02\b\x06\x06\x04\x04\x05\x01\x06\x01§:String = "dm";
      
      public static var §\x04\x06\x04\b\x02\x03\x05\x01\x05\x04\x05\x06§:String = "tenue_";
      
      public static var §\x04\x05\x01\x05\x06\x02\x04\b\x03\x02\x03\x02\x05§:String = "$action.";
      
      public static var §\x06\x03\x06\b\x03\x06\x04\x02\x04\x06\x01\b\x05§:String = "$ExperienceProfilDM";
      
      public static var §\x05\b\x07\x04\x02\b\x06\x02\x07\x07\x04§:String = "$PersonnageNonSauvegarde";
      
      public static var §\x07\b\x02\x01\x04\x07\x03\x01\x02\b\x02\x05\x02§:String = "$ConfirmationRecyclage";
      
      public static var §\x04\x05\b\x05\x03\x03\x03\x01\x06\x03\x01§:String = "$AvertissementRecyclageInutile";
      
      public static var §\x01\x07\x04\x04\x02\x03\b\x06\x04\x06\x04\x04\x04§:String = "<font size=\'16\'><D>";
      
      public static var §\x07\x01\x03\x07\x06\x04\x04\x07\x01\x04\x04§:String = "$NiveauSuperieur";
      
      public static var §\x04\x06\x05\x05\x04\x06\b\x03\x01\x05\x05§:String = "$EditeurEditerCarte";
      
      public static var §\x07\x06\x06\x03\x04\x06\x03\b\x05\x06\x04\x02\x02§:String = "$JePeuxPas";
      
      public static var §\x06\x06\x07\x05\x03\x06\x05\x07\x06\x05\x04§:String = "$ConfirmationAbandonProjetRecherche";
      
      public static var §\x07\x07\x07\x07\x04\x06\x02\x04\x06\x02\x04\x01§:String = "Documentation";
      
      public static var §\x05\x04\x05\x01\x07\x04\x02\x05\x07\x05\x05\x06\x02§:String = "replace_text";
      
      public static var §\x01\b\x06\x04\x01\x07\x06\x07\x01\x01\b§:String = "text_id";
      
      public static var §\x07\b\x01\x07\b\x02\x07\x03\x05\x06\x02§:String = "<O>delete";
      
      public static var §\x06\x02\x03\x01\x06\x07\x06\x07\x07\x03\x03\x01§:String = "famfamfam/bullet_arrow_up.png";
      
      public static var §\x06\x05\b\x04\x04\x03\x07\x01\x05\x06\x05§:String = "enable";
      
      public static var §\x05\x05\x02\x05\x06\x03\x04\x07\x05\x07\x03\x06\x01§:int = 1566 + -1394;
      
      public static var §\x05\x01\x04\x03\x01\x07\x04\x01\x06\x04\b\x05\x03§:String = "x_deadmeat/x_interfaces/expedition/defaite.png";
      
      public static var §\x03\x03\x05\b\x07\x05\x03\x06\x02\x02\x05\x05§:String = "$Expedition_NouvelleRechercheGroupe";
      
      public static var §\x02\x05\x01\x04\b\x04\x01\b\x07\x01\x05§:String = "$SC_Fuir";
      
      public static var §\x04\x05\x06\x07\x01\x06\x01\x07\x07\x01\x04§:int = 3968 + -291;
      
      public static var §\x05\x07\b\x02\x03\x01\x07\x06\x04\x04\b\x04§:String = "x_deadmeat/x_interfaces/divers/recomp2.png";
      
      public static var §\x02\x03\x06\x06\x02\x06\x05\x03\x01\x07\x05\x05\x07§:String = "$Groupe_AutresOptions";
      
      public static var §\x04\b\x04\x01\b\x06\x04\x04\x03\x06\x03§:String = "180 %";
      
      public static var §\x01\x07\x03\x01\x02\x04\b\x02\b\x04\x07\x07\x04§:String = "+10%";
      
      public static var §\b\x05\x01\x04\x03\b\x01\x01\x03\x03\x03\x04§:String = "0%";
      
      public static var §\x02\x06\x03\x02\x05\x06\x01\x03\b\x07\x07\x06\x06§:String = "$AideCuisine";
      
      public static var §\x06\x03\x06\b\x02\x06\x06\x05\b\x06\x05\x06§:String = "HENRY_COLLINS";
      
      public static var §\x05\x05\x03\x01\x04\x03\x01\x07\x01\x03\x03\x05\x06§:String = "LYNN_DURAND";
      
      public static var §\x06\x01\x05\x07\x03\x02\x01\x01\x04\b\x03\x05\x05§:String = "JARED_CRANE";
      
      public static var §\x06\x06\b\x01\x03\x01\x04\x01\x02\x02\x04§:String = "JOSH_NOLAN";
      
      public static var §\x04\x01\x02\x05\x03\x05\x05\x04\x07\x05\x05\x03§:int = 721 + 214;
      
      public static var §\x06\x05\x01\x04\x06\x04\x07\x07\x07\x06\x04\x07\x06§:String = "x_deadmeat/x_campement/fond2.png";
      
      public static var §\x07\x01\x04\x05\x07\x05\b\x03\x06\x06\x06\x02\x03§:String = "allumette";
      
      public static var §\x03\b\x07\x03\x05\b\x07\x04\x01\x02\x02\x02\x06§:String = "<V>[";
      
      public static var §\x04\x06\x07\x05\x07\x07\x03\x04\x05\x05\b\x01§:String = "\\*(.*)\\*";
      
      public static var §\x06\x04\x04\x02\x04\x06\x01\x01\x03\x05\b\x02\x01§:String = "$Boussole";
      
      public static var §\x07\x05\x04\x01\x02\x07\b\x03\b\b\x07\b\x05§:String = "clip";
      
      public static var §\x03\x02\x05\x03\x07\x06\x04\x03\x02\x06\x07\x01\x06§:String = "$JaugeSurvie";
      
      public static var §\x04\x04\b\x03\x02\x02\x02\x07\b\x04\x01§:String = "x_deadmeat/x_interfaces/divers/jauge-radioactivite.png";
      
      public static var §\x06\x05\x03\x05\x02\x05\x02\x03\x02\x01\b\x02\x06§:String = "\n• ";
      
      public static var §\x05\x01\x06\x06\x05\x02\x05\x07\x02\x01\x04\x02§:String = "$Commun";
      
      public static var §\x04\x02\x05\x01\x07\x07\x05\x05\x05\b\x03\b§:String = "$PasRecyclable";
      
      public static var §\x07\x03\x01\b\x04\x04\x05\x05\x03\x02\x04\x06\x01§:String = "$QualiteObjet_";
      
      public static var §\x05\b\x06\x06\b\x04\x06\x07\x07\x03\x02\x06§:String = "<font color=\'#FFA03B\'>";
      
      public static var §\b\x04\b\x03\b\x05\x04\x01\x05\x03\x04§:String = "x_deadmeat/comp/";
      
      public static var §\x03\x01\x03\x04\x07\x05\x02\b\x07\x07\x01\x02\x05§:String = "$TooltipExpedition";
      
      public static var §\x06\x07\x04\x01\x03\b\x02\x06\b\x01\x02§:String = "« ";
      
      public static var §\x06\x01\x04\x02\x07\x04\x05\x07\x05\x05\x07\x02§:String = "$CestVide";
      
      public static var §\x02\x01\x01\x01\x03\x06\x03\x04\x05\x05\x04§:String = "</I> »";
      
      public static var §\x07\x02\x06\x05\b\x02\x06\b\x02\x05\x01§:String = "/\\d+/\\s*";
      
      public static var §\x06\x07\b\x03\x04\x01\x04\x02\x06\x05\x06§:String = "teleportation";
      
      public static var §\x04\x03\x07\x02\b\b\x07\x07\x02\x05\x02\x02§:String = "Add monster path\n<N>(<V>CTRL</V> to remove)";
      
      public static var §\x05\x07\x04\x05\b\x02\x04\x02\x04\x06\x06§:String = "Light";
      
      public static var §\x01\x01\x01\x02\x05\x03\b\x07\x03\x05\x05§:String = "$EditeurDefinirRadioactiviteModEnv";
      
      public static var §\x04\x06\x03\x03\x05\x04\x05\x04\b\x01\x04\x03§:String = "$EditeurIdTraduction";
      
      public static var §\x07\x01\x03\x03\x03\x03\x02\x05\x01\x07\b\x03§:String = "$EditeurConfirmerSuppressionTrad";
      
      public static var §\x03\b\b\b\x07\x03\x03\x07\x05\x01\x04§:String = "$langue.bulgare";
      
      public static var §\x07\x03\x02\x07\x05\x01\x06\x06\b\x07\x03\x01§:Number = (2751 + -2736) / (3912 + -3812);
      
      public static var §\b\x01\x06\x03\x06\b\x01\x07\x05\x06\x05\b\x02§:String = "map_celousco_";
      
      public static var §\x05\x04\x06\x01\x03\x04\x04\x05\x06\x02\x06\x07\x07§:String = "A4F33A72-E71B-44EC-B71E-A5618DCE2BAF";
      
      public static var §\x06\b\x01\x06\x07\x06\x02\x05\x01\x02\x07§:String = "$Groupe_Inviter";
      
      public static var §\x01\x05\b\x04\b\x05\x03\x05\x03\x05\x04\x03\x01§:String = "focusIn";
      
      public static var §\x03\x01\x06\x06\x06\x01\x05\x05\x05\x01\x06\x01§:String = "$PC_PAF";
      
      public static var §\x03\x07\x06\x05\x02\x07\x04\x02\b\b\x02\x01§:String = "$PC_AIE";
      
      public static var §\x01\x06\x04\x06\x05\x02\x06\x04\x04\x05\b§:String = "orderToFront";
      
      public static var §\x02\b\x07\x02\x02\x02\x05\x02\x04\x05\x03\x07\x06§:String = "nativeApplication";
      
      public static var §\x07\x01\x06\x02\x07\x06\x05\x04\x06\x03\x04§:String = "$Action_Sprint";
      
      public static var §\x06\x06\x04\x07\x07\x03\b\b\b\x04\b\x03\x05§:String = "$CategorieAction_Divers";
      
      public static var §\x03\x02\x05\x02\x01\x04\x04\x02\x07\x02\x02\x04§:String = "$CategorieAction_CompetencesDM";
      
      public static var §\x05\x04\x07\x07\x01\x02\x07\b\x07\x02\x07\x01\x01§:String = ".texte";
      
      public static var §\x03\x01\x06\x03\b\x03\x01\x07\x04\x04\x06§:String = "$replique.";
      
      public static var §\x06\x03\x04\b\x06\x03\x04\x01\x06\x04\x03\x01\x06§:String = "CuisseG_1";
      
      public static var §\x06\x07\x07\b\b\x07\x02\b\x07\x04\x07\x03§:String = "Oeil3_1";
      
      public static var §\b\b\x06\x05\x02\x01\x04\x05\x02\x02\x05\x05§:String = "behindzero";
      
      public static var §\b\x01\x05\x04\x04\b\x02\x04\x01\x03\x01\x04\x01§:String = "Module 801";
      
      public static var §\x03\b\b\x02\x04\b\x03\b\x01\x02\x04\x07§:String = "AnimAttaque";
      
      public static var §\x07\x06\x02\x07\x05\b\x05\x05\x01\x04\x03§:String = "10;0,0";
      
      public static var §\x05\x03\x05\x04\x07\b\x02\b\x03\x06\x07\x02\x03§:String = "AnimHi5_2";
      
      public static var §\x05\x06\x01\x02\x03\x05\x04\x05\x04\x06\x03\x01§:String = "msg";
      
      public static var §\x02\x05\x06\b\x03\x04\x03\x01\x01\x06\x01\x05§:String = "Tribulle 2 : ";
      
      public static var §\x04\x07\b\x01\x07\x06\x04\x07\x02\b\x02\x04§:String = "ignorerInvTribu";
      
      public static var §\x06\x07\b\x07\x05\x07\b\x02\b\x03\x01\x07\x06§:String = "MT,";
      
      public static var §\b\x01\b\x04\b\x03\x05\b\x04\x01\x05\x04\b§:String = "$InvTribu_InvitationRecue";
      
      public static var §\x02\x01\x02\x02\x03\x06\x06\x07\x04\b\b\b§:String = "$Nouveau_Grade";
      
      public static var §\b\x01\x05\x05\x03\x01\x05\b\x05\x04\x06\b\x07§:String = "$Message_Voleuse";
      
      public static var §\x06\x02\x03\x06\x05\x05\x05\x05\x07\x05\x07\x07§:String = "$Info_Titre";
      
      public static var §\x03\x05\x06\x07\x07\x06\x05\x01\x04\x07\x05§:int = 4054 + 7747;
      
      public static var §\x01\x07\x03\x07\x04\x02\x06\x03\x01\b\x07\x06\x05§:int = 1329 + 4226;
      
      public static var §\x02\x06\x04\x02\x05\b\x01\b\x03\x06\b\x07§:String = "$chat.message.erreurMute";
      
      public static var §\x01\x02\x02\x01\x03\x05\x04\b\x03\x05\x05\x03\x02§:String = "$popup.mariage.demandeEnCours";
      
      public static var §\x07\x06\x02\x03\x04\x03\b\b\x02\x01\x06\x07§:String = "$listeNoire.ajoutImpossible";
      
      public static var §\x02\b\x05\x06\x03\x06\x01\x04\x03\x03\x04\x05\x07§:String = "$InvTribu_AnnulationRecue";
      
      public static var §\x07\b\x07\x06\x02\x03\x07\x02\x06\b\x06\x03§:String = "$popup.tribu.exclusion.contenu";
      
      public static var §\b\x01\b\x07\x04\x04\x03\x07\x02\x05\x07\x06\x01§:String = "identifie";
      
      public static var §\x05\x05\x02\x01\x04\x03\x05\b\x04\x06\x04§:Number = (1131 + -1033) / (9825 + -9725);
      
      public static var §\x06\x01\x04\x06\x04\x03\b\x05\x06\x05\x02\x01\x03§:String = "://www.transformice.com/langues/dm-";
      
      public static var §\b\x01\b\x04\x02\x06\x01\x06\x04\x02\x02\x01§:String = "finChargementLecteur";
      
      public static var §\x02\x04\x04\x05\x01\b\x07\x07\x05\x06\x03\x05§:String = "Youtube.API.changerTaille";
      
      public static var §\x05\x05\x06\x07\x05\x02\b\x03\x03\x07\x07§:String = "Български";
      
      public static var §\x06\x01\x05\x04\x03\x02\x02\x07\b\x03\x07\b\x04§:String = "lt";
      
      public static var §\x06\x04\x02\x04\x07\x05\x04\x01\x04\x04\x06\x03\x01§:String = "fi";
      
      public static var §\x04\x07\x07\b\x01\x06\x06\x03\x02\x01\x01\x04§:String = "jp";
      
      public static var §\x01\x07\x02\x03\x05\x04\x06\x02\x07\x07\x06\x01\x05§:String = "$I_FondTitre";
      
      public static var §\x05\x01\x03\x05\x02\x05\x02\x05\b\b\x02\x07§:String = "onAuthFB";
      
      public static var §\x01\x05\x01\x02\x05\x01\x07\x03\x04\x03\b\x01§:String = "RESPONSE_PURCHASE_SUCCESS";
      
      public static var §\x06\x02\x02\x04\x05\x03\x07\x07\x03\b\x07\x06\x06§:String = "getUsername";
      
      public static var §\x07\x03\x05\x07\x04\x02\x05\x06\x01\x07\x07\x02§:String = "callback";
      
      public static var §\b\b\x06\x07\x05\b\x02\x02\x06\x07\b\x05§:String = "touchEnd";
      
      public static var §\b\x01\x06\x07\x02\b\x03\x03\x01\x05\x06\x07\x03§:String = "date";
      
      public static var §\x02\x05\x01\x07\x06\x07\x02\x07\x07\x05\x07§:String = "$ParrainageForteresse";
      
      public static var §\b\x07\x02\x05\x05\x01\x06\x04\b\x04\x02§:String = "$MettreChamane";
      
      public static var §\x03\x02\b\x07\x04\x02\x04\x02\x07\x03\x06§:String = "Erreur de sécurité.";
      
      public static var §\x02\x06\x03\x03\x01\x05\x05\x01\x01\x03\x06\x04§:String = "Images";
      
      public static var §\x03\x02\x02\x03\x07\x03\b\x01\x04\x01\x05\b§:String = "browseForOpen";
      
      public static var §\x02\x03\x05\b\x07\x01\x06\x01\x05\x04\x05§:String = "close";
      
      public static var §\x01\x02\x01\x04\x05\x02\b\x03\x01\x03\x06\x03\x01§:String = "readBytes";
      
      public static var §\x07\x02\x01\x07\x02\x06\x02\x02\x02\x02\x02\b§:String = "exitFrame";
      
      public static var §\x04\x05\b\x05\x06\x03\x06\x02\x01\x06\x03\x06\x07§:String = "$popup.tribu.changerCodeMaison.contenu";
      
      public static var §\b\b\x02\x04\b\x01\x05\x02\x02\x03\x03\b§:String = "$historique.tribu.membreInvite";
      
      public static var §\b\x05\x03\x04\x06\x07\x02\x02\x03\x05\x03§:String = "tribe-forum?tr=";
      
      public static var §\x05\x01\x07\x03\b\x07\x03\b\x01\b\x05§:String = "x_tribulle2/";
      
      public static var §\x06\x02\x05\x07\b\x05\x03\b\x03\x07\x07\x07§:String = "message-accueil.png";
      
      public static var §\x02\x02\x03\x01\x07\x05\b\b\x02\x06\x02\b\x03§:String = "$interface.tribu.bouton.rejoindre";
      
      public static var §\x02\x06\x04\b\b\b\x02\x06\x04\b\x05\x04\x05§:String = "x_tribulle2/liste-ennemis.png";
      
      public static var §\b\x02\x01\x06\x02\x01\x06\x02\x02\x02\x06\x01§:String = "x_tribulle2/ajouter-ami.png";
      
      public static var §\x07\x03\x01\b\x02\x01\x07\x04\x05\x02\x04§:String = "$bouton.envoyerMessage";
      
      public static var §\x07\x02\x04\x02\x02\b\x03\x01\b\x01\x06\x06§:String = "$menu.contextuel.joueur.ajouterAmi";
      
      public static var §\x01\x01\x03\x07\x01\x02\x05\x05\b\x02\b\x02§:String = "$menu.contextuel.joueur.tribu";
      
      public static var §\b\b\x03\x04\x03\x03\x06\x02\x05\x05\b\x01§:String = "$Envoyer";
      
      public static var §\x02\x06\x02\x04\b\x01\x04\x05\x04\x07\x05\x07§:String = "$Menu_4";
      
      public static var §\x07\x02\x01\x03\x01\x03\x04\x05\x06\x02\x01§:String = "$Message_Salon";
      
      public static var §\x04\b\x03\x07\x01\x01\x04\x07\x01\x04\x07\x07§:String = " <CH>";
      
      public static var §\x06\x02\b\x04\x04\x06\b\x01\x02\x04\x07\x07§:String = "$S_Prems";
      
      public static var §\x01\x04\x04\x02\x07\x03\x03\x01\x01\x01\x03§:Number = (4587 + -4282) / (3014 + -3004);
      
      public static var §\x03\x02\x04\x02\x03\x02\x04\x01\x02\b\x02\x04\x05§:String = "#_#_Canal_General";
      
      public static var §\x01\x01\x06\x02\x04\x07\b\x04\x02\x04\x07\x05\x07§:String = "$ChuchoImpossibleSilenceEtoile";
      
      public static var §\x04\x03\x01\x01\x03\b\x04\x02\x05\x04\x03\x04§:String = "$chat.message.rejoindreCanal";
      
      public static var §\x05\x06\x01\b\x07\x02\x05\x03\x02\x04\x05\x03\x03§:String = "$chat.message.rejoindreCanalTribu";
      
      public static var §\x02\x02\x07\b\x04\x03\x02\x05\x03\x02\x02§:String = "survivor";
      
      public static var §\x05\x06\x06\x05\x02\x03\x07\x05\x05\x07\x05\x04\x06§:String = "x_transformice/x_interface/armorgames/armor.png";
      
      public static var §\x02\x06\x07\b\x07\x05\x07\b\x04\x03\x03\x06§:String = "http://www.nekodancer.com/";
      
      public static var §\x01\x02\x05\x06\x05\b\x07\x06\x02\x03\x01\x06\x05§:int = 2913 + -2481;
      
      public static var §\b\b\x07\x04\x02\x07\x07\x02\x03\x06\x06\x03\x03§:String = "$LoginForteresse";
      
      public static var §\x01\b\x04\x05\x06\x03\x01\x02\x04\x03\b\x05\b§:String = "$FormatPseudo";
      
      public static var §\b\x05\x02\x05\x07\x03\x02\x07\x04\x06\x05\x02\x04§:String = "$pseudo_premiere_lettre";
      
      public static var §\b\x01\b\x05\x06\x02\x03\x02\x07\x02\x01§:int = 5080 + -4281;
      
      public static var §\x02\x02\x03\x06\x07\x07\x03\x04\x04\x05\x07\x06\x07§:String = "$authentification.erreur.7";
      
      public static var §\x04\x05\x06\x07\x02\x01\x04\x02\x02\x06\x05\x03§:String = "$Objet_44";
      
      public static var §\x01\x07\b\x03\x04\x07\x05\x07\x04\b\x04\b§:String = "$aventuresSucces";
      
      public static var §\x04\x04\x02\x03\x07\x01\x04\x06\x01\x01\b\x01§:String = "ibanH";
      
      public static var §\x03\x07\x01\x06\x02\x03\x01\x02\x02\b\x06\x07\b§:String = "l";
      
      public static var §\x02\x06\x01\x01\x05\x07\x07\x01\x04\x06\x01\x04§:String = "nar";
      
      public static var §\x05\b\x01\x03\x07\b\x07\x07\x03\x04\x01§:String = "o";
      
      public static var §\b\b\x05\x03\x07\x04\x04\x01\x04\x04\x04\x04§:String = "<G>(Muted for ";
      
      public static var §\b\x02\x02\x02\x04\x01\x06\x07\x01\b\x02\b\x03§:String = "</a>";
      
      public static var §\b\x03\x06\x07\x07\x05\x06\x02\x04\x06\x06\x03§:String = "$RotationCartes";
      
      public static var §\x01\x01\x05\x04\x03\x04\x03\x01\x06\x05\x01\x02\b§:String = " %";
      
      public static var §\x07\x02\x02\x07\x03\x03\x04\x05\x03\x01\x05\x05§:String = "<font color=\'#C2C2DA\'>";
      
      public static var §\b\x07\b\x06\x07\x05\x07\x03\x07\x06\x04\x06§:int = 9366 + -9126;
      
      public static var §\x03\b\x07\x04\x06\x04\x04\x01\x01\x06\x06\x07\x07§:String = "Bootcamp";
      
      public static var §\x04\b\x04\b\x07\b\x02\x04\x05\x04\x04\x04§:String = "x_transformice/x_minijeux/x_normal.jpg";
      
      public static var §\x05\x07\x03\b\x02\x06\b\x01\x06\x02\x03\b\x06§:String = "tc";
      
      public static var §\x02\x01\x06\x06\b\x07\x06\x07\x07\x02\x03\x05\b§:String = "Affichage des erreurs de chargement d\'images : ";
      
      public static var §\x02\x06\x07\b\x03\x04\x06\x07\x06\x02\x03\x05\x02§:String = "<font size=\'10\' color=\'#6C77C0\'><textformat leftmargin=\'20\' rightmargin=\'20\'>$1</textformat></font>";
      
      public static var §\x05\x06\x01\x03\x07\x01\x05\x07\x06\x05\x04\x06\x07§:String = "gm";
      
      public static var §\x01\x03\x01\b\b\x05\x07\x02\x07\x07\x04\x02\x02§:String = "\r\r";
      
      public static var §\x07\b\x02\x05\x03\x05\x02\x06\x03\b\x03§:String = "bl";
      
      public static var §\x02\b\x04\x04\x02\x03\x04\x03\b\x07\x01§:String = "<R>FX <D>";
      
      public static var §\x01\x03\x05\b\x05\x01\b\x04\x01\x05\x05\x04\x06§:int = 16 + 4484;
      
      public static var §\x05\x02\x03\x05\x01\x05\x07\x06\x01\x02\x05\x03\x05§:String = "`";
      
      public static var §\x02\x04\x03\x04\x01\b\x01\x06\x02\x07\b§:String = "I";
      
      public static var §\x07\x06\b\x02\x02\x04\x02\x01\x05\x01\b\b§:String = "Control";
      
      public static var §\x03\x05\x04\x07\x06\x05\x07\x06\x06\x03\x03\x07§:String = "\n<R>";
      
      public static var §\x03\x05\b\x01\x05\x01\x07\x07\x02\x01\x07\x07§:String = "$RaccourciClavierPourAction";
      
      public static var §\x02\b\x06\x05\x06\b\b\x03\x05\x04\x05§:Number = (4554 + -4548) / (4566 + -4556);
      
      public static var §\x03\x05\b\x01\x03\x03\x04\x07\x05\x07\x06§:int = 4586 + -4378;
      
      public static var §\x03\x04\b\x01\x07\b\x04\x01\x02\x06\x01\b\x02§:int = 7708 + -7581;
      
      public static var §\x05\x04\x04\x05\x04\x03\x03\x04\x02\x05\x02\x07\x05§:int = 2509 + -2383;
      
      public static var §\x05\x05\x05\x04\x01\x04\x06\x05\b\x02\b§:int = 9703 + -9628;
      
      public static var §\x03\x03\x06\x07\b\x06\x04\x01\x05\x05\x03\x02§:int = 1994 + -1955;
      
      public static var §\x04\x06\x05\x04\b\x01\x07\x03\x04\b\x05\x07§:int = 1265 + -1151;
      
      public static var §\x05\x01\x04\x06\b\x01\x06\x01\x06\x01\x01\x05\x03§:int = 9170 + -8897;
      
      public static var §\x04\b\x04\x06\x07\x03\x03\x03\b\x03\b\x05\x05§:int = 8196 + -7985;
      
      public static var §\x03\x07\x06\x05\x03\x01\b\b\x05\x04\x01\x01§:int = 9645 + -9374;
      
      public static var §\b\b\x05\b\x05\x06\x04\x05\x06\x02\x01§:String = "$P_";
      
      public static var §\x03\x02\x07\x06\x03\x01\b\x01\x06\x04\x03§:String = " souris.";
      
      public static var §\x01\x05\x05\x05\x07\x06\x07\x07\x07\x07\x01\x05§:String = "</V>";
      
      public static var §\x07\x03\x06\x04\x02\x07\x02\x02\x06\b\b\x06\x04§:String = "dm-fraises";
      
      public static var §\x07\x04\x06\x01\x06\x02\x05\x05\b\x02\x01§:int = 1839 + -1836;
      
      public static var §\x04\b\x06\b\x01\x03\x02\x04\b\x04\x05§:String = "\nVitesse";
      
      public static var §\x01\x01\b\x02\x03\x01\x04\x06\x06\x04\x07§:String = "krE^`hLmqflkp";
      
      public static var §\x07\b\x02\x04\x04\x02\b\x07\x07\x05\x03§:String = "stageWidth";
      
      public static var §\x01\x05\x05\b\x07\x03\x07\x01\b\x04\b\x05§:String = "inline";
      
      public static var §\x03\x07\x07\x06\x05\x01\x03\b\x03\x02\x04\x02§:String = "a:hover";
      
      public static var §\x03\x06\x01\x07\x01\x07\x03\x07\x03\x01\x06\x01\x05§:String = "right";
      
      public static var §\x04\b\x01\b\x03\x05\x03\x03\x05\x05\x06\x02§:String = "#FEB1FC";
      
      public static var §\x04\x02\x07\x06\x02\x03\x01\x06\x05\x02\b\x07\b§:String = "VI";
      
      public static var §\x05\x06\x04\b\x05\x07\x01\x06\x05\x05\x03\x03§:String = "#F79337";
      
      public static var §\b\x01\x02\b\x04\x07\x01\x02\x05\x04\b\x07\x06§:String = "#009D9D";
      
      public static var §\x04\b\x05\x05\x01\x04\x03\b\x04\x03\x06§:String = "R";
      
      public static var §\x05\x06\x04\x01\x07\x07\x04\x02\b\x07\x07\x04§:String = "BV";
      
      public static var §\x01\x04\x05\x07\b\x02\x05\x02\x06\x06\x02§:int = 7815 + -7005;
      
      public static var §\x03\x07\b\x05\x02\x03\x02\x02\x07\b\x06§:String = "Vérifications diverses";
      
      public static var §\x06\b\x03\x06\b\x04\x07\b\b\x01\x02§:String = "$AFK";
      
      public static var §\x06\x05\b\x04\x07\x04\x04\x05\x04\x01\x03\x02\x04§:String = "$Glacon";
      
      public static var §\x04\x02\x04\x07\b\b\x07\x04\x06\b\x02\x04\x05§:String = ":";
      
      public static var §\x04\x04\x05\x04\x04\x04\x07\x03\x01\x03\x07\x06§:String = "$OC_MoteurVert1";
      
      public static var §\x04\x01\x05\x05\x04\x01\x05\x03\x04\x02\x07\x04\x04§:String = "$Balle";
      
      public static var §\x01\x07\x06\x05\b\x03\x01\x02\x03\x02\x07\x06§:int = 8153 + -7705;
      
      public static var §\x01\x01\x01\x04\x07\x05\x05\x01\x07\x02\x02\x07\x04§:String = "  - ";
      
      public static var §\x06\x03\x01\x04\b\x02\x04\x02\b\x01\x03\x06\x06§:String = "<J>Clavier français.";
      
      public static var §\x01\x01\x05\x03\x07\x02\x05\x06\x01\b\x02\b§:String = "sala";
      
      public static var §\x06\x01\x06\x03\x06\b\x03\x05\x02\b\x04\x02§:String = "aide";
      
      public static var §\x07\x06\x03\x07\x07\x01\x01\x05\x05\x06\x04\x05§:String = "x_imj";
      
      public static var §\x04\x02\x07\x05\x02\x07\x07\x04\x01\x06\b§:String = "error";
      
      public static var §\x04\x04\x01\x07\x03\x03\x02\x05\b\b\x05§:String = "$Pas_De_Fromage";
      
      public static var §\b\x07\x04\x03\x05\x04\x05\x04\x03\x02\x07\x03\x05§:String = "$SourisIci";
      
      public static var §\x01\x02\x03\x06\x07\x06\x02\x05\x03\x06\b\x05§:int = 7453 + -7405;
      
      public static var §\x02\x01\x04\b\x06\x05\b\b\x05\x06\x05§:String = "WIN";
      
      public static var §\x07\x02\x05\x05\b\x04\x01\x07\x06\b\x04\x06§:String = "UTTutSG";
      
      public static var §\x07\x07\x06\x04\x04\x07\x03\x05\b\x01\x05\x02\x07§:int = 1653 + -1646;
      
      public static var §\x06\x06\x02\x01\x03\x06\x06\x01\x04\x06\x05§:String = "Kongregate WEB";
      
      public static var §\x03\x07\x07\x03\x06\x03\b\x07\x03\x07\x02\x02\x06§:int = 2488 + 12;
      
      public static var §\x06\x07\x04\x01\x01\x03\x02\x06\x05\x07\b§:String = "x_mj";
      
      public static var §\x06\x05\x05\x05\x01\x02\x01\x01\x04\x06\b§:String = "hasEventListener";
      
      public function §\x01\x03\x04\x07\x07\x04\x05\b\x06\x01\x07\x04§()
      {
         super();
      }
      
      public static function §\x02\x02\x01\x04\x07\x02\x06\b\x02\x03\x04\b\x05§() : int
      {
         return 2050 + 6178;
      }
      
      public static function §\x06\x02\x05\x04\x03\x01\x03\x07\x04\x04\x03§() : int
      {
         return 3105 + -2592;
      }
      
      public static function §\x07\x02\x07\x02\x04\x03\x07\x04\x07\x01\x04\x02§() : int
      {
         return 921 + -815;
      }
      
      public static function §\x05\x06\x04\x05\b\x04\x03\x07\x06\x07\x04\x07§() : int
      {
         return 4379 + -4290;
      }
      
      public static function §\x05\x04\x04\x07\x06\x07\x04\x07\b\b\x02\b\x01§() : int
      {
         return 2554 + -2417;
      }
      
      public static function §\b\x06\x02\x03\x04\x02\x03\x07\x04\x03\x01§() : int
      {
         return 3365 + -3210;
      }
      
      public static function §\x05\x03\x03\b\x04\x01\x01\x05\x01\x01\x03\x04§() : int
      {
         return 4820 + -4790;
      }
      
      public static function §\x02\x04\x05\x02\b\x02\x07\x04\x02\x02\b\x04§() : int
      {
         return 6113 + -6065;
      }
      
      public static function §\x02\b\x02\x01\x07\b\x05\x01\b\x03\x01\x02§() : int
      {
         return 7016 + -6878;
      }
      
      public static function §\x04\x04\x02\x05\x04\x07\b\x02\b\x01\x07\x05§() : int
      {
         return 2394 + -2214;
      }
      
      public static function §\x06\x01\x01\x07\x05\x01\x03\x02\x05\x07\x07\x06§() : int
      {
         return 4276 + -4132;
      }
      
      public static function §\x02\x05\b\x04\x05\x06\b\x03\x02\x05\x03§() : int
      {
         return 1092 + -993;
      }
      
      public static function §\b\x07\x07\x01\x04\x01\x01\x07\b\x07\x01§() : int
      {
         return 913 + -720;
      }
      
      public static function §\x07\x01\x02\x05\x02\x05\b\x04\x06\x06\b§() : int
      {
         return 9767 + -9743;
      }
      
      public static function §\x01\x07\x07\x01\x02\x02\x05\x07\x05\x07\x01\x02§() : int
      {
         return 2996 + -2811;
      }
      
      public static function §\x07\x02\x06\x04\x05\x06\x02\x05\x07\x03\x06§() : int
      {
         return 2389 + -2374;
      }
      
      public static function §\x02\x04\x01\x01\x04\x04\x02\x03\x05\x06\x07§() : int
      {
         return 2814 + -2638;
      }
      
      public static function §\x07\x05\x03\x01\x07\x03\x04\b\b\x06\b\x05\x07§() : int
      {
         return 7285 + -7278;
      }
   }
}

