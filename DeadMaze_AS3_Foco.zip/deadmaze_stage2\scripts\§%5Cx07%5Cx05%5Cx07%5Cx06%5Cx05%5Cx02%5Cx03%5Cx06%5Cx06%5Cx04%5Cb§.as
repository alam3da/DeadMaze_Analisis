package
{
   public class §\x07\x05\x07\x06\x05\x02\x03\x06\x06\x04\b§
   {
      
      public static var §\x05\x07\x04\x06\x07\x05\b\x07\x02\x02\x04\x05\x07§:String = "ajout objet : 5_2";
      
      public static var §\b\x02\x05\b\x05\x02\x04\x05\x06\x05\x05\x02\x07§:String = "$Oeuf";
      
      public static var §\x04\x03\b\x07\x07\x04\x03\x06\x07\x02\x02\x05\x07§:String = "$Horloge";
      
      public static var §\b\x04\x05\x02\x02\b\x07\x07\x03\x05\b\x03\x05§:String = "x_transformice/x_interface/4.jpg";
      
      public static var §\x05\x05\x02\x06\x07\b\x03\x06\x06\x07\x07\x03§:String = " <BL>";
      
      public static var §\x07\x03\x01\x04\x02\x04\x04\x07\x06\b\x03§:String = "$C_Competence";
      
      public static var §\x05\x03\x05\x07\x02\x07\x01\x07\x06\x07\x04§:String = "http://transformice-adventures.com";
      
      public static var §\x01\x05\b\x04\b\x07\x05\x05\x02\x03\b\x06\x04§:String = "x_transformice/x_evt/x_evt_16/JKESOLKA/tardis.png";
      
      public static var §\x05\x02\x01\x02\x05\x04\x03\x06\x01\x02\x07\x06\x06§:Number = (98 + -16) / (3362 + -3262);
      
      public static var §\x02\x01\x07\x04\x07\x02\x04\x07\x07\x01\x05\x04\x03§:Number = (2973 + -2767) / (6950 + -6850);
      
      public static var §\x03\x03\x07\x04\x01\b\x01\b\x03\x01\x02§:String = "chapeau_petite.png";
      
      public static var §\x06\x05\x04\x02\x07\x06\x02\x05\x07\x07\x03\x02\x05§:String = "raisins.png";
      
      public static var §\x05\b\x03\x06\x05\x02\x05\x04\b\x06\x07\x07\x05§:int = 54 + 2158;
      
      public static var §\x03\b\x02\x03\x06\x03\x05\b\x03\x05\x01§:String = "$EquiperMagasin";
      
      public static var §\x04\x01\x07\b\x04\x04\x03\x03\x03\x03\x03§:String = "n\'est plus";
      
      public static var §\x07\x06\x05\b\x02\x06\x01\x04\x03\x05\x05\x02\x06§:String = "infoshop";
      
      public static var §\x06\x02\x01\x04\x07\x01\x03\x04\b\x05\x03\x03§:int = 9073 + -6495;
      
      public static var §\x07\x05\x02\x04\x03\x07\x03\x04\x03\b\x05\x06\x07§:String = "$ModeSansComp";
      
      public static var §\x05\b\x04\x05\b\x01\x03\x06\x06\x07\x03§:String = "selfie_";
      
      public static var §\x03\x07\x01\x01\x05\x06\x06\x07\x01\x06\x05\x06\x02§:String = "$Inventaire_FinEchange";
      
      public static var §\x07\x01\x05\x05\x06\x02\x06\b\x07\x07\x05\x01§:String = "</V></BL>";
      
      public static var §\b\x05\x02\x01\x03\x03\x06\x06\x07\x05\x04§:String = "♂ ";
      
      public static var §\x02\x06\x06\x03\x04\b\x06\x05\b\x01\x01§:String = "tfmnews_(\\d+)";
      
      public static var §\b\x06\x06\b\x02\x04\x06\b\x03\x04\x03\x01\x02§:int = 1700 + 348;
      
      public static var §\x02\x04\x05\x07\x02\b\x04\x02\x04\x02\x07\x01§:String = "aie";
      
      public static var §\x04\x06\x03\x03\x02\x02\x01\x05\b\x05\x03§:String = "nosync";
      
      public static var §\x04\x02\x01\x02\x04\x03\x06\b\x07\b\x01\x02\x04§:String = "\n    <G>[";
      
      public static var §\b\b\x03\x04\x01\x03\b\x01\x06\x07\x07\x02\x01§:String = "<font size=\'60\' color=\'#FFB370\'>";
      
      public static var §\x03\x06\x07\x01\x07\x07\x03\x04\x06\b\x05§:String = "$GetSteam3";
      
      public static var §\x06\x04\x07\x02\x02\x07\x07\b\b\x01\b\x05\b§:String = "\' color=\'#FFF3CE\'>";
      
      public static var §\x03\x05\x03\b\x07\b\x07\x05\x03\x05\x07\x06§:String = "modeForteresse";
      
      public static var §\x05\b\x06\x04\x01\x06\b\x04\x04\x03\x03\x01§:String = "SalonCible";
      
      public static var §\x01\b\x06\x04\x03\x01\x01\x05\x05\x05\x05\x01§:String = "Flash version : ";
      
      public static var §\x07\x07\b\x05\x07\x04\x01\x03\x06\b\x02§:int = 2208 + -1871;
      
      public static var §\x02\x01\x02\x05\x07\x05\x06\x02\x04\x01\b§:String = "x_transformice/x_interface/check-";
      
      public static var §\x07\x07\x04\x01\x06\x06\x03\x03\b\x04\x04\x04\x07§:String = "wig";
      
      public static var §\x03\x05\x01\x02\x06\x04\x04\x05\b\x07\x03\x04§:String = "x_souris";
      
      public static var §\x02\b\b\x03\b\x07\b\x06\b\x07\x07\x07\x03§:int = 8358 + -7577;
      
      public static var §\x02\x07\b\x03\b\x04\x02\x06\b\x07\x02\x07\x04§:String = "$DescriptifAchatTenueComplete";
      
      public static var §\x03\x03\x06\x07\x02\x05\x03\x05\x04\x03\x07\x06\x07§:String = "$AllerSurSite";
      
      public static var §\x06\x05\x04\b\x04\x06\x06\x03\x06\x02\x01\x02§:String = "$Validation_Email_Titre";
      
      public static var §\x04\x05\x04\x02\x04\x04\x01\x06\x05\x06\x05\x07§:String = "$Cadeau";
      
      public static var §\x05\b\x04\x01\x02\b\x04\x03\b\x06\x02\b§:String = "_Po";
      
      public static var §\x07\x05\x03\x02\x06\x05\x07\x07\b\x03\x05\b§:String = "_Bar Halloween";
      
      public static var §\x04\x02\x04\x04\x04\x04\b\x07\x01\x05\x05§:String = "ms";
      
      public static var §\x05\x01\b\x04\x02\x04\x01\b\b\x01\x05\x06\x03§:String = " - <D>";
      
      public static var §\x06\x02\x05\x01\x04\x05\x01\x07\x07\x01\b§:String = "$FX_42";
      
      public static var §\b\x06\b\x03\x03\x06\x04\x05\x01\x07\b§:String = "AnimLancer";
      
      public static var §\x03\x07\x02\x05\x06\x02\x02\x02\b\x02\x02\x04\x06§:String = "$AnimZombieEsquive";
      
      public static var §\x05\x04\b\x03\x02\x07\x01\x03\x02\x04\x06§:String = "touche";
      
      public static var §\b\x05\x06\x04\x04\x02\b\x02\x03\x02\x02\x02§:String = "x_deadmeat/x_interfaces/divers/statut_cinematique.png";
      
      public static var §\x05\x07\x05\b\x02\b\x05\b\x01\x02\x02§:String = "$AnimAttaque_F_1";
      
      public static var §\x04\x04\x02\x04\x07\x05\x05\x02\x05\b\x05\x05§:String = "$AnimAttaqueNormal_2";
      
      public static var §\x07\x02\x06\x04\x01\x07\x03\x03\x03\x01\x01§:String = "attaque_1_2";
      
      public static var §\x02\x06\x05\x02\x05\x03\x04\x01\x07\x01\x06\x04§:String = "$AnimFeinte";
      
      public static var §\x05\x01\x03\x07\x02\x01\x02\x04\x02\x05\x06§:String = "$AnimManip";
      
      public static var §\x02\x07\x05\x04\x02\x06\x01\x01\x04\x04\x03\x04§:String = "$AnimStatique/Combat";
      
      public static var §\b\x02\x06\x06\x06\x02\x05\b\x06\b\x04\x03\x03§:int = 6196 + -5948;
      
      public static var §\x02\x03\x07\x06\x06\x04\x05\x05\x05\x06\x01\x03\b§:String = "inte";
      
      public static var §\x06\x03\x05\x02\x02\x07\x06\b\x02\x02\x05\x01§:String = "x_deadmeat/x_interfaces/principale/kit/chaine.png";
      
      public static var §\x01\x04\b\x02\x04\x06\x02\x03\b\x03\x06\x07\x03§:String = "famfamfam/bullet_go.png";
      
      public static var §\x01\b\x02\b\x01\x01\x01\x06\x05\x02\x02§:String = "$EditeurNomCarte";
      
      public static var §\x03\x06\x02\x04\x06\x02\x03\x05\x06\x07\x04\x03\x05§:String = "bonus (";
      
      public static var §\x01\x06\x07\x05\x07\x03\x07\x03\x04\x07\x06§:String = "famfamfam/book_add.png";
      
      public static var §\b\x07\x05\x04\x02\x03\b\x04\x05\x04\x03§:String = "<O>import/export";
      
      public static var §\x01\x01\x05\x02\x05\x07\x07\x04\x02\b\x01\x03§:String = "famfamfam/bullet_black.png";
      
      public static var §\x06\x01\x05\x04\x05\x04\x03\b\x02\x04\x04\x03\x01§:String = "\t\t- ";
      
      public static var §\x06\b\x02\x05\x02\x04\x05\x03\b\b\b§:String = "http://store.steampowered.com/recommended/recommendgame/667890";
      
      public static var §\x05\x07\x07\b\x05\x04\x01\x04\x07\x06\x07§:String = "$RetourLakeview";
      
      public static var §\b\x02\b\x01\x05\b\x05\b\x06\x06\x03\x01\x04§:String = "journal_page";
      
      public static var §\x07\x05\b\x07\x03\x02\x06\x06\x04\x04\x01\x02\x07§:String = "sons/16";
      
      public static var §\x02\x02\x02\x05\b\x06\x04\x05\x01\x01\b\x05\x07§:String = "$Ameliorer";
      
      public static var §\x07\x04\x02\x03\b\x03\x03\x03\x04\x01\x01\x03§:String = "x_deadmeat/x_campement/repos_fond.jpg";
      
      public static var §\x06\x05\x05\x02\x03\b\x06\x05\x06\x02\x04\b\x05§:String = "clique_repos";
      
      public static var §\x05\x04\x02\x07\x04\x04\x03\x07\x01\x07\x04§:String = "x_deadmeat/x_interfaces/forge/rotate_cw.png";
      
      public static var §\x07\x07\b\x03\x06\x01\x03\x01\x03\x07\x04\b§:String = "$Invitation";
      
      public static var §\x01\x07\b\x05\x02\b\x02\x06\x06\b\x02\x03§:String = "\n<N>Points de vie bonus : <V>+1";
      
      public static var §\x05\b\x02\x06\x04\x02\x01\x03\x05\x03\x03§:String = "]</V> <N>";
      
      public static var §\x03\x05\x06\x04\x06\b\x02\x03\x05\x06\x01\x05\x05§:String = "$ChienAnimAssis";
      
      public static var §\x03\x05\x06\x04\x06\x06\x06\x05\x03\x03\b\b\x04§:String = "<img align=\'right\' width=\'193\' height=\'241\' vspace=\'2\' hspace=\'2\' src=\'http://www.transformice.com/images/x_deadmeat/x_interfaces/divers/boussole1.png\'>";
      
      public static var §\x05\x06\b\x03\b\x04\x01\x01\x07\x06\x03\x02§:String = "<font color=\'#571515\' size=\'16\'><i>";
      
      public static var §\x05\x06\x07\x05\x06\x05\x02\x04\x05\x07\x02§:String = "<font color=\'#3B3028\'>";
      
      public static var §\x07\x07\x05\x07\x05\x05\x06\x01\x05\x01\x07\x05§:String = "$ETB_1";
      
      public static var §\x02\x07\x03\x05\x03\b\x06\x06\x04\x01\b\x07\x04§:String = "x_deadmeat/x_objets/";
      
      public static var §\x03\x01\x06\b\x04\b\x03\x01\x06\x05\b\x07§:String = "$EquipementSurvivant";
      
      public static var §\x04\x01\b\x07\x06\x04\x02\x05\x04\b\b\x07§:String = "x_deadmeat/x_interfaces/illus/cp.jpg";
      
      public static var §\x04\x07\x05\x07\x01\x05\x02\x06\x04\x01\x07§:String = "$SacPlein";
      
      public static var §\x04\x03\x07\x07\x01\x07\x03\x04\b\x03\x06\x06§:String = "celousco/interfaces/scorpion-petit.png";
      
      public static var §\x06\b\x01\x05\x02\x01\x06\x07\x06\x03\x05\b\x01§:String = "<font size=\'16\'><font color=\'#F7C988\'>";
      
      public static var §\x01\x06\x04\b\x04\x07\x04\x01\x06\x02\x05\x01\x07§:String = "$VictoireEquipe";
      
      public static var §\x01\x03\x03\x03\x07\x05\b\x02\x02\x07\x05\x07\x01§:String = "param";
      
      public static var §\x06\x06\x02\x07\b\x07\x02\x03\b\x04\x07\x05§:String = "collision";
      
      public static var §\x05\x07\x06\x06\x07\x01\x04\x07\x05\x04\x05§:String = "rotation2";
      
      public static var §\x04\x03\x07\x05\x05\x05\b\x05\x04\x06\x02§:String = "mouseWheel";
      
      public static var §\x06\x07\x04\x07\x07\x02\x03\b\x05\x02\x01\x05§:String = "Blend mode <V>(J)";
      
      public static var §\x04\x07\x02\x07\x04\x02\x06\x07\x01\b\b\x06\x02§:String = "lumiere_1";
      
      public static var §\x07\x02\x05\x03\x06\x01\b\b\x01\x06\x06\x04\x01§:String = "https://docs.google.com/spreadsheets/d/...";
      
      public static var §\x06\x02\x05\x07\x07\x04\x01\x03\x03\x07\x06\x04§:String = "$EditeurVueCodeTSVTraductions";
      
      public static var §\x07\x07\x07\x01\b\x04\b\x02\x06\x02\x04§:String = "HR";
      
      public static var §\x07\x01\x03\b\x06\x05\x03\x07\x07\x07\x06§:String = "middleMouseDown";
      
      public static var §\x05\x04\x07\x01\b\x06\x04\x05\x04\b\x02§:String = "$Interaction_0";
      
      public static var §\b\b\b\x01\x02\x05\x03\x01\x07\x04\x05\x07\x06§:String = "Hauts_02.swf";
      
      public static var §\x05\x02\x04\x05\x03\x03\x06\x06\x06\x01\x02\x01§:String = "$FX_28";
      
      public static var §\x03\x01\x01\x07\x06\x06\x02\b\x01\x02\x07§:String = "Particle pre-loading";
      
      public static var §\x04\x03\x04\x02\x01\b\x05\x02\x06\x05\x06\x04§:int = 5668 + -5167;
      
      public static var §\x04\x06\x06\x06\x03\x02\x04\x07\x04\x05\x07\x04§:String = "$Action_Droite";
      
      public static var §\x07\x01\x06\x04\x07\b\x02\x06\x02\x06\x04\x01\x05§:String = "$item.";
      
      public static var §\x04\x01\x04\b\x03\x06\b\b\x05\x01\x07\x03§:String = ".txt";
      
      public static var §\x05\b\x03\x01\x03\x06\x07\x01\x02\x06\x05\x05\b§:int = 1805 + 48195;
      
      public static var §\x02\x01\x07\x01\x06\x05\x02\x03\x01\x02\x03\x02§:String = "$MasqueTete";
      
      public static var §\x05\x06\x05\x05\x02\x05\x03\x06\x03\x05\x06\x02\x05§:String = "$bulleciseaux";
      
      public static var §\x05\x06\x06\x04\x06\x06\x04\x02\x05\x04\x02§:String = "[Monstre: ";
      
      public static var §\x05\x03\x02\x07\b\x06\x01\b\b\x06\x04\x02\x01§:int = 1199 + 598801;
      
      public static var §\x02\b\x04\x07\x05\x05\x04\x05\b\x07\x07§:String = "multi_AnimCalin";
      
      public static var §\x01\x06\x01\x05\x02\x01\x07\x06\b\x01\x06\x06\x04§:String = "AnimHi5_1";
      
      public static var §\x05\b\x01\x06\x06\x01\x06\x02\x01\x02\x01\x05\x02§:String = "$GainFraise";
      
      public static var §\x07\x06\x05\x01\x05\x02\x03\x02\b\x05\x04\x05\x05§:String = "$TexteInfo0";
      
      public static var §\x05\x01\x07\x01\x06\x03\x01\x02\x03\x06\x02\x04\x06§:String = "\n    [";
      
      public static var §\x03\x03\x01\x01\x02\x02\x07\x01\x05\x01\x05§:String = "$Exclusion_Tribu_Soit";
      
      public static var §\x03\b\x03\x07\x02\x05\x05\x01\x03\x03\x03\x06§:String = " {\n\testProprietaire=";
      
      public static var §\x03\x06\x04\x02\x04\x04\x03\x01\x06\x05\x01§:String = "$Silence";
      
      public static var §\x06\x02\x04\x04\x03\x06\x05\x05\x03\b\x03§:String = "$CompteNonExistant";
      
      public static var §\x01\x04\x06\x07\x02\x07\b\x06\x01\x07\x06\b\x03§:String = "Error : ";
      
      public static var §\x01\b\x01\x05\x04\x03\x04\x06\x05\x03\x06\x02\x02§:String = "$texte.invitation.tribu.1";
      
      public static var §\x02\x02\x04\x03\x07\x06\x05\x02\x04\x02\x02§:int = 3733 + -1720;
      
      public static var §\x02\x07\x07\x02\x06\x06\x07\x05\x01\x03\x01\x01\x04§:Number = (5100 + -5070) / (6643 + -6633);
      
      public static var §\x04\x05\x04\x02\x07\b\x07\x02\x04\x05\x07\b\x05§:String = "ATTENTION : Texte introuvable -> [";
      
      public static var §\x03\x06\b\x07\x07\x03\b\x07\x02\x06\x07\x01§:String = "zlib";
      
      public static var §\b\x01\b\x06\x02\x04\b\x03\x02\x01\x06§:String = "flash.html.HTMLLoader";
      
      public static var §\x07\x06\x06\x06\x01\x01\x03\x01\x02\x01\x03\x03§:String = "Youtube.API.changerVolume";
      
      public static var §\x07\x05\x04\x06\b\x01\x05\x06\x02\x06\x07\x03§:String = "args";
      
      public static var §\x01\x06\x05\x03\x03\x06\x03\x03\x03\x05\b\b\x03§:String = "he";
      
      public static var §\x04\x01\b\x02\x06\b\x02\b\x05\x05\b\x06§:String = "日本語";
      
      public static var §\x03\x05\x04\b\x03\x04\x01\b\x02\x07\x02§:String = "ja";
      
      public static var §\b\x07\x04\x01\x07\x05\x05\x02\x01\x05\x02\x05\x04§:String = "hu";
      
      public static var §\b\x06\x03\b\x04\x05\x06\x05\x02\x03\x04\x05§:String = "ru";
      
      public static var §\b\x07\x01\x05\b\x05\x01\b\x02\b\x06\x01§:String = "Türkçe";
      
      public static var §\x03\x07\x04\x05\x01\x02\b\x05\x02\x02\x03\x03\x06§:String = "onVideoTerminee";
      
      public static var §\x07\x06\x07\x01\x01\x01\x07\x01\x02\b\x04\x05§:String = "windows";
      
      public static var §\x02\x02\x02\x05\x04\x05\x07\x07\x06\x01\x05\x01\x03§:String = "Google Pepper";
      
      public static var §\x06\x03\x05\x01\x07\x07\x06\x05\x07\b\x05\x04\x07§:String = "http://www.transformice.com/?id=";
      
      public static var §\x04\x05\b\x02\x02\x05\x03\b\x04\x07\b\x02§:String = "medium";
      
      public static var §\x04\b\x06\x02\x03\x06\x01\x05\x07\x05\b§:String = "loadVideoById";
      
      public static var §\x03\b\x01\x01\x01\x05\x03\x06\b\x07\x06\x05\x06§:String = "$IdentifiantOuUrlImage";
      
      public static var §\x07\x04\x06\b\b\x01\x02\x01\b\x01\x07\x05§:String = "$ProchaineCarte";
      
      public static var §\x07\x05\x01\x04\x02\x03\x06\x03\x03\x07\x04§:String = ":</V> <BL>";
      
      public static var §\x05\x06\x05\x02\x03\b\b\x07\x02\b\x04§:String = "$popup.tribu.supprimerRang.etiquette";
      
      public static var §\x02\b\x04\x01\b\x02\x04\x02\x01\x05\x05\x01§:String = "<<";
      
      public static var §\x03\x04\b\x04\x05\x06\x07\x05\x02\x02\b\x04§:String = "$ActionIrreversible";
      
      public static var §\x06\x04\x02\x01\b\x07\x01\x02\x01\b\x03§:String = "x_tribulle2/male.png";
      
      public static var §\x02\x03\x03\x04\x02\b\x01\x07\x07\x07\b\x06§:String = "x_tribulle2/female.png";
      
      public static var §\x06\x03\x01\b\x04\x07\x06\x02\x03\x05\x05\x03\x05§:String = "$Menu_3";
      
      public static var §\x07\x01\x03\x02\x01\x06\x01\x02\x01\x05\x04\x03§:String = "$Amis";
      
      public static var §\x04\x07\x04\x06\x04\x07\x01\x01\x03\x05\x04\x07\x05§:String = " <N>(<BL>";
      
      public static var §\b\x04\x05\x02\x07\x05\x04\x01\x03\x05\b\x04§:String = " <N>";
      
      public static var §\x01\x02\x05\x07\x04\x04\x06\b\x06\x02\x02\x04§:String = "$Stat_33";
      
      public static var §\x06\x03\x01\x07\x03\x02\b\x06\x06\b\b\x04§:String = "\t- Cancelled: ";
      
      public static var §\x07\x01\x03\x03\x01\x03\x04\x01\b\b\x01\x06§:String = "<p align=\'center\'><V>";
      
      public static var §\x04\x05\x02\x01\b\x02\x04\x07\x03\x02\x04\x05§:String = "   ";
      
      public static var §\x02\x02\x07\x05\b\x07\x06\x04\x07\x04\x07\x05§:String = "ami";
      
      public static var §\x05\x05\x06\x01\x05\x06\x02\x03\x01\x01\x05\b\x02§:String = "silence";
      
      public static var §\b\b\x04\x07\x02\x01\x04\b\b\x04\x05§:String = "tutorial";
      
      public static var §\x02\x03\x01\x02\x07\x01\x03\x07\x02\b\x06\x06\x05§:String = "pwet";
      
      public static var §\x02\x05\x04\x03\x07\x06\x02\x01\b\x04\x05\x06§:int = 5409 + -4701;
      
      public static var §\x02\x03\x07\x01\x01\x03\b\x01\x06\x02\x04\x06§:String = "$QuestionAssocierCompte";
      
      public static var §\x04\x02\x07\x02\x01\x02\x02\x05\x07\b\x05§:String = "$LogoTransformice";
      
      public static var §\x05\x05\x04\x01\x04\x05\x03\b\x07\b\x01§:String = "http://www.transformice.com/Transformice.exe";
      
      public static var §\x06\x02\x04\x07\x05\x05\x07\x04\b\x05\x04\x05§:String = "$BoutonQJ";
      
      public static var §\x07\x06\x05\x01\x02\x04\x06\x06\x05\x07\x06\x07\x06§:String = "$AutresJeux";
      
      public static var §\b\b\x05\x01\x06\x02\b\x04\x02\x03\x05§:String = " [";
      
      public static var §\x05\x06\b\x07\x03\x06\x04\x06\x03\x01\x06\x01§:String = "$SalonSansConso";
      
      public static var §\x03\b\x07\x04\x02\x06\x03\x03\x05\x04\x03\x07\b§:String = "x_transformice/x_interface/indice.png";
      
      public static var §\b\x02\x02\x03\x04\x02\x05\b\x02\x07\b§:String = "$ModeJeu_Bootcamp";
      
      public static var §\x07\x03\x06\x05\b\x07\x05\x03\x07\b\x06\x05§:String = "ue=";
      
      public static var §\x04\b\x04\x01\x06\x01\x06\x07\x03\b\x04\x07§:String = "\n<N>";
      
      public static var §\b\x02\x07\x04\x05\x05\x03\x04\x04\b\x07\x01\x07§:String = "<u>$1</u>";
      
      public static var §\x02\x05\x05\x04\x01\b\x06\b\x05\x06\x01\x06\x03§:String = "href=\'event";
      
      public static var §\x02\x07\x07\x03\b\x01\x05\x02\x02\x01\b\x01§:String = "$SecuriteMDP";
      
      public static var §\x04\x07\x04\x05\x07\x04\x01\x06\x05\x03\x06§:String = "[img tag forbidden]";
      
      public static var §\b\x03\x04\x01\x07\x05\x07\x06\x05\x06\x02\x07\x05§:Number = (5817 + 206854) / (98 + 999902);
      
      public static var §\x05\x05\x02\x03\x02\b\x06\b\x01\x05\x07\x06\x05§:String = "x_transformice/x_aventure/x_banniere/x_";
      
      public static var §\x02\x06\b\b\x03\x05\x05\x06\x07\x02\x07\x02§:String = "Q";
      
      public static var §\x05\x05\x05\x05\x03\x03\x01\x03\x04\b\x05§:String = "Backspace";
      
      public static var §\x07\x06\x02\x02\x01\x02\x05\x02\x03\x04\x07\b\x05§:String = "getGameAuthToken";
      
      public static var §\x07\x03\x03\x03\x02\x07\x03\x06\x04\x02\x04§:String = "http://www.transformice.com/";
      
      public static var §\x06\x04\x05\x07\x03\x06\b\x06\x03\x06\x06\x01\b§:String = "\n<G>";
      
      public static var §\x05\x01\x01\x04\x05\x05\x05\x05\x01\x01\x03\b\x02§:String = "onGoogleYOLOInitialise";
      
      public static var §\x01\x04\x04\x03\x06\x01\x07\x07\x03\x01\b\x07\x05§:int = 9650 + -9441;
      
      public static var §\x04\x01\x02\b\x06\x01\x01\x04\x06\x07\x07\x06\x07§:int = 3136 + -3013;
      
      public static var §\x07\x07\x07\x01\b\x01\x06\b\x05\x05\x03\b§:int = 6812 + -6691;
      
      public static var §\x06\b\b\x02\b\x01\x03\x04\x07\x05\b\x07§:int = 2529 + -2422;
      
      public static var §\x07\x02\x04\b\x06\x04\x04\x03\x02\x06\x05§:int = 3032 + -2926;
      
      public static var §\x07\x05\x01\x04\x01\x05\x01\x05\x04\x07\x07\x02§:int = 9846 + -9757;
      
      public static var §\x06\x04\b\b\x05\x01\x07\x02\b\x04\x07\x07§:int = 1025 + 9975;
      
      public static var §\x03\x05\x06\x05\x06\b\x04\x07\x02\x06\x07§:int = 3760 + -3704;
      
      public static var §\x01\x06\x02\x05\x05\x02\x01\x06\x04\x01\b\x03§:int = 2187 + -2149;
      
      public static var §\x05\x05\x04\x05\x01\x07\x07\x01\x07\x01\b\x05\x02§:int = 9873 + -9810;
      
      public static var §\x07\x03\x04\x03\x05\x06\b\x01\x05\x05\x06§:int = 6227 + -5882;
      
      public static var §\x04\x05\x03\x02\x05\x03\x02\x06\x01\x03\b\x07§:int = 6065 + -5890;
      
      public static var §\x04\x05\x06\x05\x06\b\x06\x06\x02\x06\x01\x04§:int = 2847 + -2573;
      
      public static var §\x06\x06\x03\x03\x01\x05\x01\x07\x04\x03\x01\x03§:int = 4511 + -4330;
      
      public static var §\x05\x04\x02\x02\x03\x02\x01\x02\x03\x01\x01§:String = "$editeur.vitesseBonusEntrée";
      
      public static var §\x04\x01\x02\x04\b\x07\x01\x03\x05\x05\x03§:String = "defilante_plus.png";
      
      public static var §\x07\x01\x03\x02\b\x05\x03\x06\b\x03\x04\x07\x06§:String = "P";
      
      public static var §\x05\x04\x04\x07\x07\x02\x06\x05\b\x06\x04\x03\x07§:String = "AnimStatiqueC";
      
      public static var §\x04\b\x02\x06\x04\x03\x05\x07\x02\x07\x04\x06\x05§:String = "AnimStatique";
      
      public static var §\x04\x06\x07\b\x07\b\x02\x04\x02\x04\b§:int = 5408 + 14992;
      
      public static var §\x03\x06\x04\x06\x02\x02\x02\x03\b\x03\x05\x01§:Number = (4971 + -4966) / (4624 + -4524);
      
      public static var §\x03\b\x06\x04\x05\x04\x03\b\x02\x03\b\x01\x05§:String = "$ValiderPaiement";
      
      public static var §\x04\x01\b\x01\x01\x07\x06\x03\x01\x02\x01\x07\x06§:String = "x_transformice/x_interface/paiements/paypal.jpg";
      
      public static var §\x05\x03\x05\x07\x05\b\x06\b\x01\x07\x07\x02\x03§:String = "$CopierLienPressePapiers";
      
      public static var §\x01\x04\x05\x01\x05\x06\b\x01\x06\b\x01§:String = "response";
      
      public static var §\x04\x04\x01\b\x07\x01\x05\x02\x03\x04\b\x06\x04§:int = 6735 + -6570;
      
      public static var §\x05\x07\x04\x05\x04\x02\x03\x07\x03\b\x05\x05§:String = "x_commun/x_iconespaiement/x_logo_kongregate.png";
      
      public static var §\x01\x05\x04\x05\x03\x05\x07\x05\x01\x07\x07\x06\x04§:Number = (3235 + -3199) / (4521 + -3521);
      
      public static var §\x06\x05\x01\x01\x07\x04\x01\x07\x07\x01\x04\x07§:int = 7320 + 12680;
      
      public static var §\x06\x02\b\x05\x01\x03\x06\x06\x06\x03\x05\b§:int = 9715 + -9560;
      
      public static var §\x05\x04\x01\x04\x04\x03\x04\b\x01\x04\x01§:String = "] ";
      
      public static var §\x06\x06\x01\x01\x01\b\x04\x01\x07\x03\x02\x06\x03§:String = "clojf`b\\ci^+\\buqb";
      
      public static var §\x03\x02\b\b\x04\x02\b\b\x02\x06\x07§:int = 8307 + -7832;
      
      public static var §\x01\x01\x01\b\x04\x06\x03\x07\b\x04\x03§:int = 9393 + -9231;
      
      public static var §\x04\x05\x04\x04\x03\x06\b\x02\x05\x05\x06\x04\b§:String = "_DE";
      
      public static var §\x01\x03\x03\b\x04\x05\x04\x07\x05\x01\x04\x01§:int = 1618 + -1599;
      
      public static var §\x01\x01\x06\x07\x04\b\x05\x01\x01\b\x05\x07\x04§:String = "$OC_MoteurVert2";
      
      public static var §\x04\x07\x07\x05\x03\x03\x01\x07\x06\x05\x02\x01§:int = 9581 + -9129;
      
      public static var §\b\x02\x06\x02\x03\x05\b\x07\x07\x04\x01\x02\b§:String = "<font color=\'#FEB1FC\'>Le Bourrin</font>";
      
      public static var §\x07\x07\x03\x06\x05\x03\x07\x07\x02\x04\x04§:int = 5889 + -5442;
      
      public static var §\x05\x07\x06\x07\x01\x06\x05\x05\b\x06\b\x03§:String = "zimmer";
      
      public static var §\x01\b\b\x07\x07\x05\x03\x01\x05\x01\b\x07\b§:String = "scc";
      
      public static var §\b\b\x05\x02\x04\x07\x04\x02\b\x07\x04§:Number = (5046 + -4046) / (4481 + -4471);
      
      public static var §\x01\x02\x04\x01\b\x05\b\x03\x02\x05\x06\x03§:String = "ECHELLE : ";
      
      public static var §\x05\x02\x07\b\x01\b\x06\x02\x04\x07\x07\x01\x05§:String = "fin_partie";
      
      public static var §\x07\x03\b\x06\x01\x06\x03\b\x02\x07\x05\x04\x03§:String = "son/np";
      
      public static var §\b\x05\x03\x06\x06\x06\x03\x01\x07\b\x01\b\x05§:String = "$";
      
      public static var §\x01\b\x06\x02\x07\x01\b\x07\b\x02\x03\x07§:String = "*";
      
      public static var §\x07\x03\x07\b\x04\x02\x07\x06\x06\x03\x02\x05\x07§:String = "$Deballer";
      
      public static var §\x04\b\x02\x05\x04\x06\x02\x01\b\x07\x05§:String = "nekodancer.net";
      
      public static var §\x07\x06\x07\x07\x02\x03\x06\x05\x02\b\x07§:Number = (9281 + -9270) / (5568 + -5558);
      
      public static var §\x07\x06\x01\x05\x01\x01\x01\x04\x06\x03\x01§:Number = (860 + -859) / (8347 + -8337);
      
      public static var §\x02\x05\b\x01\x05\b\x07\x07\x06\x02\x05\x02\x03§:int = 9831 + -7831;
      
      public static var §\x07\x04\x06\b\x07\x06\x03\x01\x01\x04\x04\x07\x03§:int = 8005 + -7845;
      
      public static var §\x02\x03\x01\x06\x07\x02\x04\x05\x07\x05\x07\x05\b§:String = "Transformice";
      
      public static var §\x02\b\x04\x05\x04\x01\x05\x04\x07\x06\x05\x03\x07§:String = "<J>";
      
      public static var §\b\x04\x03\x06\x06\x05\x04\b\x07\x02\x03\x03\b§:String = "push";
      
      public static var §\x05\x03\x01\b\x01\x07\x01\x07\b\b\x04\x02\x03§:String = "";
      
      public function §\x07\x05\x07\x06\x05\x02\x03\x06\x06\x04\b§()
      {
         super();
      }
      
      public static function §\x02\x03\x07\x04\x01\x01\b\b\x02\x03\x04\x06§() : Number
      {
         return (9592 + -9588) / (8867 + -8857);
      }
      
      public static function §\x03\x01\x02\b\x04\x03\x01\x03\x02\x03\x07\x06\x06§() : int
      {
         return 3340 + -2580;
      }
      
      public static function §\x03\x04\x07\x03\x03\b\x06\x04\x04\x01\x02\x02\x05§() : Number
      {
         return (2473 + -728) / (2198 + 97802);
      }
      
      public static function §\x03\x03\x07\x05\x01\x03\x04\x05\x04\x03\x02\x05§() : Number
      {
         return (559 + -214) / (4101 + -4001);
      }
      
      public static function §\b\b\x02\b\x07\x06\x04\x04\x01\x01\x03\x02§() : int
      {
         return 1877 + -1759;
      }
      
      public static function §\x07\x02\x01\x07\x07\x06\x02\x07\b\x05\x07\b\x03§() : int
      {
         return 3895 + -3801;
      }
      
      public static function §\x01\x02\x02\x05\x03\b\x07\x07\x02\x02\x01\x02§() : int
      {
         return 1530 + -1339;
      }
      
      public static function §\x06\x07\x03\x06\x04\x06\b\x04\x06\x06\x02\x07\x07§() : int
      {
         return 5922 + -5894;
      }
      
      public static function §\x02\x07\x03\x01\x03\x03\x02\x03\b\x07\x05§() : int
      {
         return 819 + -623;
      }
      
      public static function §\x03\x02\x07\x03\x03\b\x01\x07\x07\x05\x04\x07\x07§() : int
      {
         return 1013 + -945;
      }
      
      public static function §\x01\x03\x04\x03\x03\x01\x03\x07\x07\x07\x04\b\x03§() : int
      {
         return 3882 + -3789;
      }
      
      public static function §\x06\x07\x03\b\x05\x04\x04\x07\x02\x02\b\x06\x05§() : int
      {
         return 1839 + -1816;
      }
      
      public static function §\x03\x03\b\x05\x06\x03\x01\x05\x05\x01\x07§() : int
      {
         return 2956 + -2938;
      }
      
      public static function §\b\x07\x07\x02\x05\x04\x07\x07\x07\x02\x04\x04\x02§() : int
      {
         return 9967 + -9814;
      }
   }
}

