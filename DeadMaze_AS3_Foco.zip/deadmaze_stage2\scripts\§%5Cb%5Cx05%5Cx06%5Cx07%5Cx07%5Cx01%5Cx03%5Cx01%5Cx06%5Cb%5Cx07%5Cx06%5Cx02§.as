package
{
   public class §\b\x05\x06\x07\x07\x01\x03\x01\x06\b\x07\x06\x02§
   {
      
      public static var §\b\x02\x07\x02\x06\x07\x04\x07\x04\x05\x07§:String = "ajout objet : 6";
      
      public static var §\x06\x05\x06\x04\x02\x06\x02\x01\x01\x05\x05§:int = 4733 + -2112;
      
      public static var §\b\x05\x03\x05\b\x05\x07\x07\x05\x07\x07\x06§:String = "<font color=\'";
      
      public static var §\b\x06\x01\x04\x07\x05\x04\x01\x03\x07\x03§:String = "<font color=\'#D8A8FF\'>";
      
      public static var §\x06\x04\x05\x04\x01\x05\x04\x02\x05\x05\x04\x07§:String = "x_fourrures5.swf";
      
      public static var §\b\x03\x05\x07\b\x06\x05\x07\b\x06\x05§:int = 1936 + -1426;
      
      public static var §\x01\x02\x03\x01\x07\x04\x03\x01\x04\x01\x02§:Number = (6501 + -6336) / (196 + -96);
      
      public static var §\x02\x07\x01\x07\x06\x05\x02\x05\x05\x06\x05§:Number = (9209 + -9171) / (8186 + -8086);
      
      public static var §\x07\b\x07\x06\b\x05\x03\x02\b\x05\x01\x04§:Number = (9914 + -9739) / (4178 + -4078);
      
      public static var §\x04\x06\x04\x02\x06\x01\x07\x06\x04\x04\x03\b§:String = "puceron.png";
      
      public static var §\x07\x07\x07\x02\x01\x01\x07\x01\x05\x06\x04\x06§:String = "raisins_petite.png";
      
      public static var §\x01\x04\x05\x07\x05\x01\x05\x06\x02\b\x03\x02\x07§:String = "    chemin swf : ";
      
      public static var §\x01\x02\b\x07\x07\x03\x03\x04\x02\x07\x05§:String = "    param : ";
      
      public static var §\b\x03\x07\x05\x02\x07\x02\x05\x04\x02\b\x05\x05§:String = "stream";
      
      public static var §\x02\x04\x06\x01\x07\x06\x01\x06\x05\x01\x02§:String = "$Utiliser";
      
      public static var §\b\x03\x04\x02\x02\x03\x07\x07\x07\b\x03§:String = "$Inventaire_DejaEnEchange";
      
      public static var §\b\x03\x05\x06\b\x05\x04\x02\b\x05\x02\x03\x01§:String = "$Enregistrer";
      
      public static var §\x06\x06\x07\x04\x04\x03\x03\x04\x07\x06\x02§:String = "$QuantiteFraisesBaseEtBonus";
      
      public static var §\x03\x04\x07\x05\b\x02\x03\x06\x02\x04\x06\x05§:String = "x_commun/x_boutonspaiement/fond-fraise-steam-";
      
      public static var §\b\b\x04\x05\x07\b\x07\x05\b\x01\x05\x03\x05§:String = "$Remercier";
      
      public static var §\x07\x05\x01\x03\x05\x03\x06\x04\x01\x01\x04\x02§:String = "$C_Fromage";
      
      public static var §\x02\x04\x06\x04\x07\x01\x06\x01\b\x02\x03\x07§:String = "</V> / <J>";
      
      public static var §\x01\x01\x03\x01\x05\x02\x05\x02\x01\x02\x06§:String = "Arme_";
      
      public static var §\x01\x05\x06\x01\x03\x02\x07\x07\x06\x05\x07\b\x03§:String = "img:";
      
      public static var §\x04\x02\x02\x01\x07\x07\x01\x03\x02\x01\x03§:String = "</a> »";
      
      public static var §\x07\x02\x04\x05\x01\x04\x05\x03\x02\x01\x02\x02§:String = "<font color=\'#E1B353\'>★★★</font>";
      
      public static var §\x02\x05\b\x04\x06\x04\x04\b\x05\x07\x03\x03\x03§:String = "x_i_16.png";
      
      public static var §\b\x07\x02\x01\b\x04\x06\x07\b\x07\x07\x07§:String = "x_i_22.png";
      
      public static var §\x02\x06\b\x03\x03\x06\x06\x02\x01\x07\x04\x05§:String = "x_i_20.png";
      
      public static var §\x07\x06\x01\b\x03\x05\x04\x03\x05\x06\b\x02§:String = "x_i_41.png";
      
      public static var §\x07\x04\x05\x07\x01\x06\x01\x03\x05\x01\x04§:String = "physiqueJoueur";
      
      public static var §\x06\x05\x04\x06\x06\x01\x06\x07\x03\x03\x05\x03\x02§:String = "$Transparent";
      
      public static var §\x01\x05\x01\b\b\x02\x04\x05\x01\x07\x07\x07§:int = 1747 + -1145;
      
      public static var §\x06\x01\x02\x05\x04\x04\x07\x01\x06\x07\x01\x07\x01§:String = "SFH";
      
      public static var §\b\x05\x03\x03\x01\x05\x06\x04\x06\x06\x04\x03\x06§:String = "SSS";
      
      public static var §\x02\x05\x02\x01\x01\x06\x05\x02\x02\x04\x03§:String = "JPL";
      
      public static var §\x02\x02\x02\x03\x06\x01\x06\x07\b\x05\x05\x04\x06§:String = "HZ";
      
      public static var §\x04\x04\x01\x06\x03\x05\x01\x02\x04\x01\x06§:String = "dur";
      
      public static var §\x04\x02\x02\x01\x06\x02\x05\x02\x06\b\x06§:String = "$Noir";
      
      public static var §\x02\x05\x02\x03\x04\x02\x04\b\x04\b\x04\x03§:String = "<BL> - ";
      
      public static var §\x02\x05\x05\x05\b\x03\x07\x02\x07\x04\x07\x07\x07§:String = "$T_";
      
      public static var §\x01\x01\x07\x03\b\x02\x02\x04\x02\x02\x06\x01\x07§:String = "$CartoucheArbre";
      
      public static var §\x06\b\x03\x01\x01\x07\x07\x06\x07\x05\x07\x07§:String = "Envoie_Serveur";
      
      public static var §\x01\x06\x02\x05\x06\x01\x03\x06\x01\x04\x06§:String = "recupRessource";
      
      public static var §\b\x06\x02\x06\b\x01\x04\x05\x06\x06\x03\x06§:String = "<font color=\'#009D9D\'>•</font> ";
      
      public static var §\x06\b\x04\x04\x04\x04\x07\x02\b\b\b\x04§:String = "$Emoji";
      
      public static var §\x02\x01\x05\x04\x06\x02\x03\x06\x01\x03\x07\x05\b§:String = "$texte.magasin";
      
      public static var §\x03\x01\b\x02\x03\x06\x07\x06\x06\x04\x03\x04§:String = "$CertificationOK";
      
      public static var §\x05\b\x04\b\x01\x05\x03\b\b\x07\b§:String = "C_";
      
      public static var §\b\x06\x04\x04\b\x06\x07\x07\x01\x06\x06\x01§:String = "$Taille";
      
      public static var §\b\x03\x06\b\x07\x06\x06\x04\x03\x05\x06\x03§:String = "lice";
      
      public static var §\x06\b\x03\x06\x04\x03\x05\x06\b\x01\x06\x03§:int = 4791 + -4575;
      
      public static var §\x02\x01\x07\x06\x04\x02\x01\x07\x06\x01\x03\x07§:String = "x_evenements/x_machine_2.jpg";
      
      public static var §\x06\x03\x05\x05\x02\b\x02\x03\x02\x05\x01\x05\x04§:String = "• [";
      
      public static var §\x05\b\x05\x07\x05\x02\x03\x02\x01\x07\b\x03§:String = "<ROSE>• [JOUEUR] MESSAGE</ROSE>";
      
      public static var §\x02\x07\x01\x02\x07\x01\x06\x04\x04\x07\b\x03\x07§:int = 3387 + -2287;
      
      public static var §\x03\x07\x01\x03\x05\b\x03\x05\x07\x07\x02\x06§:String = "_sort_2";
      
      public static var §\x03\x01\x04\x07\x01\b\x07\x03\x01\x02\x07\x07§:String = "$AnimAttaque_H_3";
      
      public static var §\b\x01\x04\x02\x03\x01\x02\x04\x07\x04\x01\x02§:String = "courseArme";
      
      public static var §\x03\x04\x03\x02\x04\x06\x02\x07\x07\b\x01\x04§:String = "comp_6";
      
      public static var §\x04\x06\x04\x03\x04\x05\x06\x02\x03\x06\x01\x01§:String = "feinte";
      
      public static var §\x06\b\x06\x05\x07\x01\x04\x03\x07\x05\x06\x01\x04§:String = "boire";
      
      public static var §\x06\x01\x07\b\x02\x02\x04\b\x03\x04\x03\x07§:String = "$AnimManger";
      
      public static var §\x06\x05\b\x07\x02\x02\b\x01\x06\x05\x03\x07\x04§:String = "/mort";
      
      public static var §\x02\x01\x05\x01\x04\x07\x01\x05\x07\x03\x05\x07§:String = "plop";
      
      public static var §\x01\b\b\x05\x02\b\b\x01\x07\x02\x05\x01\x04§:int = 7318 + -6985;
      
      public static var §\x04\x05\b\x03\b\x04\x06\x03\x04\x01\x06\x07§:String = "info_arme";
      
      public static var §\x04\x01\x07\x02\x05\x02\b\b\x07\x02\x01§:String = "bruit/sac2";
      
      public static var §\x07\x05\x02\x07\x03\x07\b\b\x01\x03\b\x04\x02§:int = 7313 + -7142;
      
      public static var §\x07\x05\x01\x06\x01\b\x03\b\x04\x03\x07§:String = "</N>\n";
      
      public static var §\x05\x05\x01\x05\x01\x06\x07\x04\x02\x06\x07\x04\x05§:String = "$Niveau";
      
      public static var §\x02\x03\b\x06\x06\x06\x04\x02\x05\x06\b\x06§:String = "]</O>";
      
      public static var §\x03\b\x02\x04\x06\x06\x01\x07\x02\x07\x03§:String = "https://discord.gg/deadmaze";
      
      public static var §\x07\x07\x05\b\x03\x01\x04\x01\x01\x05\x05\x01\x01§:String = "$DenominationAventure";
      
      public static var §\x06\x01\x06\x07\x07\x03\x05\x03\x05\x06\x04\x07\x05§:String = "$EditeurEmplacementLibre";
      
      public static var §\x01\x07\x07\x07\x04\x02\x03\x04\x03\x01\b\x02\x04§:String = "$EditeurJouerCarte";
      
      public static var §\x05\x04\x05\x04\x01\x06\b\x07\b\b\x03\x03§:String = "<O>xp <font color=\'#C396E3\'>";
      
      public static var §\x07\x07\x02\x07\x07\x01\x02\b\x06\x07\x01\x07\x06§:String = "$AideAmelioration";
      
      public static var §\x05\b\x05\x03\x01\x03\x04\x03\x04\x04\x01\b§:String = "$Chien";
      
      public static var §\x04\x01\x06\x02\x03\x02\x03\x01\b\x06\x02\x07\x03§:String = "active_until_step";
      
      public static var §\x06\x02\x03\x07\x07\x03\x05\x05\x01\x03\x02\x05\x06§:String = "famfamfam/bullet_purple.png";
      
      public static var §\b\x06\x05\x05\x01\x06\x06\x07\x07\x03\x04§:String = "<VP>add objective";
      
      public static var §\x03\x06\x04\x01\x02\x01\x01\x06\x04\x05\x05\b\x03§:String = "Yes, delete";
      
      public static var §\x03\x02\x01\x03\x01\b\x01\b\b\x05\x07§:String = "duration";
      
      public static var §\x06\x07\x01\x02\x06\x01\x03\x05\x02\x07\x04\x04§:String = "x_deadmeat/x_objets/347.png";
      
      public static var §\x06\x07\x03\x07\x02\x01\x04\x03\x05\x02\x03\x03§:String = "$TempsRestantHeure";
      
      public static var §\x05\x05\x06\x07\x04\x06\x03\x07\b\x07\x03\x02§:String = "Cinematique_";
      
      public static var §\x05\b\x03\x05\x04\x07\x04\x05\x04\b\x07\x07§:String = "$CameraFluide";
      
      public static var §\x02\x01\x06\x04\x05\x04\x06\b\x06\x02\x05\b§:String = "$bordure_bas_droite";
      
      public static var §\x04\x04\x04\x07\x03\x03\x05\x03\x01\x04\b\x02\x01§:String = "+100%";
      
      public static var §\x02\b\x06\x07\x03\x01\x06\x05\x02\x05\x02§:String = "$AideFabrication";
      
      public static var §\x06\x05\x05\x02\x07\b\x01\x05\x01\b\x05\x05\x01§:String = "$CombustiblesDispo";
      
      public static var §\x04\x05\x05\x07\x06\x03\b\x05\x06\x06\x06\x07§:String = "x_deadmeat/x_campement/feu/";
      
      public static var §\x05\x01\x07\x03\x04\x01\x07\x06\b\x02\x02\x05\x06§:String = "tremblement";
      
      public static var §\x07\b\x03\x02\x01\b\b\x04\x01\x03\x05\x04§:String = "tuto_allumer_feu";
      
      public static var §\x07\x01\x01\b\x03\x04\x02\x04\x01\x03\x02§:String = " s";
      
      public static var §\x05\x01\x01\x05\x04\x06\x05\x03\x01\b\x01§:String = "x_deadmeat/x_interfaces/forge/switch_fg_bg.png";
      
      public static var §\b\x02\b\x07\x02\x05\x01\x07\x07\x02\x04\x05\x06§:int = 688 + -404;
      
      public static var §\x04\x07\x07\x04\b\x07\x05\x07\x04\x06\x02\b§:String = "$type_atelier.";
      
      public static var §\x04\x04\x03\x07\x07\x01\x07\x01\x04\x02\x05\x03\x07§:String = " <O>+";
      
      public static var §\x02\x03\x03\x05\x07\x01\x07\x07\x04\x02\x05\x02§:String = "<O>+";
      
      public static var §\x05\b\x04\x02\x07\x03\x02\b\x03\x03\x02\x03\x03§:String = "\n<R>• ";
      
      public static var §\x01\x02\x06\b\x04\x07\x07\x07\x03\x03\x04\x06\x03§:String = "x_deadmeat/x_interfaces/principale/jauge";
      
      public static var §\x03\x05\x07\x03\x07\x02\b\x06\x05\b\x07\x03\x02§:String = "$ChoisirRecompense";
      
      public static var §\x01\x03\x07\b\x04\b\x04\x01\x01\x02\x03\x05§:String = "$CouleurSousVetements";
      
      public static var §\x07\x02\x06\x05\x05\x02\x03\x04\x04\x01\x07\x01§:int = 8222 + -7382;
      
      public static var §\x06\b\x02\x05\x06\x01\x02\x03\x02\x07\x01\x04\x05§:String = "x_deadmeat/x_personnages/x_illu_";
      
      public static var §\x05\x06\x04\x04\x01\b\b\x06\x05\x03\b\x06\x05§:int = 5401 + -5023;
      
      public static var §\x03\x06\b\x06\x02\x05\x05\x06\x07\x07\x01\x04§:int = 338 + 251;
      
      public static var §\x03\x01\x03\x04\x04\x06\b\x04\x01\x05\x01\x06\x02§:int = 54 + 533;
      
      public static var §\x03\x07\x04\x02\x03\x04\x01\x07\x02\x01\x03\x01§:int = 4901 + -4315;
      
      public static var §\x07\x05\x07\x06\x03\x01\x06\x01\b\x05\x03\x01\x02§:int = 7728 + -7555;
      
      public static var §\x02\x02\x02\x03\x07\x01\x07\x05\x01\x07\x04\x02\x07§:int = 652 + -132;
      
      public static var §\x02\x07\x02\x02\x02\b\x07\x06\x05\x07\x01\x01§:String = "$ConfirmationAchatSlotOccupe";
      
      public static var §\x05\x01\b\x06\x02\x06\x04\x01\x04\x06\x06\b\x03§:String = "<font size=\'11\'><G> (";
      
      public static var §\x04\x02\x06\x04\x05\x02\x03\x03\x01\x06\x07\b\x01§:String = "GrosMonstre";
      
      public static var §\b\x06\b\x07\x05\x05\x03\x01\x01\x03\x01§:String = "$EditeurProprietesGroupeSpawns";
      
      public static var §\b\x05\x06\x04\x05\x05\x01\x04\b\x02\x03§:String = "$texte.desactiver";
      
      public static var §\x04\x05\x05\b\x02\x02\x05\x02\x02\b\x06\x03§:String = "Test point accroche";
      
      public static var §\x04\x01\x04\x03\x07\x03\x07\x06\x05\x07\x07§:String = "addChild";
      
      public static var §\x06\x06\x05\b\x06\x03\x04\x03\x03\x06\b\b§:String = "ancre";
      
      public static var §\b\x02\x04\x03\x03\x02\x01\x05\x01\x01\x06\x05\x02§:String = "secret";
      
      public static var §\x03\x05\x06\x02\x01\x05\b\b\x03\x03\x07\x01\x05§:String = "Landmark\n<N>(<V>CTRL</V> to remove)";
      
      public static var §\x04\x03\x05\b\x06\x06\x02\b\x02\x02\x05\x06§:String = "Add narration area\n<N>(<V>CTRL</V> to remove)";
      
      public static var §\x04\x02\x02\x07\x03\x04\x05\b\b\x03\x05\x06\x06§:String = "chemin";
      
      public static var §\x05\x01\x05\x05\b\x07\x05\x04\x06\x02\x01\x05\x04§:String = "spawn1";
      
      public static var §\x06\x04\x07\x01\x03\x07\b\b\x04\x01\x05\x05§:String = "sim2";
      
      public static var §\x03\x01\x04\x04\x05\x07\x02\x02\x06\x04\x03\x03§:String = "sim1";
      
      public static var §\x05\x02\x02\x04\x05\x04\x01\x05\x05\x05\x04\x02\x03§:String = "Clear elevation";
      
      public static var §\x05\b\x07\x01\x01\x02\x06\x05\x01\x06\x05§:String = "elevation_2";
      
      public static var §\x05\x06\x02\x06\x01\x03\b\x06\x04\x05\x02\x06\x01§:String = "Ids de monstres :";
      
      public static var §\x01\b\x06\x01\x07\x01\x03\x02\x06\x02\x07\x04§:String = "$EditeurTitreProprietesObjet";
      
      public static var §\x05\x01\x07\x05\x07\x03\x04\x07\x06\x06\x02\x06\x04§:String = "$bouton.annuler";
      
      public static var §\x02\x03\b\x04\x06\x05\x04\x01\x04\x01\x03\x06\x04§:String = "ET";
      
      public static var §\x01\x01\x03\x05\x07\x04\x06\x04\x07\x06\x05\x05\x03§:String = "$langue.japonais";
      
      public static var §\x01\b\x05\x06\x04\x01\x05\x07\b\x05\b§:String = "BR";
      
      public static var §\x03\x03\x05\x01\x01\x04\x01\x06\x03\x03\x01§:String = "\nMobile : ";
      
      public static var §\x04\x07\x06\x04\x03\x06\x06\x04\x03\b\x06§:String = "x_deadmeat/x_campement/x_icones/";
      
      public static var §\b\x02\x07\x03\x07\x07\x06\x04\x01\x07\x02\x04\x05§:String = "] !";
      
      public static var §\x06\x01\b\x01\x03\x06\x02\x02\x03\x03\x01\x07\x05§:String = "x_deadmeat/x_pictos/s_";
      
      public static var §\x01\x04\x06\x06\x07\x01\x06\x03\x07\x06\x01§:String = "$FX_";
      
      public static var §\x01\x04\x04\b\x03\b\x05\x01\x03\x04\x05§:String = "$I_Croix1_DM";
      
      public static var §\x02\x01\x05\x06\x07\b\x07\x07\x01\x01\x07\x04§:String = "x_deadmeat/x_interfaces/x_login.jpg";
      
      public static var §\x03\x01\x02\x01\x06\x03\x05\x05\x03\x01\x06\x02§:String = "flash.desktop.NativeApplication";
      
      public static var §\x03\x02\x02\x01\x01\x02\x07\x07\x05\x02\x06\x06\x02§:String = "Changer le sens d\'un picto";
      
      public static var §\x02\x06\x07\x01\x03\x05\x05\x06\x01\x02\x02\x01§:String = "$EliminationJoueur";
      
      public static var §\x05\x04\x02\b\x05\x02\x06\x06\x04\x07\b\x01§:String = "$DebloquerTitre";
      
      public static var §\x02\b\x07\b\x04\x06\x06\x05\x07\x06\x02\x01\x01§:String = "x_deadmeat/x_interfaces/divers/cheveux.png";
      
      public static var §\b\x06\b\b\x04\x04\x04\x06\x05\x01\x07§:String = "http://atelier801.com/tradmin?co=";
      
      public static var §\x03\x07\x02\x02\x03\x02\x01\x07\x06\x01\x06\x01§:String = "enter";
      
      public static var §\b\x07\x01\x07\b\x07\x01\x04\x01\x05\x04§:String = "Gant_1";
      
      public static var §\x05\x02\x06\x04\x05\x02\x03\b\x02\x07\x03\x02\x04§:String = "son/victoire2";
      
      public static var §\x01\x07\x02\x07\b\x05\x01\x02\x02\x01\x02\x01\x04§:String = "$FH";
      
      public static var §\x03\x06\x03\x02\x06\x04\x01\x01\x02\x01\x05\x07§:String = "f";
      
      public static var §\x07\x06\x06\x05\x06\x04\b\b\x06\x06\x02\x04\x06§:String = "AnimDuck";
      
      public static var §\x05\x04\x04\b\b\x02\x02\x03\x04\x01\x05\x02§:String = "AnimCalin_2";
      
      public static var §\b\x05\x03\x04\x07\x01\x03\x05\b\b\x05\x07§:String = "$ParticuleNeige";
      
      public static var §\x07\b\x01\x01\x06\x04\b\x04\x03\b\x07\x02§:String = "]</a><BL>";
      
      public static var §\x04\x06\x06\x03\x06\x05\x03\b\b\x07\x01\x04§:String = "</CH>";
      
      public static var §\x03\x02\x01\x07\x02\x06\x04\x03\x05\x01\x06\b\b§:String = "après objetSpawn";
      
      public static var §\x07\b\x04\x05\x05\x05\x06\x03\x07\b\x02§:String = "$Rejoindre_Tribu";
      
      public static var §\x06\x05\x04\x07\x07\b\x04\x05\x04\x05\x06\x06§:String = "16";
      
      public static var §\x01\x02\x06\b\x04\b\x05\x01\x01\x04\x02\b\x05§:int = 3354 + 6644;
      
      public static var §\x04\b\x06\x04\x04\x06\x07\x02\x06\x03\x03\x07§:String = "mobilepay";
      
      public static var §\x03\x04\x04\x02\x05\x07\x04\x01\x01\x05\x05\x05\x06§:String = ") ";
      
      public static var §\x04\b\x06\x05\x04\x06\x02\x02\x07\x05\x01\x06§:String = "Tentative de connexion au serveur monde (";
      
      public static var §\x05\x03\b\x06\x03\x03\x01\x02\x03\x07\x04§:String = "$NePlusAfficherFenetre";
      
      public static var §\x06\x03\b\x01\x07\x04\x03\x04\x02\x04\x03\b§:String = "$popup.tribu.pleine";
      
      public static var §\x04\x03\x06\x01\x03\x01\x04\x03\x03\x06\x01§:Number = (5941 + -5441) / (1439 + -1429);
      
      public static var §\x06\x04\x04\x03\x04\x06\x04\x01\b\x06\x03\x04§:String = "Youtube.API.arreterVideo";
      
      public static var §\x03\x01\x01\x05\x01\x04\x01\x05\x01\x07\x03\x05\x03§:String = "AR";
      
      public static var §\x02\x03\x01\x01\x01\x01\x06\x01\x02\x01\b\x04§:String = "pt";
      
      public static var §\x03\x03\x01\x05\b\x01\x03\x06\x02\x04\x03§:String = "Lietuvių";
      
      public static var §\x01\x07\x02\x07\x02\x03\x03\x07\x06\x06\x05§:String = "Doit être implémenté.";
      
      public static var §\x06\x03\x05\x05\x02\x04\x04\x06\x02\b\x05\x02§:String = "setSize";
      
      public static var §\x03\x04\x02\x02\x06\x06\x03\x02\x04\b\x03\x05§:String = "x_transformice/x_interface/steam.png";
      
      public static var §\x01\x04\x07\x03\x02\x01\x06\x03\x04\b\x02§:String = "$ExplicationImageFondLogin";
      
      public static var §\b\x07\x07\x02\b\x02\b\x02\x01\x07\x03§:String = "$LancerNouvellePartie";
      
      public static var §\x01\x06\x04\x05\x01\x04\x03\x04\x05\x01\x05§:String = "Erreur de fichier.";
      
      public static var §\x06\x06\b\x01\b\x04\x02\x02\b\x01\x07\x05§:String = "flash.filesystem.FileMode";
      
      public static var §\x05\x02\x05\x04\x04\x01\x04\x02\x07\x05\x06\x04\x07§:String = "$popup.tribu.creation.information";
      
      public static var §\x06\x06\x02\x02\x06\x02\x06\x06\b\x06\x06\x06§:String = "@0-9";
      
      public static var §\x01\x02\x02\x01\x05\x04\x06\x07\x06\x01\x06\x06\x05§:String = "$popup.tribu.dissoudre.titre";
      
      public static var §\x04\x02\x07\x01\x02\x01\x04\x04\x06\x07\x04\x02§:String = "membreParti";
      
      public static var §\x06\x03\b\x04\x02\b\x02\x06\x03\x04\x05\x03§:String = "$interface.tribu.bouton.monter";
      
      public static var §\x05\b\x03\x07\x06\x06\x07\x03\x01\x03\x01§:String = "$ListeMembres";
      
      public static var §\x01\x04\x06\x07\x01\x03\x07\x06\x02\x05\b§:String = "tribe?tr=";
      
      public static var §\x04\x06\x03\x03\x05\x01\x03\x03\b\x05\x02\x06§:String = "$popup.amis.divorcer.contenu";
      
      public static var §\b\x05\x07\x07\x04\x05\x07\x07\x02\x01\x06\x02\x02§:String = "$Anonymouse";
      
      public static var §\x01\x07\x02\x07\x05\x07\x04\x02\x02\x02\x03\b\b§:int = 7209 + 17510;
      
      public static var §\b\x03\x07\x04\x03\x03\x05\x05\x06\x04\x06\x05§:String = "<N>)";
      
      public static var §\x05\x01\x04\x02\b\x04\b\x03\b\x02\x05§:String = " <N>(<R>";
      
      public static var §\x06\x02\x05\x04\x07\x01\x07\x07\x03\x03\x07\x07\x07§:String = "x_transformice/x_interface/classement/6.png";
      
      public static var §\x07\b\x06\x02\b\x03\x07\x01\x07\x04\x03\x05§:String = "x_transformice/x_interface/classement/5.png";
      
      public static var §\x04\x04\x06\x06\x07\x02\b\b\x05\x01\x03\x07\x03§:String = "minutes";
      
      public static var §\x05\x01\x06\x05\b\x05\x04\x07\b\b\x05\x07§:String = "$Doucement";
      
      public static var §\x02\x07\b\x05\x07\x01\x06\x02\x06\x02\x06\x07\x01§:String = "  ";
      
      public static var §\x02\x05\x01\x04\x01\x02\x06\b\x03\x06\x07§:String = "mt";
      
      public static var §\x03\x01\b\x03\x06\b\x02\x04\x06\b\x05\x05§:String = "t*";
      
      public static var §\x07\x07\b\x07\x04\x06\x02\b\x03\x06\x04\x04\x06§:String = "$Tribu";
      
      public static var §\x02\x03\b\b\x05\x07\x05\x02\x02\x04\x07§:String = "Code";
      
      public static var §\x02\x07\x06\x04\x04\x05\b\x05\x05\x02\b\b§:String = "$SeConnecter";
      
      public static var §\x03\x03\b\x07\x05\x07\x06\x05\x03\x04\x07\x06\x03§:String = "$ErreurAuthGoogle";
      
      public static var §\x04\x03\x05\x01\b\x02\x04\x05\x03\x03\x06§:int = 3806 + -3257;
      
      public static var §\b\x04\b\x07\x04\x02\b\x03\x06\x04\x02\x04§:String = "$CadreLogin";
      
      public static var §\x06\x04\x03\b\x05\x02\x04\b\x04\x06\b§:String = "https://www.youtube.com/watch?v=";
      
      public static var §\b\b\x07\x01\x03\x06\x06\x04\x03\x04\x05\x03\x02§:String = "x_transformice/x_divers/";
      
      public static var §\x05\x04\x03\x03\x06\x01\b\x03\x01\x03\x07\x02§:String = "https://www.twitch.tv/noisette_801";
      
      public static var §\x03\x01\x05\x03\x07\x01\b\x01\b\b\x07\b§:String = "$MDP_Contient_Pseudo";
      
      public static var §\x05\b\x03\x02\x06\x02\x05\x06\x02\x02\b\x05\x04§:String = "$MDP_8caract";
      
      public static var §\x02\x07\x04\b\x06\b\x02\x01\x01\b\x01§:String = "$authentification.erreur.8";
      
      public static var §\x06\x02\x02\x03\x03\x03\x05\x07\x03\x04\x01\x03§:String = "$ListeSalons";
      
      public static var §\x02\x04\x02\x06\x02\x04\x06\b\x04\x01\x06\b\x03§:String = "x_commun/x_iconesjeux/x_bb.jpg";
      
      public static var §\x04\x01\b\x02\x01\x03\x05\x06\x06\x02\x02\x07\x03§:String = ")</G></font>";
      
      public static var §\x01\b\x07\x06\x02\b\x05\x04\x04\x07\x03\x02\x07§:String = "$SalonDuréePartie";
      
      public static var §\b\x05\x04\x04\x02\b\b\x04\x05\x06\b\x04§:int = 7576 + -5555;
      
      public static var §\b\x07\x07\x03\x03\x07\x05\x05\x07\x04\x04\x06\x02§:String = "$Sondage_Reponse";
      
      public static var §\x06\x05\x01\b\x01\x02\b\x04\x04\x01\x05\x02§:String = " <BL>(";
      
      public static var §\x05\x06\b\x03\x06\x05\b\x03\x01\x03\x02§:String = "report";
      
      public static var §\b\x02\x06\x05\x07\x05\b\x01\x04\x04\x02\x06§:String = "hp?";
      
      public static var §\x03\x03\x05\x06\x04\x07\x06\x07\b\x04\x06§:String = "vY";
      
      public static var §\x07\x01\x04\x03\x03\x07\b\x01\x02\x02\x03\x01\x06§:String = "$ErreurGeneriqueSurvenue";
      
      public static var §\x04\b\x04\x04\x05\x03\x05\x07\x04\x01\x05\x04\x05§:String = "ouvrirPageNavigateur";
      
      public static var §\x03\x06\x06\b\b\x03\x01\x01\x04\b\b§:String = "x_transformice/x_badges/x_";
      
      public static var §\b\b\x06\x02\b\x01\x06\x07\x05\x03\b§:String = "ame";
      
      public static var §\x06\x06\x05\x04\x05\x03\x03\b\x03\b\x04§:String = "F6";
      
      public static var §\x01\x03\b\b\x05\x03\x07\x03\x02\x05\x07\x02§:String = "Numpad 9";
      
      public static var §\x05\x04\b\x01\x05\x03\x07\x05\x05\x07\b\x02§:String = "U";
      
      public static var §\x01\x01\b\x02\x02\b\b\x06\x04\x05\b§:String = "L";
      
      public static var §\x06\x03\x04\x04\x07\x06\x01\x03\b\x02\x06\x06§:String = "Insert";
      
      public static var §\x01\x03\x03\x01\x06\x04\x01\x07\x01\x02\x01\x01§:String = "showRegistrationBox";
      
      public static var §\x03\x05\x04\x03\x02\x07\x04\x01\x06\x04\x03\x06\x03§:String = "requestItemList";
      
      public static var §\b\x03\x02\x03\x04\x06\x05\x02\x04\x04\x07\x04§:String = "isGuest";
      
      public static var §\x04\b\x02\x02\x01\x01\x03\x01\x06\x01\x01§:String = " + ";
      
      public static var §\x02\x03\x05\x02\x07\x07\b\x02\x07\x05\x03\x06§:String = "None";
      
      public static var §\b\x05\x05\x06\x05\x03\x06\x01\x01\x02\b\x06§:int = 2089 + -71;
      
      public static var §\x02\x07\b\x06\x05\x02\x01\b\x04\x05\x03\x05§:String = "##";
      
      public static var §\x01\b\x03\x07\b\x06\x07\b\x07\x02\x04§:int = 8475 + -8467;
      
      public static var §\x07\x04\x02\x06\x04\x02\x05\x06\x05\x06\x03\b§:String = "spriteDebug";
      
      public static var §\b\x07\x02\x07\x01\x01\b\b\x07\x05\x05\b§:String = "Ligne du curseur introuvable";
      
      public static var §\x06\x05\x05\x06\x04\x01\x01\x07\x01\x01\x01§:int = 9047 + -8905;
      
      public static var §\x01\x02\b\x04\x06\x06\x03\x02\x02\x01\x05\x04\b§:int = 5113 + -5026;
      
      public static var §\x05\x01\x02\x04\x06\x07\x04\x04\x03\b\b\x01§:int = 9898 + -9223;
      
      public static var §\b\x02\b\x04\x06\x04\x02\x06\x04\x07\x03\x06\b§:int = 2439 + -2174;
      
      public static var §\x02\x01\x07\x06\x02\x01\x03\x03\x03\x04\x06\x02\x05§:String = "mous";
      
      public static var §\x05\x07\x06\x04\x03\x07\x07\x02\x06\x04\x03\x06§:String = "defilante_mort.png";
      
      public static var §\x01\x06\x03\b\x06\x07\x07\x07\x05\x02\x05\x07§:int = 1901 + -1784;
      
      public static var §\x02\x03\x05\x02\x01\x02\x02\x02\b\x04\x03\x05\b§:String = ";";
      
      public static var §\b\x02\x01\x04\x06\x06\x07\b\x01\x07\x01\x04§:int = 6053 + -5705;
      
      public static var §\x04\x07\x02\x06\b\x04\x07\x02\x05\b\b\x05§:String = "x_commun/x_iconespaiement/x_logo_g2apay.png";
      
      public static var §\x01\x07\x05\x05\x06\x06\x04\x03\x06\x03\x01\x02\x06§:String = "&ids=289625&idd=1";
      
      public static var §\x04\x03\x01\x05\x02\x01\b\x03\x05\x05\x07\x01§:String = "c";
      
      public static var §\x07\x05\x03\x07\x04\x05\b\x05\x07\x05\x01§:String = " (";
      
      public static var §\x04\x07\x01\x02\x04\x05\x02\x05\x05\x06\x02§:String = "i";
      
      public static var §\x07\x03\x01\x04\x06\x04\x03\x02\x06\x03\x07\x05§:String = "Distance : ";
      
      public static var §\x07\x05\x03\x05\x01\x06\x06\x01\x04\x06\x07\x03\x07§:int = 2795 + 5387;
      
      public static var §\x01\x01\x07\x04\x07\x06\x02\x02\x03\x03\x05\x01§:String = "left";
      
      public static var §\x05\x01\b\x02\x07\x05\x06\x01\x02\x05\b\b§:String = "VP";
      
      public static var §\x07\b\x05\x05\x06\x05\x01\x02\x07\x01\x04\x02\x06§:String = "D";
      
      public static var §\x02\x06\x06\x02\x03\x02\x06\x04\x02\x02\b\b\b§:String = "#60608F";
      
      public static var §\x04\x07\x06\x04\b\x01\x01\x01\x01\x07\x04\x06§:String = "J";
      
      public static var §\x02\x03\x03\x06\b\x04\x07\x03\x05\b\x01\x06\x03§:String = "$Souris";
      
      public static var §\x01\x04\x02\x04\x05\x07\x07\x03\b\x01\x05§:String = "$Ballon";
      
      public static var §\x04\x07\x06\x06\x01\x04\x01\x07\x02\b\x03\b§:String = "ps";
      
      public static var §\x04\x07\x01\x02\x05\x07\b\x04\x06\x07\x02\b\x03§:String = "nosouris";
      
      public static var §\x06\x06\x03\x05\x02\x04\x07\b\x05\x04\x03\x02§:String = "rt";
      
      public static var §\x07\x05\x06\x03\x07\x01\x04\x07\b\x02\x05\x01§:String = "son";
      
      public static var §\x01\x03\x01\x06\x07\x03\x04\x07\x03\b\x03\x07§:String = "ev";
      
      public static var §\x05\b\x07\x06\x07\x07\x02\x07\x01\x04\x05\x01§:String = "mort";
      
      public static var §\x03\x01\x02\b\x01\x03\x03\x03\x05\b\x06\x04§:String = "sauvertotem";
      
      public static var §\x01\x02\x03\x02\x04\x02\x06\x07\x07\x06\x05\b§:String = "Chargement des ressources graphiques";
      
      public static var §\x05\x07\x03\b\x03\x01\b\b\x05\x01\x02\b\b§:int = 7839 + -7369;
      
      public static var §\x05\x05\x04\x01\x06\x07\b\x05\x03\x04\x04\b§:int = 7791 + -7767;
      
      public static var §\x03\x01\x03\x01\x05\x05\x03\x01\x07\b\x04\b\b§:int = 9910 + -9130;
      
      public static var §\x02\x07\x05\x05\x01\x02\x03\b\x07\x04\x05\x07\x07§:int = 4189 + -4186;
      
      public static var §\x06\x03\x04\x06\b\x05\x07\x02\x06\b\x06\x01§:String = "Choix : ";
      
      public function §\b\x05\x06\x07\x07\x01\x03\x01\x06\b\x07\x06\x02§()
      {
         super();
      }
      
      public static function §\x04\x06\x04\x02\x01\b\x05\x07\b\b\x01§() : int
      {
         return 5412 + 56460056;
      }
      
      public static function §\x04\x03\x02\x01\x01\x07\b\x05\x04\x01\x01\x01\x04§() : int
      {
         return 3465 + -3352;
      }
      
      public static function §\x03\x07\x05\b\x01\x04\x02\x01\x06\b\x04\x03\b§() : int
      {
         return 4411 + 10769916;
      }
      
      public static function §\x07\x03\x07\x04\x02\b\x05\x03\x04\x06\x02\b\x05§() : int
      {
         return 1534 + -1388;
      }
      
      public static function §\x07\x02\b\x05\x01\x01\x03\x03\x03\b\b\x03\x03§() : int
      {
         return 3424 + -3333;
      }
      
      public static function §\x03\x06\x01\x01\x05\x02\x03\x07\x03\x07\x03\x05§() : int
      {
         return 1734 + -1334;
      }
      
      public static function §\x06\x05\x05\x01\b\x02\x07\x05\x02\x02\x01\b\b§() : Number
      {
         return (953 + -952) / (7886 + 92114);
      }
      
      public static function §\x02\x04\x03\x03\x02\b\x04\x05\x01\x05\x02\x03\b§() : int
      {
         return 822 + -761;
      }
      
      public static function §\b\x06\x01\x01\x02\x07\x06\x06\x01\x05\x06\x05\x03§() : int
      {
         return 8067 + -7950;
      }
      
      public static function §\x04\x05\x03\x07\x06\x03\x03\x03\x06\x03\x03\x03§() : int
      {
         return 8450 + -8340;
      }
      
      public static function §\x06\x05\x06\x03\x07\x03\x04\x04\x05\x05\x06\x05\b§() : int
      {
         return 1987 + -1922;
      }
      
      public static function §\x04\x02\x01\x01\x03\x02\x03\x05\x07\x03\x03\x01\x07§() : int
      {
         return 7589 + -7411;
      }
      
      public static function §\x07\x02\x03\x07\x02\b\b\x05\x01\x07\b\x06§() : int
      {
         return 8646 + -8561;
      }
      
      public static function §\b\x03\x01\x04\x03\x01\x04\x04\x07\x05\x02\x04\x03§() : int
      {
         return 7367 + -7335;
      }
      
      public static function §\x03\x02\x04\x01\b\x02\x01\x05\x05\x04\x07§() : int
      {
         return 1450 + -1417;
      }
      
      public static function §\x07\x04\x07\x05\x07\x05\x06\x03\x07\x06\x06\x06§() : int
      {
         return 9343 + -9273;
      }
      
      public static function §\x01\x06\x07\x01\x01\x02\x06\x06\x07\x06\x03§() : int
      {
         return 2442 + -2309;
      }
      
      public static function §\x01\x06\x05\x02\b\x04\x04\x05\x05\b\x07\x03§() : int
      {
         return 8478 + -8312;
      }
      
      public static function §\x07\b\x04\x05\x03\x01\x04\x03\x01\x05\x05§() : int
      {
         return 3476 + -3388;
      }
   }
}

