package
{
   public class §\x01\x07\x05\x04\b\x07\x07\x01\b\b§
   {
      
      public static var §\x07\x04\x01\x06\x05\x04\x03\b\x05\b\x01\x01\x03§:String = "ajout objet : 7";
      
      public static var §\b\x01\x04\b\x07\x01\x04\x03\x04\x01\x06\b§:int = 1419 + 1079;
      
      public static var §\b\x07\b\b\x02\x04\x07\x05\x04\x02\x01\x03§:String = "$Chauvesouris";
      
      public static var §\b\x07\x04\b\x07\b\x01\x02\x05\x07\x02§:String = "x_transformice/x_interface/2.png";
      
      public static var §\x02\x04\x03\b\x07\x04\b\x01\x01\x05\x05\b\x01§:String = "$Inventaire";
      
      public static var §\x06\x03\x03\b\x07\x04\x03\x02\b\x05\x06§:int = 4956 + -4230;
      
      public static var §\b\x02\x04\x06\x03\x03\x07\b\x03\x03\x05\x01§:Number = (6782 + -6695) / (4773 + -4673);
      
      public static var §\x07\b\x02\x04\x05\x02\x02\x04\x01\x07\x05\x07\x02§:Number = (4160 + -3979) / (4995 + -4895);
      
      public static var §\x07\x05\x06\x04\x06\x02\x01\x02\x01\x03\x01§:Number = (210 + -51) / (1744 + -1644);
      
      public static var §\x04\x07\b\x03\x02\x04\x02\x05\x04\x01\b§:Number = (2647 + -2518) / (6458 + -6358);
      
      public static var §\x01\x01\x06\x06\x04\x04\x01\x01\x03\x04\x03\b\x03§:Number = (1991 + 14675) / (4688 + -3688);
      
      public static var §\x03\x04\x03\x07\x01\x07\x07\x02\x07\x02\x05§:String = "myrtilles_fleur.png";
      
      public static var §\x05\x03\b\x04\x03\x04\x04\x05\x05\x05\x06\x06§:String = "$Enlever";
      
      public static var §\x02\x07\x03\x03\x02\b\x06\x04\b\x03\b\x07\x03§:String = "<font color=\'#00D0D0\'>";
      
      public static var §\x07\x04\x02\x02\x04\x07\x07\x04\x06\x02\b\x05§:String = "$AcheterTenueComplete";
      
      public static var §\x02\x02\x04\x07\x01\x02\x02\x03\x02\x04\x04§:String = "Mode miroir : ";
      
      public static var §\b\x02\b\x02\x07\x07\b\x06\x04\x02\x01\x04§:String = " = ";
      
      public static var §\x04\x03\x06\x05\x03\x02\x05\x05\x06\b\x07\x02\x05§:String = "exporter_costumes";
      
      public static var §\x02\x01\x04\x06\x01\x05\x05\x02\b\x03\x03\x05\x06§:String = "nuit";
      
      public static var §\x06\x04\x01\x05\x05\b\x07\x01\x02\x05\x01\b\x03§:String = "chapeaux.png";
      
      public static var §\b\x06\x05\b\x01\x05\x06\x04\x02\x07\x07\x03\b§:String = "coloration";
      
      public static var §\x04\x04\x07\x07\b\x02\x06\x04\x06\b\x01\x07§:String = "$ConsoInterdit";
      
      public static var §\x07\x02\x06\x04\x01\x03\x04\x07\x01\x04\x02\x02\x04§:String = "Mmmmh...";
      
      public static var §\x03\x02\x01\x02\x02\x07\x03\x05\b\x07\x04\x07\b§:String = "$competence/sauvageonne";
      
      public static var §\x03\x02\x06\b\x07\x07\x04\x01\x01\x05\x07\x07§:int = 4126 + -3758;
      
      public static var §\x04\x01\x02\x01\x07\x06\x01\x01\b\x07\x03\x03§:String = "</font><font color=\'#60608F\'> & </font>";
      
      public static var §\x07\x03\x03\x01\x02\x03\x05\x03\x03\x02\x05\x07§:String = "$Inventaire_VeutPasEchanger";
      
      public static var §\x02\x05\x04\x07\x04\b\x06\x05\x07\x01\b\x07§:String = "[<a href=\'event:echange_ignorer;";
      
      public static var §\x01\x05\x07\b\x06\x03\x04\x02\x07\x04\x01\x01§:String = "$QueteJournaliere";
      
      public static var §\x03\x07\x07\x02\x07\x02\x02\x01\x05\x03\x03\x03\x04§:int = 4651 + -4295;
      
      public static var §\x01\x06\x04\x05\x02\x01\x04\x06\x07\x03\b\x03§:int = 3459 + -2664;
      
      public static var §\x03\x01\x06\x05\x07\x01\x05\b\x06\x02\b§:String = "Bootcamp : <V>";
      
      public static var §\x01\b\x02\x04\x01\x04\x02\x07\x01\x01\x05\x02\b§:String = "$E_Ame";
      
      public static var §\x05\x03\b\x01\x03\x04\x07\b\x07\x04\x06\x03§:String = "\' size=\'-6\'>#";
      
      public static var §\x05\x05\x06\x06\x01\x02\x07\x03\b\x06\x01\x01\x06§:String = "Nickname";
      
      public static var §\x05\x05\x02\b\x06\x06\x04\x05\x06\x02\x04\x06\x04§:String = "$ElectionPresident";
      
      public static var §\x03\x02\x06\x04\x07\x02\x05\x04\x06\x07\x05\x02\x04§:String = "<font color=\'#A0A0A0\'>★★</font>";
      
      public static var §\x07\x04\b\x06\x05\b\x02\x06\x05\x04\x01\x06§:String = "<font color=\'#AA8066\'>*</font>";
      
      public static var §\x01\x07\b\b\x04\x05\x01\b\x03\x01\x02\x01\x01§:String = "$C_GuideSprirituel";
      
      public static var §\x06\x02\x01\x03\x02\x01\x03\x02\b\x03\x05\x05\x01§:String = "x_i_93.png";
      
      public static var §\x06\x01\x01\x07\b\x05\x03\x06\x01\b\x02\x01§:String = "x_i_88.png";
      
      public static var §\x05\x06\x04\x06\b\x01\x07\x06\x04\x06\x03\x05§:String = "x_i_45.png";
      
      public static var §\x01\x03\x04\b\b\x04\b\x01\b\x06\x04\x02\x05§:String = "x_i_34.png";
      
      public static var §\x04\x01\x07\x07\x06\b\x03\x07\x06\x02\x06§:String = "x_i_3.png";
      
      public static var §\x01\x05\x07\x03\x02\x06\x04\x01\x07\b\x01\x01§:String = "chat_fond_entree";
      
      public static var §\x05\x01\x03\x07\b\x01\x04\x05\x07\x05\x05\x01\b§:String = "$Sol_Rebond";
      
      public static var §\x02\x02\x01\x04\x07\x01\b\b\x04\x02\x03§:String = "acc";
      
      public static var §\x01\x01\x02\x07\x07\b\x05\x02\x01\b\x05\x03\x06§:String = "angDampMax";
      
      public static var §\x04\x05\x03\x01\x03\x06\x03\x05\x01\x01\x06§:Number = (5887 + -5886) / (2417 + 97583);
      
      public static var §\x05\x01\x07\x01\x03\x07\x03\b\x06\x06\x03\x05\x04§:int = 899 + 1476;
      
      public static var §\x02\x06\b\x01\x06\x05\x05\x01\x05\x07\x02\x02\x03§:String = "recupSolEditeur";
      
      public static var §\x01\x01\x04\x02\b\x01\x05\x05\x01\x05\x04\x02§:String = "modeGlisseEnCours";
      
      public static var §\b\x07\x03\x01\x02\x03\b\x03\x07\x05\x01\b§:String = "Envoie_Serveur_Satellite";
      
      public static var §\x04\x03\x06\x03\x06\x03\x01\x04\x07\x03\x07\b§:String = "Vignette_Menu";
      
      public static var §\x03\x04\x02\x01\x03\x04\b\x06\x01\b\x02\x06§:String = "ListeInterface";
      
      public static var §\x01\x02\x07\b\b\x03\x05\x03\x05\x03\b§:String = "<a href=\'http://get.adobe.com/flashplayer/\' target=\'_blank\'><font color=\'#ED67EA\'><u>Click here to get the new flash player version !</u></font></a>";
      
      public static var §\x03\x06\x05\x02\x07\x06\b\x06\x02\x02\b\b§:int = 5945 + -5204;
      
      public static var §\x04\x02\x04\x01\x06\x01\x04\x03\x04\x05\x06\x03\x01§:String = "enclume";
      
      public static var §\x02\x03\x05\x01\x04\x06\x01\x06\b\b\b§:String = "planche";
      
      public static var §\x02\x06\x04\x06\x06\x06\x05\x06\x04\x04\b\b§:String = "$Tatouage";
      
      public static var §\b\x02\x01\b\x04\x05\x02\x05\x04\x02\x02\x07§:String = "scarf";
      
      public static var §\x04\x02\x04\x03\b\b\x05\x06\x03\x05\x01\b§:String = "$OM7";
      
      public static var §\x03\x02\x06\x07\x05\b\b\x02\b\x06\b§:String = "$OM5";
      
      public static var §\x07\x06\x07\x01\b\b\b\x07\b\x02\x05\x02\x06§:String = "coeur_shop";
      
      public static var §\x03\x03\x07\x01\x06\x04\b\x04\b\x04\x01\x03§:String = "x_transformice/x_interface/x_fleche.png";
      
      public static var §\x05\x06\x05\x06\x05\x02\b\x05\x06\x01\b\x04\x02§:String = "$GainMonnaie";
      
      public static var §\x03\b\x02\b\x05\b\x03\x02\x01\x04\x02\x02§:int = 4550 + 7195450;
      
      public static var §\b\x07\x04\x07\x03\x05\x06\b\x07\x06\x07\x02§:String = "$TT_Intervalle";
      
      public static var §\x02\b\x03\x02\x02\x03\x05\x01\x06\x04\x03\x04\x04§:String = "$D_Mort";
      
      public static var §\x06\b\x07\x04\x06\x05\b\x03\x06\x02\x04\x02§:String = "$D_Attaque";
      
      public static var §\x03\x02\x01\x07\x03\x05\b\b\x07\x06\x07§:String = "$FX_poison_1";
      
      public static var §\x06\x07\x03\x04\x05\x01\x03\x07\x06\x06\x03\x05\x03§:String = "combat/blocage";
      
      public static var §\x01\x06\x03\x04\x04\x06\x03\x01\x01\b\x03\x07§:String = "combat/feinte";
      
      public static var §\x02\x04\x04\x05\x06\x02\b\x07\x02\x01\b\x07\b§:String = "attaque_2_1";
      
      public static var §\x02\x03\x03\x02\x03\b\x01\x05\x07\x02\x06§:String = "$AnimMort_retraite";
      
      public static var §\x04\x07\x07\x04\x07\x07\x07\x06\x06\x02\x02\x03\x03§:String = "manip";
      
      public static var §\x06\x02\x01\x04\x03\x06\x05\b\x05\x03\b\x02§:String = "monstres/m_";
      
      public static var §\x06\x06\x05\x03\b\b\x05\x04\x07\x07\x03\x06§:String = "x_deadmeat/x_interfaces/divers/b2.png";
      
      public static var §\x06\x05\x01\x02\b\x04\x05\b\b\x02\x07\x01§:String = "invi";
      
      public static var §\b\b\x04\x01\x05\x04\x04\x06\x04\x03\x02§:String = "cinematique";
      
      public static var §\x07\x04\x07\x07\b\x05\x03\b\x06\x03\x05\x04\x03§:String = "sauver_groupe";
      
      public static var §\x03\x07\x05\x06\x05\b\x04\x06\b\x07\x03\x05§:String = "def_arme";
      
      public static var §\x03\x03\x04\x02\b\x01\x06\x04\x03\x03\x05\x05§:String = "\n<N>Dégtâts : <V>";
      
      public static var §\b\x07\x06\x04\b\x07\b\x06\x07\x01\x04\b\x01§:String = "x_deadmeat/x_interfaces/principale/bricolage.png";
      
      public static var §\x01\b\x03\x07\x06\x02\x06\x03\x05\x03\x07\x01\x03§:String = "$NiveauSanteMax";
      
      public static var §\x03\x03\x02\x03\x01\x03\x05\x05\x02\x03\x05\x02§:String = "x_deadmeat/x_interfaces/principale/kit/fond_";
      
      public static var §\x03\x02\x05\b\x05\x04\b\x02\x03\x03\x04\x02§:String = "x_deadmeat/x_interfaces/x_action_barre.png";
      
      public static var §\x02\x05\x07\x07\x02\x02\x02\x02\x05\x01\x02§:String = "$RecompensesAventureDM";
      
      public static var §\x04\x06\x06\b\b\x01\x06\x07\x06\x06\x03\x05§:String = "x_deadmeat/x_zone/x_mz_";
      
      public static var §\x04\x07\x01\x01\x04\x05\x07\x02\x06\x05\x02\x05§:String = "$Acheter";
      
      public static var §\x06\x01\x02\x03\x07\x03\b\x02\x06\x01\x01\x01§:String = "<R>remove <N>";
      
      public static var §\x01\x03\x05\x04\x01\b\x01\x07\b\x02\b\x06§:String = "In seconds";
      
      public static var §\x02\x06\x03\x07\x06\b\x06\x03\x01\x05\x03\x04\x06§:String = "monster";
      
      public static var §\x05\x06\x02\x04\x03\x03\x03\x04\x04\x01\x01\x04\b§:String = "enable asynchronous mode";
      
      public static var §\b\x02\b\x02\b\x02\x04\x02\x07\x03\x07\b§:String = "famfamfam/clock.png";
      
      public static var §\x06\b\x01\x06\x01\x06\b\x02\x02\x02\x03\x07§:String = "<O>move to";
      
      public static var §\x02\x05\x07\x02\x06\x05\x04\x03\b\x07\b§:String = "action";
      
      public static var §\x01\x06\x04\x03\x01\x07\x04\x07\x01\x04\x07\x01§:String = "$PlusDeMission";
      
      public static var §\x04\x06\b\x04\x06\x06\x05\x01\x01\x04\x07\x05\b§:String = "$SC_Titre";
      
      public static var §\x03\x06\x06\x06\x03\b\x05\x05\b\x02\b\b§:String = "fusee";
      
      public static var §\x02\x07\x01\x04\x01\x02\x03\x06\x02\x02\x07\b§:String = "$VolumeSon";
      
      public static var §\x04\x05\x01\b\x01\x02\x07\x03\x05\x05\x02\x05§:String = "$bordure_haut_gauche";
      
      public static var §\x02\x06\x05\x07\x01\x03\x06\x07\b\x01\x06\x04\x02§:String = "Wallace";
      
      public static var §\x01\x05\x02\x05\b\x06\x03\x01\x04\b\x01§:int = 7873 + -7413;
      
      public static var §\x06\x03\x07\x06\x02\x05\b\x07\b\x06\x01\x03§:String = "$RefuserInvitation";
      
      public static var §\x07\x02\x04\x02\x03\x05\b\x02\x07\x02\x07\x01§:String = "x_deadmeat/x_interfaces/coffres/coffre-ouvert.png";
      
      public static var §\x07\b\b\b\x06\b\x01\x02\x01\x06\x07\x02\x07§:String = "x_deadmeat/x_interfaces/forge.png";
      
      public static var §\x04\b\x06\x06\x02\x07\x07\x04\x01\x03\x05\x07\x07§:String = "$Ensemble";
      
      public static var §\x06\x03\x01\x04\x06\b\x03\x02\x03\x07\x06\x04§:String = "$type_effet.33.nom";
      
      public static var §\x02\x04\x03\x01\x06\x04\x04\b\b\x04\x06\x02§:String = "\n<font color=\'#5ED2FF\'>";
      
      public static var §\x04\x03\x06\x07\x03\x03\x03\x07\x06\x07\x04\x01§:String = "$Perime";
      
      public static var §\x02\x01\x05\x04\x06\x05\x07\x01\x04\x04\b§:String = ".desc";
      
      public static var §\x03\x06\x05\x02\x02\x05\x06\x01\x03\b\x05\x02\x03§:String = "$CompActive";
      
      public static var §\b\x03\x01\x02\b\x06\x01\x06\x06\x02\b§:String = "rightClick";
      
      public static var §\x01\x05\x04\x02\x03\x01\x03\x02\x03\b\x02\x01§:String = "radial";
      
      public static var §\x07\x02\x07\x02\x01\x05\b\x07\x04\x01\x01\b\x03§:String = "x_deadmeat/x_interfaces/expedition/expedition.png";
      
      public static var §\x05\x04\x01\x07\x03\x05\x06\x05\x01\b\x04\x06§:String = "$zone.";
      
      public static var §\x05\b\x01\x05\b\x02\x02\x02\x03\x07\x03§:Number = (6985 + -6670) / (4249 + -4149);
      
      public static var §\b\x06\b\b\x06\x06\b\x02\x06\x01\x05§:String = "$TutoConteneur";
      
      public static var §\b\x05\x02\x07\x07\x04\x02\b\b\b\x03\x03\b§:String = "x_deadmeat/x_interfaces/divers/pomme.png";
      
      public static var §\x02\x06\x05\b\x02\x07\b\x03\x05\b\x06§:String = "« <I>";
      
      public static var §\x03\b\x04\x05\x06\x06\x05\x02\b\x04\x01\x06\x01§:String = "$EditeurPlaceholderNouveauScript";
      
      public static var §\b\x01\x06\x03\b\x03\x02\x07\x05\x03\x02\x02§:String = "narration";
      
      public static var §\x06\b\x05\b\x05\x01\b\x04\b\x03\b\x02§:String = "Ground";
      
      public static var §\x04\x02\x06\x04\b\x01\x04\x03\b\x05\x07\x04§:String = "<R>You must select an item before performing this action.";
      
      public static var §\x07\x06\x07\x07\x03\x01\b\x02\b\x07\x06\x01§:String = "$text.error";
      
      public static var §\x01\x05\x05\x05\x06\x05\x01\x07\b\x03\x05\x07\x02§:String = "PL";
      
      public static var §\x06\b\x02\b\x02\x06\x05\x07\x03\x03\x01\x05§:String = "$EditeurTitreGestionLanguesTraductions";
      
      public static var §\x04\x02\x07\x01\x03\x05\x03\x05\x05\x02\x05\x07§:String = "liste";
      
      public static var §\x05\x04\b\x04\x03\x06\x01\x01\x05\x06\x01\x02\x05§:String = "doubleClick";
      
      public static var §\x05\x01\x03\b\b\x01\b\x04\x07\x02\b§:String = " <BL><font size=\'10\'>(";
      
      public static var §\x03\x02\x03\x05\x03\x07\x02\x01\x05\x06\x02\x03\x07§:String = "aplat";
      
      public static var §\x04\b\b\x07\x06\x01\x05\x02\x01\b\x01\x02§:String = "$CadrillageCafe";
      
      public static var §\x01\x06\x03\x01\x01\x05\x05\x01\x05\x03\x01\x03§:Number = (3167 + -3139) / (7169 + -7159);
      
      public static var §\x07\x02\x06\x04\x01\b\x06\x06\x07\x02\x07\x01§:String = "http://192.168.0.2/deadmeat/assets_prod/d_";
      
      public static var §\x03\x05\x04\x06\x05\x07\x07\x06\x04\x05\x01\x06\x06§:String = "Sacs_01.swf";
      
      public static var §\x02\x03\x07\x01\x05\x06\x06\x05\b\x05\x04§:String = "Hauts_03.swf";
      
      public static var §\x05\x06\x07\x05\x04\b\x03\x01\b\x05\b\x03\x07§:String = "<V>ok</V>";
      
      public static var §\x04\b\x04\x07\x01\x05\x06\x06\x07\x05\x04\x04§:String = "$FX_33";
      
      public static var §\x03\b\x07\x03\x06\x07\b\x03\x07\x04\x07\b§:String = "$ParticuleCombat_";
      
      public static var §\x05\x02\x06\b\b\x03\x02\x03\x02\x03\x03§:String = "openedWindows";
      
      public static var §\x03\b\x02\x07\x02\x02\x06\x03\x05\x01\b\x02\x05§:String = "$CategorieAction_Deplacement";
      
      public static var §\x07\x03\x06\b\x07\x05\x03\x03\x07\x01\x04\x06\x02§:String = "x_deadmeat/x_interfaces/lvl-up.png";
      
      public static var §\x02\b\x04\x07\b\x02\b\x06\x04\x05\x06\x04\x01§:String = "<-- [";
      
      public static var §\b\x07\b\x03\b\x02\x04\x05\b\x06\x06\x01§:String = "$AideChamane";
      
      public static var §\x05\x07\x05\x05\x06\x07\x01\x06\x07\x06\x02\x02\x04§:String = "particuleEnBoucle principale";
      
      public static var §\x04\x07\b\x05\x04\b\x07\x06\x02\x05\x02\x07§:String = "$ChatStatique";
      
      public static var §\x03\x01\b\b\x06\x01\x01\x06\x02\x02\x06§:String = "sq";
      
      public static var §\x05\b\x01\x04\x02\x01\x01\x06\x06\x06\x06\x07§:String = "AnimCry";
      
      public static var §\x02\x02\x01\x01\x06\x03\x01\x05\x04\x02\x03\x06§:String = "$Bleu";
      
      public static var §\b\x01\x07\x03\x05\x05\x06\x05\b\x03\x04\x04§:String = "s<BL>";
      
      public static var §\x02\x06\x02\x01\x06\x07\x05\x01\x04\x01\x06\b\x05§:String = "<font color=\'#C69D9E\'>";
      
      public static var §\x05\x07\b\x04\x02\x03\x03\x07\x03\b\x01\x03\x06§:String = "$CadeauJoueur";
      
      public static var §\x04\x07\x02\x04\x03\x04\x03\b\x07\x06\x03\x02\x03§:String = "$Creation_Deja_Tribu";
      
      public static var §\x03\x01\x05\x03\x01\x04\x07\x05\x01\x05\x03\x04§:String = "10";
      
      public static var §\x05\b\x03\x02\x05\x03\x07\x05\x07\x05\x04\x06§:String = "<G>-<BL>";
      
      public static var §\x01\x04\x07\x04\x06\x03\x07\x05\x01\x07\x06\x02\x06§:String = "okBgfIXmqS";
      
      public static var §\x04\x01\x03\x03\x02\x03\x02\x04\x04\x04\x05\x04§:String = "n";
      
      public static var §\x07\x05\x02\x05\x02\x05\x06\x01\x05\x04\x04\x01§:String = "__5__ (";
      
      public static var §\b\x02\x05\b\x02\x05\x06\x07\x07\x05\b\x06§:int = 5177 + -5032;
      
      public static var §\b\x03\x03\x05\x07\b\x07\x04\x03\b\x07\x02\x06§:String = "mc";
      
      public static var §\x06\x07\x07\x05\x02\x04\x03\x04\x06\x01\b§:String = "deadmaze";
      
      public static var §\x05\x02\x03\x03\x05\x01\x05\x06\x05\x06\x03§:String = "$chat.amis.signaleDeconnexionAmi";
      
      public static var §\x01\x03\x02\x02\x03\x03\x06\x07\b\x01\x02\x07§:String = "$erreur.tribulle2.joueurNonConnecte";
      
      public static var §\x07\x02\x05\x06\x02\x05\x04\x05\x06\x04\x04\x03§:String = "<b><V>";
      
      public static var §\x01\x05\x05\b\b\x04\x01\x04\x03\x01\b\x07§:String = "$erreur.tribulle2.limiteAtteinte";
      
      public static var §\x05\x05\x02\x04\x07\x03\x04\x01\b\x05\x06\x06§:int = 5335 + -3278;
      
      public static var §\b\x03\x03\x04\x02\x07\x03\x03\x07\x06\x06\x03\x06§:String = "$TexteVerda";
      
      public static var §\x04\x07\b\x07\x06\x03\x01\x01\x03\x02\x03§:String = "method";
      
      public static var §\x06\x01\x07\x02\x05\x04\x01\x02\b\b\x03§:String = "Italiano";
      
      public static var §\x03\x01\x04\x05\x03\x05\x06\x01\x05\x06\b\x03§:String = "中文";
      
      public static var §\x03\b\x01\x05\b\x05\x02\x06\x02\x03\x05\x06\x03§:String = "content";
      
      public static var §\x02\b\x07\x01\x07\x03\b\x01\x02\x03\b\b§:String = "CrOS";
      
      public static var §\b\x06\b\b\x07\x02\x01\x05\x04\x02\x03\x04§:String = "$PanneauControle";
      
      public static var §\x05\x03\x02\x04\x03\x03\x03\x03\x06\x06\x07\x01\b§:String = " <font size=\'8\'><BV>(";
      
      public static var §\b\x03\b\x07\x02\x03\b\x06\x05\x05\x04\x06§:String = "Chat notifications";
      
      public static var §\x05\x07\x05\x03\x07\x02\x03\x02\x01\x07\x04§:String = "<BV>#>";
      
      public static var §\x05\x07\x05\x03\b\x03\x01\x03\x04\x02\x03\x02§:String = "$historique.tribu.membreExclu";
      
      public static var §\x06\x03\x07\x04\x04\x01\x03\x02\x04\x06\x04§:String = "$QuiInviter";
      
      public static var §\x02\x07\b\x01\x05\x01\x02\x07\x06\x04\x01\x01\x04§:String = "rangs.png";
      
      public static var §\x03\x04\b\x03\x05\x07\x03\x04\x05\x02\x06\x01§:String = "$interface.tribu.bouton.designerChef";
      
      public static var §\b\x04\x02\x04\x05\x07\b\x02\x03\x02\x02§:String = "$CréerPartie";
      
      public static var §\x01\x02\x03\b\x04\x06\x04\x04\x01\x02\b\b\x06§:int = 8571 + -8241;
      
      public static var §\x01\x05\x01\x01\x06\x07\x03\x05\x04\x02\x04\x02\x02§:String = "$Monnaie_0";
      
      public static var §\x03\x03\x03\x03\x05\b\x07\b\x06\x03\b\b§:String = "   <G>|   <N>";
      
      public static var §\b\b\x07\x04\x03\x06\x04\b\x04\x01\x01\x02§:String = "$ModeJeuNom_2";
      
      public static var §\x02\x03\x07\x05\x03\x07\b\x06\x04\x02\b§:String = "x_transformice/x_interface/classement/3.png";
      
      public static var §\x05\x02\x02\x03\b\x06\x05\b\x01\x01\x04\x02§:String = "CMD";
      
      public static var §\x04\x03\x02\x05\x07\x05\x06\x04\x07\x02\b§:String = "] <font color=\'#";
      
      public static var §\x03\x04\x03\x03\x05\b\b\x05\b\x04\x07\x07\x07§:String = "$Chat_Bas1";
      
      public static var §\x02\x04\x01\x03\x06\x01\x01\x06\x06\x03\x06§:String = "canal_";
      
      public static var §\b\x03\x02\b\x02\x06\x02\b\x03\x02\x02\x06\b§:String = "editeur";
      
      public static var §\x07\x04\x04\x07\b\x01\x06\x04\x01\x02\b\x07§:String = "$Recup_MDP";
      
      public static var §\x02\x04\x01\x04\x06\x05\x05\x05\x07\x02\x03§:int = 122 + 121;
      
      public static var §\x07\x01\x04\x01\x05\x01\x07\x03\x05\x07\x02\x07\x05§:String = "0,0,0,0,0,0,17,0,0,0#36#1#7886906";
      
      public static var §\x06\x03\x01\b\x03\x04\x05\x05\x01\b\x03\x04§:String = "$MDP_Identique";
      
      public static var §\x01\x03\x02\x01\x02\x07\x01\x02\b\x07\x06\x05§:String = "[0-9]";
      
      public static var §\x06\x04\x05\x06\b\x02\x02\x06\x04\x06\x07\x06§:String = "$authentification.erreur.10";
      
      public static var §\b\x06\x07\x03\x03\x04\x06\x07\x05\x07\x04\b\x02§:String = "x_transformice/x_interface/smiley3.png";
      
      public static var §\x05\x04\x02\x04\x06\x02\x05\x01\x04\x06\b§:String = "chatlog";
      
      public static var §\x05\x02\x06\x05\x04\x01\b\x02\x03\x01\x01\b\b§:String = "</V><N>]</N> <BL>";
      
      public static var §\x07\x07\x04\x07\x07\x05\x07\x06\x01\x03\x07\x05§:String = "<a href=\'event:clic\'>";
      
      public static var §\b\x02\b\x03\x07\b\x04\x06\x05\x01\x07§:String = "<N>";
      
      public static var §\x01\x04\x02\x07\x02\x03\x03\x01\x03\x04\x06§:String = "<VP><font size=\'14\'>";
      
      public static var §\x01\x05\x06\x05\x07\x04\x01\x05\x03\x05\x02\x02§:Number = (3240 + -3238) / (9834 + -9734);
      
      public static var §\x02\x03\x06\b\x07\x07\x06\x04\x03\x06\x03\x05\x03§:String = "$café.règles";
      
      public static var §\x04\x07\b\x02\x07\x01\b\x01\x07\x03\x05\x02§:String = "<font size=\'10\'><V>";
      
      public static var §\x01\x05\x04\x07\x05\x01\x02\x06\x04\x07\x01§:String = ">(.*?)[\n\r]+";
      
      public static var §\x05\x07\x05\x07\x01\x04\x07\b\x06\b\x02\x04\b§:String = "^>(.*?)$";
      
      public static var §\x06\x01\x03\x02\b\x02\x03\b\x01\x03\x05\x04§:String = "<b>$1</b>";
      
      public static var §\x01\x03\x02\x01\x07\x05\x01\x02\x03\x02\x04\x05\x07§:String = "$Message";
      
      public static var §\x03\b\x07\x05\x06\x05\x04\x05\x02\x06\b\x01\x06§:String = "&to=";
      
      public static var §\x04\b\x04\x03\x02\x04\x04\x01\x01\x03\b\x07\x07§:String = ".png";
      
      public static var §\x03\x04\b\x05\x01\x01\x02\x07\x04\x02\x04§:String = "definirPleinEcran";
      
      public static var §\x03\x04\x05\x03\x06\x04\x02\x07\x07\x05\x03§:String = "F10";
      
      public static var §\x06\x05\x03\x04\b\x06\x03\x03\x02\x05\x04§:String = "\'";
      
      public static var §\x01\x07\x04\b\x02\b\x03\x01\x06\x03\b§:String = "Delete";
      
      public static var §\b\x04\x05\x01\x06\x05\x02\x01\b\x06\x03\x05\x01§:String = "End";
      
      public static var §\x02\x05\x04\x05\x03\x01\x05\x05\x01\x07\x05§:String = "</BL>";
      
      public static var §\x01\x03\x03\x06\x04\x01\x06\x04\x03\x07\x01§:String = "</R> mo\n<V>";
      
      public static var §\x04\x07\x07\x01\x06\x04\x05\x06\x04\x05\x07§:String = "authentifierSurGoogle";
      
      public static var §\x01\x02\x07\b\x07\b\x01\x02\x05\x02\x06\x03\x01§:Number = (1418 + 14289) / (6527 + 3473);
      
      public static var §\b\b\x07\x03\x06\x07\x01\x07\x07\x01\x01\x05§:String = "rightMouseDown";
      
      public static var §\b\x06\x02\b\x03\x02\x02\x03\x07\x02\x06\x03\x04§:int = 9181 + -9135;
      
      public static var §\b\x02\x07\b\x02\b\x05\x07\x04\x02\x04\b\b§:String = "$Sol_Dur";
      
      public static var §\x03\x03\x04\x01\x04\x05\x01\x03\x04\x04\x03\x02\b§:Number = (7923 + -7873) / (9876 + -9866);
      
      public static var §\x02\x03\x02\x03\x01\x02\x06\x02\x01\b\x07\x04\x01§:int = 4538 + -4194;
      
      public static var §\x05\x04\x06\x01\b\x03\x04\b\x06\x03\b\x06§:int = 6267 + -6162;
      
      public static var §\x03\x02\x06\x04\x03\x01\b\x03\x04\x05\x07§:int = 1760 + -1531;
      
      public static var §\x05\b\x05\x04\b\x01\x01\x04\x07\x02\x04§:int = 5856 + -5672;
      
      public static var §\x04\x05\x02\x01\x07\b\x07\x06\x03\x01\x06\x01§:int = 4378 + -4185;
      
      public static var §\x06\x02\x05\x07\x06\x07\x07\x01\x01\x07\x05\x01\x04§:int = 3935 + -3679;
      
      public static var §\x07\x05\b\x01\x05\x02\x02\x06\x04\x05\x05\x07\x05§:int = 3418 + -3261;
      
      public static var §\b\x07\x07\x01\b\b\x01\x06\x03\x01\x07\x05\x03§:int = 1735 + -1671;
      
      public static var §\x07\x05\x06\x07\x05\x05\x01\x02\x01\x07\x06\x03\x07§:String = "ouseX";
      
      public static var §\x03\b\x03\x07\x03\x06\x04\x06\x03\x04\x04\x03\x02§:int = 999 + -913;
      
      public static var §\x02\b\x03\x07\x05\b\x03\x06\x05\x07\x03\x01§:String = "<R>";
      
      public static var §\x07\b\x06\x07\x07\x07\x06\x06\x07\x07\b\b§:String = "$bouton.ok";
      
      public static var §\x03\b\b\b\x06\x05\x04\x03\x04\x07\x07\x04§:int = 1950 + -1803;
      
      public static var §\x04\x05\x01\b\x03\x05\x03\x07\x01\x05\x05\x05\x04§:String = "[pwetpwet] ";
      
      public static var §\x06\x03\x01\x07\x01\x02\x01\x02\x05\x06\x04\x05§:String = "quitter";
      
      public static var §\x06\x07\b\x06\x01\b\x06\x07\x01\x06\b\x07§:String = "Incorrect version, try to reload the game.";
      
      public static var §\x04\x02\x02\x07\x05\x04\x01\x04\x05\b\b\x04\x01§:String = "$ClipVignette";
      
      public static var §\x01\x07\b\x07\x03\b\x04\x02\x06\x05\x04§:String = "a:active";
      
      public static var §\x01\x03\x06\x01\x01\x02\x01\b\b\x05\x07§:String = "#F1C4F6";
      
      public static var §\x05\x06\x02\x07\x03\x06\x03\x01\x01\x02\x07§:String = "#2ECF73";
      
      public static var §\x06\x04\x07\b\x03\b\x05\x05\x04\x04\x04\x07§:String = "#9292AA";
      
      public static var §\x04\x05\x07\x03\b\x04\x02\x06\x06\b\x07\x06\x06§:int = 282 + 918;
      
      public static var §\x03\x07\x03\x06\x07\x04\x01\x06\x05\x03\x04\b§:String = "debug";
      
      public static var §\x06\x07\x07\x02\x04\x02\x05\x04\x01\x01\x07\x01§:String = "writeU";
      
      public static var §\x02\x06\x07\x03\x01\x03\x02\x04\x06\x06\x02\x02\x05§:int = 3609 + -3160;
      
      public static var §\x02\x01\x05\x02\x05\x05\x04\x06\x04\x03\x04\x04§:String = "url";
      
      public static var §\x04\x07\x02\x05\x06\x06\x04\x01\x06\x04\x07\x02\x02§:String = "-------------------";
      
      public static var §\b\b\x06\x06\b\b\b\x03\x01\x03\x06\x05\x07§:String = " / ";
      
      public static var §\x04\x01\x02\x02\x02\b\x04\x06\b\x04\x04\x07\x07§:String = "screen";
      
      public static var §\b\x03\x01\x02\x04\x03\x05\x02\b\b\b§:String = "de";
      
      public static var §\x03\x06\x01\x01\x05\b\x06\x03\x01\x05\x01\x04§:String = "Son : ";
      
      public static var §\x06\x06\x04\x02\x07\x02\x05\x05\b\b\x01\x02\x03§:String = ")";
      
      public static var §\x03\x03\x04\x01\x06\x06\x07\x04\x05\x07\x06\x05§:int = 8474 + 991526;
      
      public static var §\b\b\x04\x05\x02\x06\x05\x02\x01\x01\x05\x07\x05§:String = "fb";
      
      public static var §\x05\x06\x02\x06\x02\x07\x03\x01\x04\x02\x04\b§:int = 1557 + -1357;
      
      public static var §\x07\x03\x04\x07\b\x06\x06\b\x02\x02\x04\x06§:int = 1895 + -1815;
      
      public static var §\x04\x05\x05\x05\x04\x03\x07\x03\x03\x05\x01\x06§:String = "velle_Chamane";
      
      public static var §\x02\x01\x04\x04\x02\x03\b\x01\x02\x04\x01\b§:int = 4244 + -3944;
      
      public static var §\x03\x07\b\x07\b\x05\x02\x02\x06\x07\b\x06\x03§:int = 3865 + -3745;
      
      public static var §\x04\x06\x03\x07\x03\x04\x02\x06\x03\x04\x05\x06\x04§:String = "_";
      
      public function §\x01\x07\x05\x04\b\x07\x07\x01\b\b§()
      {
         super();
      }
      
      public static function §\x07\b\x05\x07\x07\x01\x01\x03\x02\x02\b§() : Number
      {
         return (7713 + -6928) / (9194 + -8194);
      }
      
      public static function §\x04\x02\x02\b\x01\x06\x06\x01\b\x06\x05\x02\x05§() : Number
      {
         return (1461 + -1454) / (7599 + -7589);
      }
      
      public static function §\x05\x01\x03\x02\b\x05\x03\x04\x06\b\x07\b\x04§() : Number
      {
         return (1581 + -1451) / (5957 + -5857);
      }
      
      public static function §\x07\x03\x07\x01\x02\b\b\x02\x04\x06\x07§() : int
      {
         return 1615 + -619;
      }
      
      public static function §\x05\x07\x06\x01\x03\x05\x06\x05\x02\x04\x03\x03\x05§() : int
      {
         return 9560 + -8561;
      }
      
      public static function §\x01\x03\x03\b\x04\x04\x05\x07\x01\x06\x06\x06\x04§() : Number
      {
         return (313 + -312) / (3705 + -3695);
      }
      
      public static function §\b\x05\x03\x04\x06\x02\x02\x03\x03\x03\x01\x07\x03§() : int
      {
         return 1721 + -721;
      }
      
      public static function §\x01\x01\x04\x01\x07\b\x05\x02\x05\x04\x04\x02\x07§() : int
      {
         return 807 + -642;
      }
      
      public static function §\x04\b\x04\x03\x02\b\x03\x02\x07\x05\x06\x04§() : int
      {
         return 3079 + -3053;
      }
      
      public static function §\x07\b\x06\x06\x03\x01\b\x02\x05\x03\x03\x04\x03§() : int
      {
         return 8080 + -8014;
      }
      
      public static function §\x01\x06\x03\x05\x04\x06\x04\x04\x02\x06\x03§() : int
      {
         return 9755 + -9665;
      }
      
      public static function §\x06\x04\x07\x05\b\x01\b\x05\x03\x03\b\b§() : int
      {
         return 5517 + -5383;
      }
      
      public static function §\x06\x02\b\x05\b\x05\x02\x01\x05\x05\x03§() : int
      {
         return 3593 + -3573;
      }
      
      public static function §\x02\x04\x06\x06\x07\x05\b\x06\x06\x06\x02\x05\x03§() : int
      {
         return 1348 + -1192;
      }
      
      public static function §\x03\x02\x07\x03\x02\x04\x03\x04\x04\x04\b§() : int
      {
         return 4539 + -4468;
      }
      
      public static function §\x02\x04\x07\x04\x06\x05\x04\x07\x06\x06\b\x07\x07§() : int
      {
         return 5431 + -5312;
      }
      
      public static function §\x05\x07\b\x03\x02\x07\x05\x01\x03\x07\x06§() : int
      {
         return 5715 + -5703;
      }
   }
}

