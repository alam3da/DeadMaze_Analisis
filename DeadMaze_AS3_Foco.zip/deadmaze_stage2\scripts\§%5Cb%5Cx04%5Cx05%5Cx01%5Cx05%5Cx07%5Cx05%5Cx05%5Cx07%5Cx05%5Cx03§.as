package
{
   public interface §\b\x04\x05\x01\x05\x07\x05\x05\x07\x05\x03§
   {
      
      function x_executeSignaleInformationsConnexion(param1:§\x04\x01\x07\x06\x07\b\x05\x05\x06\x01§) : void;
      
      function x_executeResultatChangementGenre(param1:§\b\x01\x07\b\x07\x01\x03\b\x01\x03\x04§) : void;
      
      function x_executeSignaleChangementGenre(param1:§\b\b\x02\x01\x02\x06\x06\x04\b\x07\b\b§) : void;
      
      function x_executeResultatChangementAvatar(param1:§\x06\x06\x07\x01\x06\x04\x07\x07\x04\x04\x01\x03\x07§) : void;
      
      function x_executeSignaleChangementAvatar(param1:§\x01\b\x01\x04\b\x01\x06\x06\x04\b\x04\x03§) : void;
   }
}

