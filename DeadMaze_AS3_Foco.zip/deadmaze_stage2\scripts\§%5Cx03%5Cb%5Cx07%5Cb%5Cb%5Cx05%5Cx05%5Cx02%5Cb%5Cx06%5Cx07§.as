package
{
   public class §\x03\b\x07\b\b\x05\x05\x02\b\x06\x07§
   {
      
      public static var §\x03\x04\x02\x04\x04\x03\x06\x06\x06\x04\x02\x06§:Number = (8907 + -8741) / (1768 + -768);
      
      public static var §\x03\x07\x05\x04\x03\x07\x05\x01\x02\x06\x06\x03\x03§:Number = (9237 + -9012) / (1164 + -1154);
      
      public static var §\x05\x07\x03\x03\x04\x06\x02\x02\x05\b\x07\x07§:String = "(?!^)(?=(?:\\d{3})+$)";
      
      public static var §\b\x03\x03\x06\x01\x03\x07\b\x04\x04\b\x06§:int = 8412 + -7957;
      
      public static var §\x03\x02\b\x07\x04\x07\x02\x04\x06\x05\x07\x02§:String = "x_transformice/x_evt/x_evt_03/0or8meuj/mongolfiere.png";
      
      public static var §\x02\x01\b\x02\x03\b\x05\x06\x04\x04\x07§:int = 6236 + -5296;
      
      public static var §\x01\x02\x04\x02\x01\x04\x07\b\x05\x03\x03\x07\x01§:String = "x_transformice/x_evt/x_evt_20/azctnlhkqsf/bateau-arriere.png";
      
      public static var §\x06\b\x07\x04\x01\x01\x04\x05\x06\x01\x03\x04\x06§:Number = (2688 + -2486) / (5602 + -5502);
      
      public static var §\x06\b\x03\x06\x02\x07\x03\x06\x07\x02\x04\x07§:Number = (5508 + -5172) / (5650 + -5550);
      
      public static var §\x07\x04\x02\x02\x07\b\x07\x03\x02\x02\x07\x02\x05§:String = "paquerette.png";
      
      public static var §\x03\x04\x01\x05\x03\x01\b\x02\x01\x01\x05\b\x04§:String = "x_achat_tenue.png";
      
      public static var §\x06\x07\b\x05\x02\x04\x04\x07\x05\x01\x02§:String = "chr";
      
      public static var §\b\x05\b\b\x02\x06\x04\x07\x03\x05\x06\x04\x02§:String = "coul";
      
      public static var §\x05\x04\x06\x01\x07\b\x02\x02\x07\x01\x07\x03\x03§:String = "AnimNeige";
      
      public static var §\x05\x06\x05\x02\x07\x06\x01\b\x04\x05\x04\x05\x02§:int = 2273 + -1891;
      
      public static var §\x03\x01\b\x07\x04\x05\x06\x02\b\x07\b\x07§:String = "$DateInscription";
      
      public static var §\x01\x03\x01\x03\x02\x03\x07\x02\x05\x03\x06\x07§:String = "text:\\s*(.*)";
      
      public static var §\x06\x01\x01\x05\x06\b\x06\x02\x07\x04\b\x04§:String = "ras";
      
      public static var §\x04\x02\x02\x03\x04\b\x07\x05\x07\x05\x07§:String = "<font color=\'#79ABBB\'>******</font>";
      
      public static var §\x05\x03\x02\x03\b\x05\x02\x06\x07\x03\x07\x04§:String = "<font color=\'#E1B353\'>***</font>";
      
      public static var §\x04\x03\x02\x05\x03\x05\x01\x05\x07\x03\x05\x01\x03§:String = "x_i_72.png";
      
      public static var §\x05\x02\x04\b\x05\x03\x05\x06\x06\x01\x04§:String = "x_i_15.png";
      
      public static var §\x03\x01\x01\x01\x02\x04\x01\x05\x05\x02\x01\x05§:String = "$Sol_Chocolat";
      
      public static var §\x01\x05\x04\x02\x01\x03\x05\x04\x01\x04\x02\x03§:int = 3825 + -3429;
      
      public static var §\b\b\b\x07\x06\x03\x04\x01\b\x01\x04§:String = "Génération carte : ";
      
      public static var §\x03\x07\x01\x03\x06\x03\x03\x05\x04\x01\x04§:String = "_Editeur";
      
      public static var §\b\x07\x05\x04\x01\x06\x02\x05\x07\x04\x01\x02\x07§:String = "TSI";
      
      public static var §\x03\x04\x02\x06\x06\b\x03\x03\x02\x04\x05\x05\x04§:String = "JD";
      
      public static var §\x02\x03\x04\x06\x02\x04\x03\x06\x04\x04\x01\b\x03§:String = "shaman_tools";
      
      public static var §\x02\x01\x04\x03\x02\b\x02\x05\x06\x03\x05\x01§:String = "dodue";
      
      public static var §\x03\x06\x01\x02\x04\x05\x07\x04\b\x01\x01\x04\b§:Number = (3336 + -3315) / (3368 + -3268);
      
      public static var §\x02\x04\x07\x06\x05\x01\x01\b\x07\x05\x05§:String = "archMax";
      
      public static var §\x06\x07\x06\x05\x05\x02\x05\b\b\x05\x05\x02\x04§:String = "$Match_Nul";
      
      public static var §\x07\x06\x04\x07\x06\x03\x02\x04\x04\x04\x02\x05\x03§:String = "x_madchess/x_pieces/x_";
      
      public static var §\x01\b\x06\x04\x02\x01\b\x03\x07\x03\x05\x03§:String = "x_bouboum/x_chargement_serveur.png";
      
      public static var §\x02\x02\b\x02\x04\x03\b\x03\x04\x02\x02\x05§:String = "boulet";
      
      public static var §\x06\x04\x06\x07\x05\x01\x02\x02\x02\x05\x05\x03§:String = "$Mot_Souris";
      
      public static var §\x07\b\x02\x01\x02\x07\b\x01\b\b\x04§:String = "$Nouveautes";
      
      public static var §\b\x07\x07\x04\x02\x01\x03\x04\x02\x06\x06\x06\x03§:String = "$FlecheShop";
      
      public static var §\x05\x01\x07\x02\b\x01\x07\x01\x06\x07\x02§:String = "$CertificationCompte";
      
      public static var §\x06\x01\x07\x07\x01\x01\x07\x01\x05\x04\x03\x01\x07§:String = "[TED] Certifier mail";
      
      public static var §\x01\x05\x02\x02\x03\x03\x07\x02\x06\x07\x01\x04§:String = "bouton_entrerMaison";
      
      public static var §\x01\x04\x03\x04\x01\x02\x04\x07\x06\x02\x02\x07§:int = 2344 + -1987;
      
      public static var §\x04\x07\x01\x05\x07\b\x04\b\x01\b\x02\x06\b§:String = "$Info_Changement_Passe";
      
      public static var §\x07\x06\x03\x05\b\x03\x02\x02\x07\x07\x02§:String = "M_2.png";
      
      public static var §\x06\x06\x05\x06\x05\x07\x01\x06\b\x01\x03§:String = "$PayerBonbon";
      
      public static var §\x04\x06\x04\x04\x01\x02\x07\x02\x04\x03\x06\x02§:String = "$D_Parade";
      
      public static var §\x06\x03\x06\x01\x02\x02\x01\x05\b\x02\x05\x02§:String = "$FX_22";
      
      public static var §\x06\x05\x04\x04\x01\x05\x06\x07\x04\x01\x05\x06\x01§:String = "_touche";
      
      public static var §\x01\x07\x03\x06\x01\x07\x02\x06\x07\x01\x01§:String = "$AnimAttaque_H_2";
      
      public static var §\x03\x03\x07\x06\x01\x05\x05\x01\x07\x02\x02\x01\x01§:String = "$Selection_2";
      
      public static var §\x02\b\x05\x07\x04\x01\b\x07\x03\x01\x06\x06§:String = "interface_victoire";
      
      public static var §\x01\x04\x01\b\x04\x01\x03\x05\x03\x02\x03\x01§:String = "x_deadmeat/x_actions/x_";
      
      public static var §\x06\x05\x06\b\x03\x03\x02\x06\x06\x02\x06\x03§:String = "x_deadmeat/x_interfaces/principale/fond_craft.png";
      
      public static var §\x06\x01\x02\x06\x04\x03\x04\x02\x02\x03\b\b\b§:String = "x_deadmeat/x_interfaces/principale/fond_recyclage2.png";
      
      public static var §\x06\b\x07\x02\x07\b\x05\x01\x04\x07\x07\x06§:String = "x_deadmeat/x_interfaces/x_fond_perso_1.png";
      
      public static var §\b\x01\x02\x06\x07\x04\x02\x05\x03\x07\x06\b\x03§:String = "x_deadmeat/comp/0.png";
      
      public static var §\b\x05\x06\x01\x03\x03\x03\x01\x03\x01\x07§:String = "https://twitter.com/dead_maze";
      
      public static var §\x06\x02\x05\x02\x07\x03\x06\x06\b\x03\x05\x07§:String = "x_deadmeat/x_interfaces/connexion/discord.png";
      
      public static var §\x03\x07\x01\x07\x06\x06\x07\b\x03\x07\x04\x03§:String = "x_deadmeat/x_interfaces/connexion/facebook.png";
      
      public static var §\x04\x04\x07\x04\b\x05\b\b\x04\x02\x07\x03§:String = "$DenominationExpedition";
      
      public static var §\b\b\x06\x06\x02\x05\x05\b\x03\x06\x02\x07\x01§:String = "x_deadmeat/x_zone/x_";
      
      public static var §\x03\b\x06\x04\x01\x03\x05\x04\b\x05\x05\x06\x05§:String = "auto_validation";
      
      public static var §\x06\b\x01\x02\x04\x01\x04\x04\x04\b\x03§:String = "<O>launch script";
      
      public static var §\x04\x05\b\x03\x02\x06\b\x03\x03\x06\x05\x02§:String = "famfamfam/page_white_paintbrush.png";
      
      public static var §\b\b\b\x05\x07\x04\x06\x03\x04\x02\x06§:String = "famfamfam/weather_clouds.png";
      
      public static var §\x01\b\x06\x03\x05\x04\x02\x06\x06\x03\x06\x07§:String = "https://discordapp.com/invite/5ztjNPG";
      
      public static var §\x01\x01\x01\x02\x02\x03\x07\x06\x01\x07\x04\x01§:String = "$SC_Faim";
      
      public static var §\b\x04\x03\x06\x03\x04\x06\x04\x04\x02\x06§:String = "x_deadmeat/x_interfaces/journal/fond.png";
      
      public static var §\x01\x02\x04\x05\x07\x02\b\x07\x06\x04\x03\x02§:String = "190 %";
      
      public static var §\x04\x06\x02\b\x05\x04\x06\x02\x03\x07\x04\x04\x03§:String = "$ETB_6";
      
      public static var §\x03\x04\x02\x06\x06\x04\x02\x05\x07\x05\b\x05§:String = "$ETB_4";
      
      public static var §\x01\x06\x05\x02\x01\x02\x07\x03\b\b\x05§:String = "Mei";
      
      public static var §\x02\x07\x02\x01\x03\x06\x01\b\b\x04\b\x01\x02§:String = "#(.+?)\\s*\\((.*?)\\)";
      
      public static var §\x04\x02\x06\x01\x04\x02\x06\x05\x03\x07\x02\x05§:String = "$TutoAlimentationFeu";
      
      public static var §\x03\x04\x06\x03\x01\x05\b\x02\x02\b\x03\x07§:String = "tuto_alimenter_feu";
      
      public static var §\b\b\b\b\x03\x06\x06\x03\x07\x03\x02§:String = "$ResultatRecetteInconnu";
      
      public static var §\x02\x01\x01\x03\x01\x04\x01\x05\x05\x07\x02\x04§:String = " <G>";
      
      public static var §\x04\x06\b\x03\b\x01\x02\x02\x05\b\x07\x04\x04§:String = " »</i>";
      
      public static var §\x02\x02\b\x07\x01\x04\x04\x03\b\x03\x06§:String = "$type_effet.32.nom";
      
      public static var §\x05\x07\x03\x03\x06\x02\x06\x03\x01\x02\x03\x03\x03§:String = "$TooltipObjetVitesseAttaque";
      
      public static var §\b\x01\x06\b\x07\x05\x05\x02\x03\x02\x01\x07\x04§:Number = (1059 + -934) / (2520 + -2420);
      
      public static var §\x07\x01\x06\x04\x05\x01\x03\x02\x07\x03\x05§:String = "<font size=\'10\'><G>";
      
      public static var §\b\x05\b\x04\x06\x05\b\x05\x04\x01\x07\b\x01§:String = "\n<font color=\'#48AEEC\'>";
      
      public static var §\x01\x05\x01\x04\x01\x02\x02\x02\b\x07\x04§:String = "title";
      
      public static var §\x02\x02\x06\x06\x02\x06\x01\x07\x01\x04\x03§:String = "<D>Blue\n<N>Mouse wheel to change\nPress <V>CTRL</V> to change globaly";
      
      public static var §\x04\x07\x06\x03\x03\x05\x02\x01\b\x07\x02§:String = "Selection";
      
      public static var §\x04\x06\x01\x02\x05\x02\x05\x06\x07\x01\x02\x06\x03§:String = "Niveau des monstres :";
      
      public static var §\x02\x04\x01\x01\x07\x03\b\b\x06\x07\x02\x05\x01§:String = "Nombre maximum de monstres vivants :";
      
      public static var §\x03\x03\x01\x03\x07\b\b\x04\x02\b\x04§:String = "$EditeurDefinirToxiciteModEnv";
      
      public static var §\x05\x02\x05\x03\x01\x05\x06\x06\x01\x05\x01\x03\x01§:String = "$EditeurTitreSuppression";
      
      public static var §\x07\b\x06\b\x05\x03\x01\x07\x05\x07\x02\x06\b§:String = "$EditeurGererLangues";
      
      public static var §\x05\x02\x02\x06\x02\x01\x07\x01\x02\x07\x07\x07\x07§:String = "$EditeurVueNormaleTraductions";
      
      public static var §\b\x07\x03\x03\x05\x04\x03\x07\x02\x01\x01§:String = "Code : ";
      
      public static var §\x07\x04\x05\x01\x02\x03\x02\x06\b\x02\x06§:String = "area: ";
      
      public static var §\x01\x01\x05\x04\x01\x06\b\x07\x06\b\x05§:String = ", longueur: ";
      
      public static var §\b\b\x04\x06\x04\x04\x04\x07\x03\x01\x07\b\x07§:String = "$CadrillageSecret";
      
      public static var §\x07\x03\b\x04\x06\b\x04\x01\x05\x01\x07\x05\x05§:String = "Familier_01.swf";
      
      public static var §\x05\x06\x06\x04\x03\x02\x01\x05\x03\x05\x02§:String = "$Action_Haut";
      
      public static var §\b\x06\x05\x07\x04\x06\x03\x01\x03\b\x01\x01\b§:String = "combat/casse";
      
      public static var §\x01\x04\x05\x07\x02\x02\x05\b\b\x07\x06§:String = "$SlotsInventaireRequis";
      
      public static var §\x02\x02\x01\x06\x06\x06\x04\b\x05\x03\x01\x05§:String = "$reaction_bruit";
      
      public static var §\x06\x06\b\x06\x01\x01\b\b\b\x03\b\x04§:String = "$Nv";
      
      public static var §\x05\x01\x01\b\x04\x07\x01\x05\x04\x03\x07\x06§:String = "Bouclier_1";
      
      public static var §\x04\x06\x02\x02\x07\x03\x04\x02\x06\b\x04\x05§:String = "1;0,0,0,0,0,0,0,0,0,0";
      
      public static var §\x04\x01\x06\x07\x05\x05\x05\x04\b\x06\x06\x06\x03§:String = "x_transformice/x_smiley/";
      
      public static var §\x02\x04\x05\x02\x02\x02\x02\b\x02\x01\x06\x03\x03§:String = "AnimPlumes";
      
      public static var §\x06\x04\x05\x02\x03\b\x05\x05\x02\b\x01§:String = "multi_AnimBisou";
      
      public static var §\x03\x03\x04\x04\x03\x06\b\x02\x02\x03\x05\x01\b§:String = "AnimConfetti";
      
      public static var §\x02\x06\x02\x06\b\x04\x07\x05\x01\x04\x04§:String = "MESSAGE INCONNU : ";
      
      public static var §\x03\b\x07\x06\b\x05\x02\x01\b\x06\x03\b\b§:String = "$ModeMusic_InfoVideo";
      
      public static var §\x04\x03\x06\x07\b\x02\x06\x07\x05\x04\x07\x02§:String = "[Message inconnu] Derniers messages reçus (";
      
      public static var §\x07\x02\b\x03\x04\x01\x02\x01\x05\x07\x05§:String = "$authentification.erreur.2";
      
      public static var §\x01\x05\x05\x03\x06\x03\x01\x05\x07\x02\x02\x03\b§:String = "$Silence_";
      
      public static var §\x02\b\x06\x01\x02\b\x06\x04\x02\x02\x05§:String = " vient de se déconnecter.";
      
      public static var §\x03\x06\x03\x04\x04\x07\x04\b\x06\x05\x06\x02\b§:String = "son/bulle";
      
      public static var §\x05\x06\x06\b\x04\x01\x02\x04\x03\x06\x05\x04\x05§:String = "$Carte_Perma";
      
      public static var §\x04\x04\x02\x01\x07\x04\x03\x04\x03\x03\b\x02\x05§:String = "<G>-";
      
      public static var §\x03\x03\x07\x03\x02\x03\x02\x06\b\x07\x02\x01\x07§:String = "ag";
      
      public static var §\x02\x06\b\x05\x01\x05\b\x07\x06\b\b\x05§:String = "ECHEC";
      
      public static var §\x07\x04\b\x03\b\x05\x02\x02\x02\x01\x07§:String = "# Arbitre";
      
      public static var §\x04\x07\x04\x01\x04\x06\x02\x05\x03\x05\x01§:String = "# Modo";
      
      public static var §\x06\x02\x06\b\x06\x04\x07\x03\x05\x07\x02\x04§:String = "x_tribulle/x_loc_";
      
      public static var §\x05\x05\x05\x06\x04\x04\x02\x03\x03\x03\x02\x04\x06§:String = ",\n\tconnecte=";
      
      public static var §\x07\x05\x01\x05\x07\x05\x03\x05\x01\x01\x01§:String = ",\n\tpeutChangerCodeMaison=";
      
      public static var §\x06\x02\x06\x05\x06\x05\x02\x06\x06\b\x05\x05\x07§:String = "leading";
      
      public static var §\x06\x03\x05\x04\x02\b\x06\x04\x05\x06\b§:String = "onPlayerError";
      
      public static var §\x03\x01\x04\x03\b\x03\x04\x07\x02\x06\x03\x03\x02§:String = "Latviešu";
      
      public static var §\x02\x02\x04\x07\x03\x06\x07\x06\x05\x06\x06§:String = "hr";
      
      public static var §\x04\x04\x05\x05\x03\x03\x02\x04\x04\x01\x06\b\x03§:String = "Bahasa Indonesia";
      
      public static var §\x03\x03\x04\x03\b\x01\x03\x05\x04\x05\x01§:String = "es";
      
      public static var §\x05\x06\x04\x07\x07\x04\b\x06\x02\x06\x07\x02§:String = "English only";
      
      public static var §\x01\x03\x03\x05\b\x02\b\x06\x06\x06\x05\x03\x04§:String = "keys";
      
      public static var §\x07\x05\x06\x05\b\b\x01\x05\x02\x04\x02§:String = "size=\'";
      
      public static var §\x01\x06\x05\x06\x05\x01\x04\x02\x01\x06\x04\x01§:String = "small";
      
      public static var §\x03\x06\b\x07\x01\x02\x04\b\x07\x06\x05§:String = "$GererJoueursSalon";
      
      public static var §\x06\x03\x07\x03\x04\x02\b\x04\x02\x06\x06\x04\x03§:String = "$ToujoursChamane";
      
      public static var §\x06\x04\x05\x04\x02\x07\x01\x05\x05\x03\x07\x03\x03§:String = "M    O    D    O    P    W    E    T";
      
      public static var §\x05\x04\x06\x02\x02\x06\b\x06\x01\b\x02§:String = "$interface.tribu.bouton.ajouterRang";
      
      public static var §\x03\x01\x06\x04\x04\x04\x02\x05\x03\x05\x01\x07§:String = "ajouter-membre.png";
      
      public static var §\x05\x04\x07\x01\b\x04\x03\x06\x04\x07\x07§:String = "$interface.tribu.bouton.changerRang";
      
      public static var §\x07\x06\x05\x07\x04\x07\x07\x05\x02\b\x05§:String = "x_tribulle2/fond-ame-soeur-tribulle.jpg";
      
      public static var §\b\x06\x02\x05\x02\x02\x02\x05\x04\x04\x01§:String = "x_tribulle2/mariage.png";
      
      public static var §\x05\b\x07\x07\x06\x01\x03\x02\b\x04\x02\x04\x04§:String = "$menu.contextuel.joueur.ignorer";
      
      public static var §\x05\x05\x02\b\x05\x03\x02\b\x03\x07\x07\x04§:String = "\'><N>";
      
      public static var §\x07\x03\x05\x02\b\x06\x01\b\x06\x04\x01\x01\x05§:int = 714 + -478;
      
      public static var §\x02\x04\x07\b\x03\x07\x02\x03\x07\x02\x02§:int = 6470 + -5824;
      
      public static var §\x02\x05\b\x02\b\x02\x07\x07\x07\x04\b\x03\x01§:String = "] <T>";
      
      public static var §\x04\x03\b\x07\x01\x03\x07\x01\x01\b\x04\x01\x04§:String = "<V>• ";
      
      public static var §\x06\x07\x03\x03\b\b\x05\x03\x06\x07\x01\x07\x05§:String = "$ChuchoImpossibleIgnore";
      
      public static var §\x02\b\x03\x05\x04\x04\x04\x07\x07\x04\x05\x06§:Number = (8750 + -8732) / (4692 + -4682);
      
      public static var §\x02\x07\x05\x07\x06\x04\x01\x02\x04\x07\x01§:String = "$Chat_Plus";
      
      public static var §\b\x04\x01\b\x05\x06\x01\x07\x02\x03\x02\x05§:String = "$Chat_Tribu";
      
      public static var §\x02\x05\x03\x03\x05\x06\x02\x04\x06\x07\x02\x03§:String = "friend";
      
      public static var §\x06\b\b\x01\x01\x02\x03\x02\x07\x02\x05\x01\x02§:String = "ignore";
      
      public static var §\x06\x05\x01\x04\x04\x02\x01\x02\x05\x07\x02§:String = "cmd";
      
      public static var §\x05\x02\x05\x01\x05\b\x07\x02\x04\x04\x04\x04§:String = "vanilla";
      
      public static var §\x01\x02\b\x01\x03\x05\x02\x01\x04\x04\x07\x03§:String = "$ChoixPseudoMemeEmail";
      
      public static var §\b\x02\x04\x06\x01\x05\x05\x01\x03\x05\x03\x05\x03§:String = "$NouveauPseudoKongregate";
      
      public static var §\b\x06\b\x05\x02\x01\x06\x05\x01\x07\b\x03§:String = "x_transformice/x_interface/facebook/auth_facebook.png";
      
      public static var §\x06\x06\b\x01\x03\x06\x05\x07\x04\x07\x02\x04\x02§:String = "$PseudoExterneDejaPris";
      
      public static var §\b\x02\x06\x06\x03\x03\x06\x05\b\x03\x05\x02\x01§:String = "x_commun/x_iconesjeux/x_nk.jpg";
      
      public static var §\x04\x02\x05\x04\x05\x02\x05\x06\x06\x05\b\x04§:String = "Fortoresse";
      
      public static var §\x06\b\b\b\x01\x01\x01\x01\x02\x06\b§:String = "$nbTitres";
      
      public static var §\x04\x02\x06\x05\x03\x05\x05\x03\b\x03\x05\x04\x04§:int = 5176 + -4900;
      
      public static var §\x04\x05\x05\x07\x04\x04\x06\x05\b\b\x05\b§:String = "Courier New";
      
      public static var §\x01\x06\x06\x01\x02\x06\b\x06\x06\x07\x04§:String = "</V>\n";
      
      public static var §\x03\x04\b\x05\x07\x05\x01\x03\x02\x05\x04§:String = "x_transformice/x_minijeux/x_bootcamp.jpg";
      
      public static var §\x01\x03\b\x07\x05\x03\x07\x01\x07\x06\x02\x03§:String = "_Report";
      
      public static var §\x07\x02\x01\x04\x07\x07\x03\x05\x04\x05\x06\x06§:String = "on";
      
      public static var §\x03\x03\x03\x06\x04\x05\x05\x03\x03\b\x07\x07\x05§:String = "$NouveauSujet";
      
      public static var §\x05\b\b\x02\x04\x02\x01\x01\x05\x01\x07\x02§:String = "$Refresh";
      
      public static var §\x03\x01\x02\x04\x03\x04\x01\x01\x06\x01\x03§:String = "\n<V><font size=\'11\'>";
      
      public static var §\b\x03\x02\b\x04\b\x06\x07\x03\x04\x07\x04\x03§:String = "\\*\\*(.*?)\\*\\*";
      
      public static var §\x05\x07\b\x02\x01\x07\x03\x04\x06\x05\x02\x07\x05§:String = "\\";
      
      public static var §\b\x02\x07\x04\x01\x01\x01\x01\x02\x07\x03\x07§:String = "Numpad 0";
      
      public static var §\b\x03\x03\b\x05\x02\b\x03\x07\x06\x06\x04§:String = "2";
      
      public static var §\x04\x07\x07\x01\x02\b\x01\x04\x04\x04\x05\x02\x03§:String = "B";
      
      public static var §\x05\b\b\x06\x01\x05\x06\x01\x07\x07\x01\b§:String = "Taille : ";
      
      public static var §\x04\x02\x04\b\x04\x05\x05\x01\x06\x01\x03§:String = "\n<T>";
      
      public static var §\x03\x02\x04\x07\x03\x04\x05\x05\x01\b\x02§:String = "gapiEstInitialise";
      
      public static var §\x07\x07\x03\b\x06\x02\x03\x04\x07\x01\x07\x06\x03§:int = 7972 + -7765;
      
      public static var §\b\x05\x03\x02\b\x07\x05\x05\x03\x06\x07§:int = 5891 + -5755;
      
      public static var §\x03\x01\x03\b\x07\x06\b\x04\x06\x02\x05§:int = 3050 + -2949;
      
      public static var §\x02\x04\x02\x01\x06\b\x03\x07\x06\b\x02\x03§:Number = (6780 + -5765) / (9519 + -8519);
      
      public static var §\x06\x07\x07\b\b\x07\x01\x06\x07\x01\x06\x06§:int = 2531 + -2436;
      
      public static var §\x04\b\x03\x02\x02\x03\x02\x02\x06\x02\x01§:int = 2101 + -2065;
      
      public static var §\x02\x07\x03\b\x01\x06\x01\x01\x07\x02\x05\x03\x07§:String = "+ ";
      
      public static var §\b\x06\x06\x07\b\x02\b\x06\x04\x07\x04\x03§:int = 2628 + -2400;
      
      public static var §\b\x01\x01\b\x01\x03\x01\x06\x06\x03\b\x02\x02§:int = 6786 + -6604;
      
      public static var §\b\b\x07\b\b\x03\x07\x07\b\b\x02\x01§:int = 942 + -745;
      
      public static var §\x04\x01\x06\x04\b\x02\x07\x06\x04\x04\x03§:int = 2908 + -2789;
      
      public static var §\x07\x07\x02\x05\x01\x05\x04\b\x03\x03\x01\x06§:int = 4146 + -4055;
      
      public static var §\b\x01\x07\x01\x02\x04\x03\x05\x07\x01\x06\x01§:String = "outputSpeedBonus";
      
      public static var §\x04\x01\x02\b\x02\x01\x01\x06\x07\x03\x03\x04\x02§:String = "$Fromage";
      
      public static var §\b\x02\x01\x02\b\x01\x07\x04\x07\x05\x05\x07\b§:int = 6197 + 14603;
      
      public static var §\x05\x07\x03\b\x05\x01\x04\x04\x04\x05\x04\x04\x03§:String = "fr";
      
      public static var §\x03\x06\x05\x07\x07\x01\x07\x06\b\x06\x05\x02§:String = "</R>";
      
      public static var §\x04\x06\x03\x02\b\b\x03\x04\x03\x01\x07\x03§:String = "$Selecteur";
      
      public static var §\x05\x02\x06\b\x04\b\x04\x03\x07\x05\x02§:int = 9737 + -9587;
      
      public static var §\x07\x04\x06\x04\x03\x01\x04\x07\x01\x06\x01\x07\x05§:String = "$AttenteFinFraise";
      
      public static var §\b\b\x07\x03\x05\x01\x05\x04\b\x02\x06\x06§:String = "$AttenteFraise";
      
      public static var §\x01\x02\x04\x04\x04\x07\x06\x07\x02\x05\x02\b\x06§:String = "$ContactAllopass";
      
      public static var §\x07\x04\x04\x07\x04\x01\x06\x05\x02\x05\x06\x01§:String = "_blank";
      
      public static var §\x07\x01\x07\x02\x02\b\x06\x07\x05\b\x01\x06§:String = "$Allopass";
      
      public static var §\x05\x04\x06\x01\b\x05\x07\x02\x05\x04\x06\b§:int = 7133 + -7128;
      
      public static var §\x07\x06\x03\x06\x05\x07\x01\b\x07\x07\x07§:String = "oui";
      
      public static var §\x04\x03\x02\x05\x01\x05\b\x02\x06\x06\x06\x06§:String = "e";
      
      public static var §\b\x07\x04\x01\x03\x06\x03\x06\x03\x06\x06\x04\x01§:int = 6077 + -5945;
      
      public static var §\b\x03\x03\x02\x05\b\x07\x05\x02\x07\x05\b\x06§:String = "CS";
      
      public static var §\x02\x05\x07\x01\x04\x07\x05\x01\x02\b\x04\b§:String = "ROSE";
      
      public static var §\x04\x07\x03\x03\x02\x01\x01\x01\x03\b\x06\x07\x06§:Number = (6798 + -6641) / (8805 + -8705);
      
      public static var §\x04\x01\x04\x03\x03\x06\x06\x05\x02\x01\x02\x05\x04§:String = "_nfs_";
      
      public static var §\x04\x04\x01\x01\x01\x04\b\x03\x05\x02\x06\x06\x03§:String = "teUTF";
      
      public static var §\x05\x06\x06\x04\x01\b\x07\b\x07\x03\b§:int = 9874 + -9839;
      
      public static var §\x01\x06\x01\x03\x01\x06\x05\x03\x06\x06\x02\x02§:String = "w*";
      
      public static var §\b\x04\b\b\x04\b\x01\x03\x06\x02\x06\x04\x05§:String = "pacifique";
      
      public static var §\x05\x02\x03\x07\x06\b\x07\x06\b\x02\x01\x04\x06§:String = "message";
      
      public static var §\x03\x03\x05\x02\x01\x03\x07\b\x02\x05\x03§:String = "PositionSouris : ";
      
      public static var §\x06\x01\b\x07\x04\x06\x04\x05\x01\x01\x06\x06§:int = 1525 + -1502;
      
      public static var §\x07\x04\x05\x01\x07\x06\x02\x02\b\x01\x07\x06\x07§:String = "jade";
      
      public static var §\x05\x05\x01\x01\x06\x06\x02\x01\x06\x03\x04§:int = 9632 + -9621;
      
      public static var §\x04\x03\x02\x01\x07\x02\x07\x06\x03\x06\x04\x03\x01§:int = 6692 + -5792;
      
      public static var §\x04\x02\x01\x07\x07\x06\b\x03\x05\x05\x03§:String = "<J>Mode dessin : ";
      
      public static var §\x07\x04\x04\x01\x04\x07\b\x05\x04\x06\x05§:String = "<font color=\'#FF00FF\'>Version debug</font>";
      
      public static var §\x06\x02\b\x05\b\x03\x06\b\x03\x01\x07§:int = 7620 + -7618;
      
      public static var §\x06\b\x03\b\x05\x07\b\x05\x01\x07\x05\x04§:Number = (6783 + -6778) / (5779 + -5769);
      
      public function §\x03\b\x07\b\b\x05\x05\x02\b\x06\x07§()
      {
         super();
      }
      
      public static function §\x02\x04\x02\x05\x05\x01\b\x07\x07\x01\x03§() : int
      {
         return 6331 + -5630;
      }
      
      public static function §\x03\x03\x01\x02\x03\x02\x07\x07\x07\x07\x06§() : int
      {
         return 5531 + -4951;
      }
      
      public static function §\b\x06\b\x07\x05\x01\x06\x02\x03\x02\x01\x04§() : int
      {
         return 1381 + 4000;
      }
      
      public static function §\x05\x04\x05\x07\x01\x05\x07\x02\x01\x05\x07\x06\x04§() : int
      {
         return 5080 + 2929;
      }
      
      public static function §\x06\x02\x06\x02\x03\b\x02\x02\x04\x04\x01\x07\x07§() : int
      {
         return 4748 + -4537;
      }
      
      public static function §\x04\x01\x05\x03\x04\b\x04\x07\x07\x01\x01§() : int
      {
         return 9838 + -9795;
      }
      
      public static function §\x02\x04\x01\x03\x01\x01\x07\x07\b\x02\b\x01§() : int
      {
         return 2913 + -2818;
      }
      
      public static function §\x03\x07\x06\x01\b\x07\x04\x03\b\x07\x02\b\x03§() : int
      {
         return 9113 + -9050;
      }
      
      public static function §\x04\x02\x05\x05\x04\x04\x03\x05\x07\x06\x01\x04\x02§() : int
      {
         return 1752 + -1604;
      }
      
      public static function §\x06\x02\x02\x07\x05\x02\x05\x04\b\b\x06§() : int
      {
         return 7727 + -7577;
      }
      
      public static function §\x04\x02\x05\x07\x04\x02\x07\x04\x04\x01\x03\x01§() : int
      {
         return 2064 + -1949;
      }
      
      public static function §\x05\x04\x02\b\x07\x02\b\x05\x03\x04\x04§() : int
      {
         return 3715 + -3555;
      }
      
      public static function §\x06\x06\x04\x06\b\x07\x03\b\x03\x05\x04§() : int
      {
         return 9602 + -9460;
      }
      
      public static function §\b\x06\x07\x01\x06\x03\b\x06\x02\x02\x05§() : int
      {
         return 5212 + -5208;
      }
   }
}

