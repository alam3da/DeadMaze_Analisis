package
{
   public class §\x04\x01\b\b\x06\x05\x06\x01\x01\b\x04§
   {
      
      public static var §\x01\x02\x05\x02\x07\b\x03\x07\b\x02\x05\x04\x07§:String = "ajout objet : 8";
      
      public static var §\x04\x07\x06\x04\b\x01\x03\x06\x02\x02\x07\x02\b§:Number = (8535 + -1869) / (8501 + 1499);
      
      public static var §\x02\x06\x04\x01\x03\x06\x07\x06\b\x03\x03\x05\x02§:Number = (5023 + -4890) / (9414 + -9314);
      
      public static var §\x06\x05\x03\b\x03\x01\x05\x02\x03\x01\x05\b\x04§:String = "son/ecriture";
      
      public static var §\x03\x01\x03\x03\b\x03\x07\x01\x04\x01\x05§:int = 2938 + -677;
      
      public static var §\x07\x01\x02\x03\x03\x03\x03\b\x07\b\b\x05\x03§:int = 6318 + -4065;
      
      public static var §\x06\x04\b\x05\x03\x02\x07\x05\x06\x04\x01§:String = "$KS";
      
      public static var §\x02\x02\x06\x05\x01\b\x02\x03\x05\x01\x03§:String = "x_transformice/x_interface/1.jpg";
      
      public static var §\x01\b\x02\x04\x03\x01\x01\x02\b\x01\x07\x03§:String = "#604331";
      
      public static var §\x03\x01\x06\x02\x07\x02\x01\b\x04\x06\x07\x07\x01§:String = "$Mon_Compte";
      
      public static var §\x05\b\x04\x07\x06\x05\x01\b\x01\x05\x07§:String = "6986B22A-B14E-499D-87E0-B19B48EF13AE";
      
      public static var §\x07\x01\x02\x03\x04\b\x01\x06\x06\x06\x03\x06\x01§:String = "<font color=\'#FFEE8C\'>";
      
      public static var §\x04\x05\x02\x06\x02\x01\x04\x02\x05\x07\x03\x01§:Number = (2195 + -1810) / (5709 + -5609);
      
      public static var §\x03\x01\b\x05\x02\x04\b\x07\b\x02\b\x02\x07§:String = "magique.png";
      
      public static var §\x01\x04\x05\x06\x01\b\x06\b\x02\x01\x05§:int = 9730 + -8903;
      
      public static var §\x03\x07\x05\x04\x07\x07\x02\x07\x01\b\x03\x04\x01§:String = "NEWS";
      
      public static var §\x01\x06\x07\b\x05\x05\b\x03\x06\x07\x01\x01§:String = "x_divers/x_steam.png";
      
      public static var §\x03\x05\x03\x06\x06\x03\x03\x03\x01\x03\x01\x03§:String = "x_transformice/x_divers/x_cadeau1.jpg";
      
      public static var §\x02\x01\x03\x06\x04\x07\x06\x02\x02\x01\x01\x05§:String = "</J> / <font color=\'#E884E6\'>";
      
      public static var §\x01\x04\b\b\x07\x06\x04\x05\x07\x06\x05§:String = "$texte.genre";
      
      public static var §\x05\x07\x03\x07\x07\x07\x03\x03\x07\b\x01\x03\x05§:String = "_wip";
      
      public static var §\x01\x05\x05\x02\x03\x06\b\x07\x05\x02\x03\x04§:String = "<font color=\'#79ABBB\'>*****</font>";
      
      public static var §\b\b\x03\x06\b\x03\x02\x05\x03\b\b§:String = "$C_MaitresseDuVent";
      
      public static var §\x07\x06\x05\x01\x07\x04\x01\x01\x01\x04\x04\x07§:String = "x_i_90.png";
      
      public static var §\x04\b\x03\x03\b\x06\b\b\x07\b\x07\b§:String = "x_i_63.png";
      
      public static var §\x07\x01\x05\x02\x01\x07\x02\x01\x05\x04\x05§:String = "x_i_11.png";
      
      public static var §\x04\b\b\x03\b\x06\x06\x02\x06\b\b\x01§:String = "x_i_7.png";
      
      public static var §\x07\x05\x01\x05\x02\x01\x03\x03\x03\x07\b§:Number = (9158 + -9080) / (7520 + 2480);
      
      public static var §\x01\x03\x03\x07\x05\x04\x06\x06\x01\x05\x03\x01§:String = "_Halloween";
      
      public static var §\x01\x06\x02\b\x03\b\b\x03\x02\x07\x03\x02§:String = "x_flecheDroite.png";
      
      public static var §\x02\x07\b\b\x03\x03\x01\x02\x07\x02\x05§:String = "PlancheG";
      
      public static var §\x01\x06\x04\x06\x03\x07\x03\x01\x04\x03\x05\x01§:String = "SAB";
      
      public static var §\x04\b\x07\x06\x01\x01\x06\b\x06\x01\x05§:String = "$Monde_0";
      
      public static var §\x03\x05\x05\x03\x03\b\b\x02\x07\x01\x05\x05§:String = "LIM1";
      
      public static var §\x02\x07\x07\x04\x05\x07\x05\x05\x05\x07\x06\x02§:String = "grav";
      
      public static var §\x05\b\x01\b\b\x07\x03\b\x05\x04\x03\x06\x03§:String = "] <BL>";
      
      public static var §\x05\x05\x06\b\x03\b\x03\x03\x04\x05\x01\x05§:Number = (8795 + -8789) / (1800 + -1700);
      
      public static var §\x02\x02\b\b\x04\x03\x06\x02\b\x03\x07\x05§:String = "lshdjfg";
      
      public static var §\x04\x06\x03\x01\x04\x04\x04\b\b\x04\x03\x01\x01§:int = 5866 + -3756;
      
      public static var §\x04\x01\x02\x04\x03\x04\x07\x06\x07\b\x02\x05§:String = "$CartoucheArbre0";
      
      public static var §\x04\x03\x01\x07\b\x01\x05\x06\x06\x01\x04\x03\x04§:String = "$Queue";
      
      public static var §\x01\x03\x06\x04\b\x04\x03\x07\x01\x07\x02§:String = "$Favoris";
      
      public static var §\x04\x04\x01\x06\x01\x02\x01\x01\x01\x04\x03§:String = "magasin";
      
      public static var §\x04\x06\x03\x02\x01\x04\x02\x05\x05\b\x07\x06\x05§:String = "avatar_base";
      
      public static var §\x03\x06\b\x05\x05\x06\x01\x03\x07\x03\x02\x02\x02§:String = "btn_chucho_normal";
      
      public static var §\x01\x03\x06\x07\x04\x06\x06\x01\x07\x04\x02\x07\x02§:String = "btn_point_normal";
      
      public static var §\x06\x06\x04\x07\x06\x01\x07\x06\x06\x05\b\x05§:String = "btn_fermer_over";
      
      public static var §\x06\x05\x01\x06\x02\x02\x05\x04\x04\x01\x07§:String = " :";
      
      public static var §\x04\x01\x07\b\x06\x05\x06\x07\b\x07\x03\x06§:String = "$GainPatate";
      
      public static var §\b\x07\x01\x03\x07\b\x07\x05\x06\x04\x05\x01\x07§:String = "lu";
      
      public static var §\b\x01\x02\x01\x04\x06\x02\x02\x04\x05\x01§:String = "mssc";
      
      public static var §\x04\x03\x06\x06\x07\x06\x03\x01\b\x07\x06\x06\x07§:String = "%] ";
      
      public static var §\x06\x06\x02\x02\x02\b\b\x07\x05\x02\x07\b§:String = "sort_2";
      
      public static var §\x01\b\x06\x04\x04\x02\x07\x03\x03\x04\x02§:String = "$AnimCourse_";
      
      public static var §\x01\x04\x07\x03\x01\x03\x04\x06\x01\x06\x07\x06\x01§:String = "comp_2";
      
      public static var §\x01\x03\b\x03\x02\x03\x04\x05\x01\x06\x07\x01\x01§:String = "parade";
      
      public static var §\x07\x01\x03\x07\x05\x02\x01\b\x04\x06\x07\x01§:String = "statique_combat";
      
      public static var §\b\x05\x02\x05\x07\x04\b\x05\b\x05\x07§:String = "monstres/mort/m";
      
      public static var §\b\x05\x05\x06\b\x04\x02\x05\x03\x03\x06§:String = "x_deadmeat/x_interfaces/divers/etat";
      
      public static var §\x02\x02\x04\x05\x03\b\x05\x05\x07\x07\x03\x03§:String = "sons/19";
      
      public static var §\x02\b\x04\x07\x04\x03\x02\x01\b\x02\x06§:String = "<J>Initialisation chargement monde (";
      
      public static var §\x03\x01\x04\x03\x06\x02\x07\b\x01\x04\x01§:String = "$AmeliorationRequise";
      
      public static var §\b\x03\x07\x07\b\x06\x07\x05\x04\x07\x06§:String = "objectif2";
      
      public static var §\x06\x03\x05\x02\x01\x07\x02\x04\x04\x03\x06§:String = "x_deadmeat/x_interfaces/divers/boussole.png";
      
      public static var §\x06\x01\b\b\x04\x03\x03\b\x01\x05\x06§:String = "x_deadmeat/x_interfaces/divers/clef-login.png";
      
      public static var §\x06\x06\x05\x03\x01\x01\x02\x02\x06\x03\x06\x05\x06§:String = "$AuthentificationRequise";
      
      public static var §\x02\x07\x02\x02\b\x01\x01\x07\x04\x02\x03\x04§:String = "$RM_";
      
      public static var §\b\x07\x07\x04\x06\x04\x03\x06\x04\x03\x05\x03§:String = "$Recyclage";
      
      public static var §\x01\x04\x01\x01\x02\x06\x06\x01\x04\x02\x01\x04§:String = "$Nourriture";
      
      public static var §\x02\x01\x04\x03\x05\x06\x04\b\x01\x01\b§:String = "$Materiaux";
      
      public static var §\b\x02\x02\x04\x04\x03\x01\x05\x04\x03\x03\x03§:String = "$Reserve";
      
      public static var §\x02\x02\x01\x07\x02\x05\x03\x06\x04\x05\b\x04§:String = "$EditeurValiderSuppressionMap";
      
      public static var §\b\x02\x01\b\x06\x05\x02\x03\x07\x07\b§:String = "$ExpeditionQuitter";
      
      public static var §\x06\x05\x02\x04\x07\x05\x07\x06\x04\x06\x03\x07\x01§:String = "Yes";
      
      public static var §\b\x05\x01\x07\x07\x07\b\x06\x01\x05\x07§:String = "<O>set";
      
      public static var §\x02\x05\x01\b\x03\x05\x01\x06\x04\b\x03\b\x07§:String = "famfamfam/world_go.png";
      
      public static var §\x04\x02\b\x06\x06\x07\x05\b\x01\b\x04\x04\x06§:String = "New step";
      
      public static var §\x02\x07\b\x07\x01\x04\x05\x03\x06\x04\x05§:String = "\t\t\t";
      
      public static var §\b\x07\x05\x04\x06\x03\x07\x05\x03\x06\x04§:String = "$Defaite";
      
      public static var §\x05\x04\x01\x06\x05\x03\x07\x03\x03\b\x04\x04\x07§:String = "x_deadmeat/x_interfaces/expedition/victoire.png";
      
      public static var §\x07\x02\x06\x05\b\x03\x04\x06\b\x02\x02\x03§:String = "$TempsRestantJour";
      
      public static var §\x02\x02\x03\x04\b\x07\x06\x01\x06\x05\x03\x04§:String = "$QuitterJeu";
      
      public static var §\x04\x07\x01\x06\x06\b\x04\x07\x04\x03\x02\b\x06§:String = "$Moyen";
      
      public static var §\x06\x03\x04\x03\x02\x05\x02\x01\x02\x06\x06\x06\x01§:String = "low";
      
      public static var §\x05\x03\x05\x06\x04\x03\x03\x02\x07\x07\x05\x02\x04§:String = "$ETB_8";
      
      public static var §\b\x05\x02\x05\x04\x03\b\x03\x03\x05\x06\x05\x05§:String = "cinematique/tremblement";
      
      public static var §\b\x05\x06\x04\b\x06\x06\b\x06\b\b\x03§:String = "$AucunObjet";
      
      public static var §\x03\x05\x02\x07\b\x07\x04\x04\x02\x07\x01\x04\x02§:int = 3727 + -2767;
      
      public static var §\x04\b\x05\b\x03\x04\x04\x04\x02\x07\x06\x02§:String = "x_deadmeat/x_campement/Nuages.png";
      
      public static var §\x03\x04\x03\x06\x02\x02\x02\x07\x06\x03\x05§:String = "x_deadmeat/x_interfaces/forge/switch_items.png";
      
      public static var §\x04\x07\x02\x07\x06\x04\x05\x06\x06\x01\x06\x06§:String = "x_deadmeat/x_objets/x__cadre.png";
      
      public static var §\x02\b\x03\x05\x05\x02\x03\x06\x05\x06\x06\x02§:String = "\n - ";
      
      public static var §\x02\x04\b\x02\x03\x03\x03\x02\x07\x03\x03\x06\x02§:String = "$NiveauMenace";
      
      public static var §\b\b\x05\x06\b\x07\b\x05\x05\x07\x05\x06\x06§:String = " <G>(";
      
      public static var §\x06\x01\x05\x01\x03\x05\x06\x07\x03\x06\x07\x05§:String = "$Kit_";
      
      public static var §\x02\b\x04\x03\x02\x04\x07\x05\x04\x01\x04\x04§:int = 2972 + -2804;
      
      public static var §\x04\x02\x01\x01\x07\x06\x01\x06\x03\x07\x02\x02\x02§:String = "celousco/interfaces/or.png";
      
      public static var §\x07\x01\x06\x02\x04\x01\x04\b\b\x07\x07§:String = "$EquipeLoutre";
      
      public static var §\x05\b\x06\x01\x07\b\x04\x06\x02\x01\x05\b\x07§:Number = (4319 + 568639) / (1393 + 8607);
      
      public static var §\x03\x07\x01\x05\x04\x05\x07\x06\x07\x03\x07§:String = "$EditeurIdentifiantGroupeSpawn2";
      
      public static var §\x02\x02\x05\x06\x07\b\x07\x07\x05\x04\b\x04\x06§:String = "x_deadmeat/x_interfaces/divers/b";
      
      public static var §\x07\x01\x01\x04\x02\x06\x04\x03\x05\x06\x02§:String = "Add monster spawn\n<N>(<V>CTRL</V> to remove)";
      
      public static var §\x01\x07\x04\x07\x01\x07\x04\x06\x05\b\x06\x05\x01§:String = "Vertical flip";
      
      public static var §\x03\x01\x03\x04\x01\b\x06\b\x06\x07\x06\x01\x07§:String = "palette";
      
      public static var §\x01\x06\x05\x07\x05\x06\x01\x05\b\x05\b\x03\x04§:String = "$EditeurVoirExempleTradsGoogleSheets";
      
      public static var §\x03\x07\x07\b\x05\x02\x07\x06\x06\x07\x04\x06\x04§:String = "$EditeurDefinirPuissanceThermiqueModEnv";
      
      public static var §\x02\x01\x01\x06\x04\x07\x02\b\x05\b\x01\x02\x01§:String = "Y cell";
      
      public static var §\x01\x02\x03\x01\b\x05\x05\x03\x06\x03\x04\x07\x02§:String = "$EditeurTitreParametrageBalise";
      
      public static var §\x06\x02\x05\x05\x07\x07\x07\x07\b\x07\x07\x06§:String = "$EditeurCleTraductionExisteDeja";
      
      public static var §\x05\x02\x07\x04\x01\x05\x01\x04\x02\x06\x04\x07§:String = "IT";
      
      public static var §\x06\b\x07\x01\x04\x02\x03\x05\x06\x05\b\x06\x05§:String = "$langue.allemand";
      
      public static var §\x03\x07\x03\x02\x07\x03\x04\x02\x04\x05\x02§:String = "DE";
      
      public static var §\x07\x03\x04\x02\x06\b\x06\x04\x02\x04\b\x07§:String = "RO";
      
      public static var §\x02\x03\x07\x04\x02\x05\x02\x01\b\b\x01\x04§:String = "http://www.transformice.com/images/x_deadmeat/x_monstres/x_monstre_";
      
      public static var §\b\x02\x05\x01\x06\x03\x05\x01\x05\x04\x07\x04\x03§:String = "http://www.transformice.com/images/x_deadmeat/x_pictos/";
      
      public static var §\b\x06\x02\x01\b\x05\x02\x02\x06\x06\x06\x05§:String = "$CadrillageMeteo";
      
      public static var §\b\x05\x03\x02\x02\x01\x01\x03\b\x07\x07\x07§:String = "ambiance";
      
      public static var §\x07\x07\x01\x06\x02\x01\x05\x02\b\x03\x05\x02\x04§:String = "Coiffures_02.swf";
      
      public static var §\x01\x01\x07\x03\b\x06\x05\x07\x06\x02\x02\x02\x05§:String = "spawn_monstre ";
      
      public static var §\b\b\x04\x05\x01\x06\x07\x01\x05\x03\x03\x05§:String = "Impossible d\'avoir plusieurs paquets avec le même identifiant.";
      
      public static var §\x06\b\x07\x06\x01\x04\x03\x06\x07\b\x01\x03§:String = ".conseil";
      
      public static var §\x05\x03\x02\x06\x01\x02\x01\x04\x04\x04\x07§:String = "xp +";
      
      public static var §\x01\x04\x05\x03\x01\x01\b\x03\x06\x01\b\x05§:String = "«";
      
      public static var §\x07\x04\b\x07\x01\x06\x02\x06\x07\x02\x02\b§:String = "http://www.transformice.com/images/x_bibliotheques/fourrures/f";
      
      public static var §\x07\b\x07\x02\x05\x03\b\x01\x02\x06\x07§:String = "Oeil2_1";
      
      public static var §\x07\x03\x02\x07\x03\x02\x05\x03\x07\x05\x01\x02\x05§:String = "Boule_1";
      
      public static var §\x01\b\x02\x02\x05\x04\x05\x02\x01\x01\x07\x06\x07§:Number = (7945 + -7779) / (1714 + -1614);
      
      public static var §\x03\x03\x02\x06\x07\x06\x07\x07\x01\x02\x02§:String = "son/smiley";
      
      public static var §\b\x04\b\x04\x02\x01\x03\x07\x02\x06\x01§:String = "_SourisVisio";
      
      public static var §\b\x01\x05\x03\x01\x02\x02\x03\x07\x06\x06\x02§:String = "1;0,0,0,0,0";
      
      public static var §\x04\x07\x02\x07\x02\x05\x03\x06\x03\x07\x03\x05\x06§:String = "AnimClap";
      
      public static var §\x07\x01\x01\x04\x07\x04\x02\x01\x03\x01\x06\x02§:String = "$Rouge";
      
      public static var §\x02\x03\b\x05\x04\x06\x03\x04\x03\b\x01§:String = "$ExtinctionServeurSEC";
      
      public static var §\x02\x06\x04\x07\x02\x03\x02\x02\x07\b\x06\x04§:String = "$Dites";
      
      public static var §\b\x03\x06\x02\x01\x02\x06\x06\b\x04\b\x04\x04§:String = "$Pas_Assez_Fromage";
      
      public static var §\x07\x02\x06\x02\x01\x02\x06\x02\x05\x02\x02\x01§:String = "$Deja_Dans_Une_Tribu";
      
      public static var §\x01\x04\b\x07\x04\x05\x02\x05\b\x01\x07§:String = "le";
      
      public static var §\x04\x07\x04\x03\x05\x07\x03\b\x03\b\x06\x06§:int = 3456 + 268;
      
      public static var §\x03\b\x03\x01\x06\x01\x07\x01\x03\x01\x01\x04§:String = "Tentative de connexion au serveur (";
      
      public static var §\x01\b\b\x07\x05\x07\x06\x04\x04\x01\x04\x07§:String = "a*";
      
      public static var §\x01\x07\x04\x04\x07\x04\x04\b\x06\b\b\b§:String = "] : ";
      
      public static var §\x06\x05\x02\x04\x05\b\x06\x01\x02\x06\x06\x06§:String = "$chat.message.compteTropRecentPourChat";
      
      public static var §\x05\x01\x07\x07\x07\x01\x06\x05\x05\b\x06§:String = "$chat.tribu.signaleNouveauMembre";
      
      public static var §\x07\x06\x04\x04\x06\b\x03\x01\x06\x07\x06\x04§:String = "://www.transformice.com/langues/tfm-";
      
      public static var §\x06\x05\x06\x04\x05\x05\x05\x04\x07\x07\x03§:String = "window";
      
      public static var §\x01\x06\x02\x01\x02\x05\x07\x02\x04\x07\x07\x01§:String = "getPlayerState";
      
      public static var §\x02\x02\x03\x02\b\x04\x04\x05\x07\x02\x04\x07§:String = "Deutsch";
      
      public static var §\x04\b\x03\x03\x07\b\x03\x04\x03\b\x06\x04§:String = "\n<V>• <N>";
      
      public static var §\x07\x06\x01\x06\b\x03\x05\x04\x06\x02\x02\x07\x07§:String = "$FondBouton";
      
      public static var §\x01\x01\x01\x05\x02\x05\x04\x04\x07\x05\x03§:String = "onVideoPrete";
      
      public static var §\b\b\x02\x01\x05\x05\x01\x01\x02\b\x01§:String = "$CP_";
      
      public static var §\x02\x05\x03\x03\x02\x07\x01\x03\x01\x06\x05\x05\x07§:String = "mouseUp";
      
      public static var §\x03\x01\x05\x06\x03\x04\x06\x05\x05\x07\x06\x04\x03§:String = "addEventListener";
      
      public static var §\x04\x01\x01\x03\x01\x04\x04\x05\x05\x04\x06\x05\x03§:String = "https://store.steampowered.com/app/335240/Transformice";
      
      public static var §\x03\b\x04\x05\x07\x01\x06\x02\x04\x05\x04§:String = "$ListeDesJoueurs";
      
      public static var §\x06\x06\x05\b\x03\x06\x07\x06\x05\x07\x06\x05\x03§:String = "flash.filesystem.File";
      
      public static var §\x02\x04\b\x04\x01\x03\x02\x02\x04\x03\x05\x03§:String = "x_commun/x_iconesjeux/";
      
      public static var §\x04\x06\x07\x05\x05\x01\x07\x02\x07\x02\x03§:String = "$popup.tribu.creation.titre";
      
      public static var §\x02\x07\x03\x02\x05\x05\x04\x06\x06\x04\x01\x04\x06§:String = "<b><J>";
      
      public static var §\x07\b\x04\x07\x05\x05\x04\x05\x01\x04\x07\x05§:String = "^\"";
      
      public static var §\x03\x06\b\x06\b\b\x04\x07\b\x07\x04§:String = "$InvitationChangerCodeMaison";
      
      public static var §\x05\b\x03\b\x01\x05\b\x07\b\x02\x06\x07\x05§:String = "membreAjoute";
      
      public static var §\x04\x04\x05\b\x01\x05\x04\x04\x06\x07\x02\x07\x01§:String = "$DefinirNouveauNomRang";
      
      public static var §\x02\x04\x06\x05\x07\x03\x06\x07\x01\b\x01\x05\x04§:String = "$interface.tribu.bouton.historique";
      
      public static var §\b\x04\x03\x01\x07\x07\x07\x04\x05\x02\x01\x05\x05§:String = "$interface.amis.bouton.ajouterAmi";
      
      public static var §\x03\x04\x01\x02\x05\x04\b\x07\b\x06\x07§:String = "profile?pr=";
      
      public static var §\x07\x01\x04\x07\x05\x04\x04\x01\x01\x01\x01\x02§:String = "x_transformice/x_interface/etoiles.png";
      
      public static var §\x01\x05\x07\x07\b\x05\b\x01\b\x07\x05\x07\x02§:String = "$Chamane";
      
      public static var §\x06\b\x07\x02\x07\b\b\x02\x01\x05\x07§:String = "$ModeJeuNom_8";
      
      public static var §\x05\x04\x02\x01\x02\x03\x07\x05\x07\b\b\x04§:String = "$Prems";
      
      public static var §\x06\x04\x04\x03\b\x05\x05\x03\x04\b\x02\x01§:String = "$TempsRestantClassementJour";
      
      public static var §\x04\x05\x02\x03\x05\x05\x07\x07\x03\x03\x07\x03\x07§:String = "Given sanctions";
      
      public static var §\x07\x03\x02\x04\x04\x05\b\x02\x06\x04\x03§:String = "<CS>&lt; ";
      
      public static var §\x05\x03\x07\x02\x01\x03\x05\b\x07\x01\b\x07\x07§:String = "\'>• ";
      
      public static var §\x05\b\x05\x05\x03\x05\x04\x07\x04\x02\x06\x02\x03§:String = "<T>";
      
      public static var §\x02\x02\x03\b\x05\x03\x02\b\x03\x01\x02§:String = "$Mot_Salon";
      
      public static var §\x02\b\x01\b\x05\x01\x05\x06\b\x05\x05\x05§:String = "clear";
      
      public static var §\x04\x03\b\x04\x04\x03\x05\x02\x01\x07\x05\b§:String = "silence*";
      
      public static var §\x05\x07\x01\x07\x01\b\b\x02\x06\b\x01\x01\x07§:String = "Font : ";
      
      public static var §\x02\b\x02\x04\x02\x06\x07\x03\b\x01\x04\x03§:String = "x_transformice/x_interface/kongregate/fond-invite.png";
      
      public static var §\x02\x02\x01\b\x07\x01\x05\x06\x06\x03\x01\b\x03§:String = "$SeConnecterAvec";
      
      public static var §\x03\x02\b\x06\x07\b\x03\b\x02\x03\x04§:int = 4885 + -4547;
      
      public static var §\x02\x03\x01\x06\x06\x04\b\x01\x02\x01\b\x05§:String = "<b>";
      
      public static var §\x01\x03\x02\b\x06\b\x03\x07\x06\x04\x04§:String = "x_transformice/x_connexion/";
      
      public static var §\x02\x02\x04\x05\x04\b\x05\x07\x01\x04\x05\x01\x02§:String = "<V><u>";
      
      public static var §\x07\x03\x07\x04\x07\x06\x07\x07\x03\x05\b\x01\x05§:String = "$texte.resultat.erreurInterne";
      
      public static var §\x04\x02\x06\x05\x01\x04\x03\x01\x02\x02\b\x07\x05§:String = "$Fullscreen";
      
      public static var §\x04\x03\x01\b\x02\x05\x04\x06\x07\x01\x04\x07\x03§:String = "$I11";
      
      public static var §\x05\x06\x06\x06\x04\x05\x04\x01\x06\x04\x02\x07§:String = "$MenuClassement";
      
      public static var §\x01\x05\x06\x07\x03\b\x05\x02\x04\b\x02§:String = "Nekodancer";
      
      public static var §\x07\x06\x07\x03\x03\x02\x07\x02\x03\x04\x07\x01\x02§:String = "$jeu.description.transformice";
      
      public static var §\b\x01\b\x07\x04\x05\x05\x03\x03\x02\x05\x04\x04§:String = "$nbAventuresSucces";
      
      public static var §\x07\x02\x01\x03\x05\x01\x03\b\x04\x02\x02\b§:String = "d";
      
      public static var §\x06\x01\x07\x06\x05\x02\x04\x02\b\x07\x03\x05\x05§:String = "$SalonSansComp";
      
      public static var §\x01\x06\x06\x01\x07\x04\x07\b\x07\x07\x02\x02\x04§:String = "<N>Module <VP>";
      
      public static var §\x07\x03\b\x05\x07\b\x05\x05\x06\x01\b§:String = "x_transformice/x_minijeux/x_racing.jpg";
      
      public static var §\x02\b\x05\x04\x05\x02\x02\b\x04\x02\x04\x04\x02§:String = "$ModeJeu_Music";
      
      public static var §\x03\x06\x02\x06\x03\x06\b\x05\x03\x02\x07\x07§:String = "> Tribu";
      
      public static var §\x02\x03\x06\x04\x06\x06\x01\x05\x04\x04\b\x03\x02§:String = "debugrtl";
      
      public static var §\b\x07\b\x03\x02\b\x06\x01\x05\x03\x05\x06\x05§:String = "htt";
      
      public static var §\x07\x02\x02\x03\x07\x04\x05\x05\x06\x04\x01\x03\x07§:int = 1329 + 2271;
      
      public static var §\x02\x04\x06\x04\x03\x05\x05\x03\x04\x06\x06§:Number = (7585 + 618026403) / (4953 + 999995047);
      
      public static var §\x04\x01\x02\x01\x07\x02\x01\x07\x02\x06\x05§:String = "vX";
      
      public static var §\x02\b\x02\b\x03\x07\x03\x07\x01\b\x03§:String = "$texte.messageConfirmation";
      
      public static var §\x06\x07\x07\x07\x02\x07\x06\x05\x03\x03\x03\x06\x07§:Number = (6958 + -6925) / (2407 + -2307);
      
      public static var §\b\x05\x04\x04\x04\x02\x02\x07\x06\x05\x03§:String = "|";
      
      public static var §\b\x07\x01\x03\x03\x03\x06\x05\x04\b\x06\x07\x03§:String = "x_transformice/x_aventure/x_recoltables/x_";
      
      public static var §\x04\x07\x07\x05\x02\x04\x07\x05\x02\x04\b\x06\x06§:String = "estPleinEcran";
      
      public static var §\b\x01\x02\x04\x07\x04\x04\b\x02\x03\x07\x03§:String = "7";
      
      public static var §\x07\x02\x06\b\x04\x03\x06\x02\x02\x03\x02\x03\x07§:String = "H";
      
      public static var §\x04\x01\x07\x02\x02\x04\x05\x01\x01\x04\x01\x01\x06§:String = "Numpad Add";
      
      public static var §\x02\x04\x06\x04\x06\x07\x04\x02\x03\x01\x02\x07§:String = "Numpad Substract";
      
      public static var §\x06\x06\x04\x01\x04\x04\x05\x01\x04\x03\x07\x05\x01§:String = "Shift";
      
      public static var §\x06\x07\b\x05\b\x01\x02\x06\x05\x01\x04§:String = "afficherInterfaceConnexionKongregate";
      
      public static var §\x06\x01\x01\b\x03\x03\x04\b\x06\x03\x06§:String = "submit";
      
      public static var §\x04\x05\x03\b\x02\x07\b\x04\x03\x06\x01\x07§:String = "kongregate.stats.submit(\'";
      
      public static var §\x03\x04\x02\x01\x03\b\x01\x01\x07\x01\x06\x07§:String = ".";
      
      public static var §\x06\x07\x06\x02\x01\x02\x07\b\b\x07\x05\x01§:String = "Sauvegarde ok : ";
      
      public static var §\x04\b\x06\x07\x04\b\b\x06\x07\x03\x04\b\x07§:String = "$Action_PleinEcran";
      
      public static var §\x05\x02\b\x06\x04\x01\x06\x06\b\x02\x02\x03\x07§:String = "Touche : ";
      
      public static var §\x07\b\x03\x07\x07\x03\b\x02\x04\x02\x02\x04\x02§:String = "$RaccourciNonReassignable";
      
      public static var §\x07\x07\x03\x07\x01\x07\x05\x07\x02\x04\x01§:Number = (3472 + -3465) / (5414 + -5404);
      
      public static var §\x03\x03\x01\x03\x01\x06\x02\x06\x06\x06\x01\x05§:int = 6019 + -5915;
      
      public static var §\x02\x07\x07\x01\x06\x05\x07\x01\x04\x04\b\x02§:int = 2071 + -1975;
      
      public static var §\x02\x04\x03\x06\x05\x03\x01\x07\x01\x01\x04\x04\x07§:int = 7848 + -7566;
      
      public static var §\x05\x06\x01\x04\x02\x01\x03\x03\x07\x06\x07\x05§:int = 5700 + -5562;
      
      public static var §\x02\x02\x07\x06\b\b\x07\x01\b\x04\x05\x03§:String = "seY";
      
      public static var §\x04\x03\x05\x02\x01\x04\x02\x01\x06\x01\x04\b\x04§:String = "m";
      
      public static var §\x01\x06\b\x02\b\x04\x05\x05\x07\x02\x05\x02§:String = "input";
      
      public static var §\x06\x05\x02\x07\x04\x06\x03\x01\x04\x01\x06\x06\x06§:int = 7138 + -6888;
      
      public static var §\b\x04\x01\b\x02\x03\x02\x06\x04\x01\x01\x06\x05§:String = "z";
      
      public static var §\b\x07\x06\x07\x05\x04\x05\x03\x06\x05\x02§:String = "x:";
      
      public static var §\x03\x07\x03\x01\x07\x04\x06\x01\x04\x03\x06\x02§:String = "1;0,0,0,0";
      
      public static var §\x01\x06\x05\x07\x02\x02\x02\x07\x06\x03\x07\x05§:String = "#C2C2DA";
      
      public static var §\x05\x03\x01\x07\x06\x02\x06\x02\b\b\x03\x05\b§:String = "Ma";
      
      public static var §\x07\x03\x04\x05\x04\x07\b\x03\b\x07\x05§:String = "<font face=\'Verdana\'>";
      
      public static var §\x04\x07\x01\x06\x02\x05\x01\x05\x04\x02\x04\x06\x03§:String = "$Grande_Planche";
      
      public static var §\x01\x04\x07\x03\x05\x01\x02\x06\b\x03\x03\x05§:String = " ne peut pas être après ";
      
      public static var §\x04\x01\x06\x01\b\x07\x07\x02\x06\x07\x04\x03§:String = "*pw";
      
      public static var §\x07\x02\x01\x01\b\x01\x01\x05\x01\x07\x06\x07§:String = "aj";
      
      public static var §\x02\x01\x07\x06\x05\x03\x03\x07\x01\x01\x04§:String = "version";
      
      public static var §\x03\x07\x02\x07\x05\x01\b\x06\x06\x01\x06\x06§:String = "x_plnk";
      
      public static var §\x07\x07\x02\x02\x01\x04\x06\x06\x02\b\x01§:String = "pos";
      
      public static var §\x04\x02\x07\x02\x07\x03\x03\x01\x01\x02\x03§:String = "ip";
      
      public static var §\x05\x04\b\x06\x02\x04\x03\x05\x01\x01\x01\x01\x04§:String = "ping";
      
      public static var §\x03\x04\x04\x06\x06\x04\x03\x02\x04\x01\x06§:String = "mulodrome";
      
      public static var §\x05\x02\x02\b\x03\x02\x06\x03\x02\x06\x04§:String = ", ";
      
      public static var §\x03\x05\x03\x06\b\b\x06\x04\x03\x06\x07§:int = 859 + 1799141;
      
      public static var §\b\x04\x03\x02\x07\x03\x04\x06\x05\x05\x07\x07§:String = "$Objet_";
      
      public static var §\b\x01\x01\x02\b\x04\x03\b\x04\x01\x05\x05\x01§:String = "mouseX";
      
      public static var §\x06\x04\x05\x03\x04\x06\b\x01\x05\x01\x01\x06§:String = "$Offrir";
      
      public static var §\x06\b\b\x03\x01\x07\x07\x03\x06\x06\x06§:int = 7195 + -7189;
      
      public static var §\x04\x02\x03\x05\x04\x05\x04\x03\b\x06\x05§:String = "Armor Games WEB";
      
      public static var §\x06\x01\x06\x02\x02\x04\x01\x06\x03\x06\x06\x06\x05§:String = "nb";
      
      public static var §\x03\x07\x01\x03\x03\x01\x07\x04\x04\x02\x06\x04§:String = "$Objet_27";
      
      public static var §\x03\x03\x04\b\x01\b\x07\x02\x05\x01\b\x07§:String = "salon";
      
      public static var §\b\x07\x03\x01\x03\x03\x06\x02\x03\x04\b\x01\x05§:int = 770 + -350;
      
      public static var §\x04\x02\x02\x05\x03\x07\x02\x02\x07\x03\b\x05\x06§:Number = (5068 + -5066) / (1011 + -1001);
      
      public static var §\x05\x05\x07\x03\x02\x07\x06\b\x03\x01\x04§:int = 4579 + -4479;
      
      public static var §\x01\b\x02\x06\x06\x01\b\x01\x05\x04\x03\x06§:int = 7218 + -6558;
      
      public static var §\x03\x07\x01\x07\x01\x03\x02\x07\b\x06\x01\x07§:int = 5662 + -5661;
      
      public function §\x04\x01\b\b\x06\x05\x06\x01\x01\b\x04§()
      {
         super();
      }
      
      public static function §\x04\b\x06\x04\x05\x02\b\x07\x04\b\x02\x01\x07§() : Number
      {
         return (4747 + -4735) / (6486 + -6476);
      }
      
      public static function §\x02\x05\b\x02\x07\x05\x06\x05\x05\x03\b\x06§() : Number
      {
         return (3407 + -3382) / (6859 + -6849);
      }
      
      public static function §\b\x07\b\x04\x03\x04\b\x07\x06\x03\x06\x06§() : Number
      {
         return (6705 + -6607) / (8420 + -8320);
      }
      
      public static function §\x04\b\b\x03\x05\x03\x01\x03\b\x03\x02\b\b§() : int
      {
         return 1962 + 4537952;
      }
      
      public static function §\x07\x03\x06\b\x03\b\x07\x06\x01\b\x05§() : int
      {
         return 6226 + -6117;
      }
      
      public static function §\x03\b\x03\x07\x07\x05\b\x07\x03\x07\x04§() : int
      {
         return 6489 + -6413;
      }
      
      public static function §\x01\x04\x05\x05\x04\x06\x03\x03\x01\x03\b\x07\b§() : int
      {
         return 3530 + -3529;
      }
      
      public static function §\x06\x05\x07\x06\x04\x07\x03\x05\x05\x06\x04\x04§() : int
      {
         return 5064 + -5007;
      }
      
      public static function §\x04\x01\x04\x04\x03\x04\x06\b\x01\x07\x02§() : int
      {
         return 1818 + -1780;
      }
      
      public static function §\x02\x04\x05\x05\x01\x01\x06\x04\x07\x03\x03\x07§() : int
      {
         return 7133 + -7022;
      }
      
      public static function §\x05\b\x07\x02\x03\x02\x03\x02\x01\x07\x04§() : int
      {
         return 8290 + -8284;
      }
   }
}

