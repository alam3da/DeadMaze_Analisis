package
{
   public class §\x04\x01\x03\x03\x05\x04\x03\x03\x07\x04\x06§
   {
      
      public static var §\x07\x07\x06\x07\x02\x04\x06\b\x04\x06\x02§:int = 7434 + 566;
      
      public static var §\x05\x06\x02\x03\x01\x03\b\x07\x04\x03\x07\x04\x05§:Number = (1210 + -377) / (6882 + -5882);
      
      public static var §\x01\x04\x02\x01\x07\x02\x01\x04\x02\x02\x02\x01\x02§:int = 9606 + -7109;
      
      public static var §\x05\x03\x02\x04\x07\x07\x02\x03\x01\x02\x04\x06§:String = "$P_59";
      
      public static var §\b\b\x07\x01\x01\x07\x01\b\x07\x01\x01\x02\x05§:String = "$Editeur";
      
      public static var §\x03\x02\x01\x04\x07\x04\b\x01\x01\b\x02\x06§:String = "costume1.swf";
      
      public static var §\x07\x03\x06\b\x07\x04\x05\x03\x03\x07\x07\x03\x01§:String = "m2";
      
      public static var §\x01\x01\x06\x03\x04\x04\b\x03\x04\b\x07\x03\x03§:String = "x_transformice/x_evt/x_evt_10/YIKDFERT/BOSS_AnvilGod.png";
      
      public static var §\x05\b\b\x02\x05\x01\x07\x06\x01\x03\x05\x07§:int = 1979 + -1038;
      
      public static var §\x04\x07\x05\b\x07\x06\x05\x05\x03\x04\x02\x06§:String = "$FlecheBoussole";
      
      public static var §\x04\x05\b\x04\x03\b\x07\x05\x06\x07\x03\x05§:String = "$BtnObjetMagasin";
      
      public static var §\x03\x07\x06\x06\x05\x03\x04\b\x05\x01\x04\x07§:String = "Costume introuvable : ";
      
      public static var §\x03\x07\x01\x07\x01\x07\x04\x07\x02\x01\x04\x06\x02§:String = "x_transformice/x_interface/fonds_shop/";
      
      public static var §\x04\x06\x06\x06\x01\x07\x07\x03\x03\x05\x02\x01§:String = "x_transformice/x_interface/coeur_vide.png";
      
      public static var §\x05\x04\x03\x03\x06\x04\x01\b\b\x04\x04\x04\x03§:int = 5599 + -4784;
      
      public static var §\x07\x05\x03\x05\x02\b\x07\x06\x04\x04\x07\x04\x03§:int = 2508 + -1983;
      
      public static var §\x04\x04\x04\b\x06\b\x01\x05\x01\b\x02\x01§:String = "$Ignorer_Temporairement";
      
      public static var §\x05\b\x05\x01\x01\b\x04\x05\x06\b\x03\x07§:String = "ID_LIGNE_";
      
      public static var §\x04\x01\x02\x03\x04\x01\x06\x03\x06\x04\x04\x07\x01§:String = "$RemplacerQuete";
      
      public static var §\x03\x05\x01\b\x06\x04\x06\x03\x02\x06\x01\x06§:String = " : <font color=\'#CB546B\'>";
      
      public static var §\x07\x02\x07\x02\b\x01\x06\x06\x06\x05\x06\x01\x05§:String = "$S_partieJouee";
      
      public static var §\b\x05\x04\x06\x01\x01\x01\x02\x05\x01\x05\x06§:String = " <font color=\'#";
      
      public static var §\x03\x07\x03\x06\x07\x05\x06\x06\x05\x06\x04\b\x02§:String = "$FondQJ1";
      
      public static var §\b\x01\x04\x05\x06\x05\x01\x01\x01\b\x06\x06\x06§:String = "title:\\s*(.*)";
      
      public static var §\x07\x06\x06\x05\x01\x02\b\x03\x05\x03\x05§:String = "<V><font size=\'14\'>";
      
      public static var §\x07\x02\x07\x01\b\x02\x01\x02\x05\b\x01\b§:String = "<font color=\'#7EBC78\'>★★★★★★</font>";
      
      public static var §\x07\x01\x01\x06\x06\x02\x07\x04\x04\x07\x07\x04\x07§:String = "x_i_17.png";
      
      public static var §\x02\x06\x01\b\x06\x05\x01\x02\x05\x01\x03§:String = "x_i_30.png";
      
      public static var §\b\x05\b\x01\x02\x02\x02\x03\x01\x04\x04\x07§:String = "x_i_10.png";
      
      public static var §\b\x07\x02\x06\x07\x05\x01\x02\x03\x02\x06\x07§:String = "MouvementDebut";
      
      public static var §\x05\x03\x02\x03\x01\x05\x02\b\x04\x02\x04§:String = "x_evenements/x_bonbon_";
      
      public static var §\x05\b\b\x06\x06\x05\x04\b\x03\x03\x03\x03\x06§:String = "$E_1";
      
      public static var §\b\x01\x03\x02\x02\x02\x06\x03\x03\x03\x01\x01§:String = "$Tutorial_1";
      
      public static var §\x07\x06\x03\x01\x05\x01\x02\x07\b\x02\x02\x07§:String = "SG2";
      
      public static var §\x06\x02\x02\x05\x05\b\x02\x06\x02\x01\x03§:String = "SF";
      
      public static var §\b\x01\x05\x05\x06\x02\b\x06\x05\x03\x03\x05§:String = "SL";
      
      public static var §\x07\x01\x03\b\x01\x01\x05\x05\x03\x04\b\x04§:String = "ori";
      
      public static var §\x01\x06\x04\x02\x02\x06\x01\x06\x06\x02\x01\x02\x05§:String = "2000";
      
      public static var §\x06\x04\x04\x07\x07\x01\x05\x07\x02\x04\x05\x06§:int = 6906 + -4886;
      
      public static var §\x05\x05\x01\x03\x05\x07\x06\x04\b\x01\x06\x05§:String = "$Echec_Cavalier";
      
      public static var §\x01\x04\b\x02\x03\x03\x03\x02\b\x04\b\x01\x05§:String = "http://transformice.com/images/wallpaper/";
      
      public static var §\x05\x04\x02\x05\x01\x01\x06\x07\x04\x04\x03\x03§:String = "1;0";
      
      public static var §\x07\x07\x06\x04\x01\x04\x02\x06\x04\x07\x07\x04\b§:String = "\' size=\'10\' color=\'#C2C2DA\'>";
      
      public static var §\x07\x06\b\x02\x07\x07\x04\x05\x07\b\x02§:String = "$DonItemPossedeDeja";
      
      public static var §\x07\x01\b\x02\b\x06\x02\x06\x04\x01\x07§:String = "$Personnalisation";
      
      public static var §\x06\x02\x06\x06\x07\x07\x03\x07\b\x01\x01§:int = 5832 + -5504;
      
      public static var §\x03\x02\b\x05\x02\x05\x05\x03\x05\x01\x06§:String = "$OffrirItem";
      
      public static var §\x03\x03\x01\x05\x01\x06\x04\x02\x07\x05\b\x02§:String = "x_pinceau";
      
      public static var §\x04\x03\x06\x01\x01\x07\x05\x03\x04\x02\x04\x04§:String = "$Personnaliser";
      
      public static var §\x04\x01\x05\x03\x06\b\x03\x04\x06\x01\x03\x02§:String = "balle";
      
      public static var §\x03\x05\x01\x02\x06\x05\x02\x02\x02\x07\x07\x07\x04§:String = "petite_caisse";
      
      public static var §\x07\x06\b\x01\x03\x02\x07\x02\x07\x03\x05§:String = "glove";
      
      public static var §\x02\x03\x03\x03\x04\x01\x05\b\x01\x02\x05\x02\x05§:String = "$OM3";
      
      public static var §\x04\x01\x07\x01\x01\x06\b\x06\x01\x04\b\x06§:String = "$OM2";
      
      public static var §\x05\x05\x07\x05\x04\x06\x03\x03\x05\x02\x03\x03\x07§:String = "etoile";
      
      public static var §\x07\x06\x04\x03\b\x05\x01\x04\x06\x07\x03\b§:String = "cu_br.txt";
      
      public static var §\x01\x01\x05\x04\b\x01\x05\x06\x04\x03\x01\x02\x06§:String = "_Couleur";
      
      public static var §\x03\x07\x02\x05\x04\x01\x07\b\x06\x03\x06\b\x07§:int = 8198 + 17991802;
      
      public static var §\x03\x02\x06\b\x06\x06\x07\b\x07\x07\x01\x04§:String = "</a>\n<N>";
      
      public static var §\x01\x04\x07\x04\x04\x03\x07\x04\x04\x02\x07§:String = "M_3.png";
      
      public static var §\x07\x03\x04\b\b\x05\b\b\x05\x05\x01\x06§:String = "$MachineSous";
      
      public static var §\x06\x07\x05\x03\x02\x03\x01\x06\x01\x04\x03§:String = "$EquipePasEnLigne";
      
      public static var §\b\x06\x05\x03\x01\x04\b\x06\x06\x04\x07\x05\x01§:String = "rightMouseUp";
      
      public static var §\x04\x07\x04\x05\x07\b\b\x01\x05\x04\x03\x05§:Number = (4156 + -3489) / (2033 + -1033);
      
      public static var §\x03\x03\b\x05\x02\x06\x03\x04\x01\x05\x04\x06§:String = "_stun";
      
      public static var §\x03\x04\x07\x03\x01\x06\x07\x03\b\x03\x06\b§:String = "$AnimZombieAttaque";
      
      public static var §\x02\x02\b\x04\b\x05\x01\b\x03\x02\x04\b\x01§:String = "$AnimAttaque_F_2";
      
      public static var §\x05\x01\x01\x02\x03\x04\x06\x07\x01\x01\x06\x05§:String = "$AnimManipComp";
      
      public static var §\x01\x01\x05\b\x03\b\x04\x02\b\x07\x05\x01§:String = "$EchecCraft";
      
      public static var §\x02\x02\x05\x03\x03\x01\x04\x06\x05\x02\x02§:String = "$Selection_1";
      
      public static var §\x01\x02\b\x01\x06\b\x03\b\x05\b\x01\x07§:String = "emote";
      
      public static var §\x03\b\x06\x03\b\x02\b\x01\x07\x06\x02§:String = "image_tenue";
      
      public static var §\x04\x05\x03\x03\x06\x02\b\x04\b\x07\x05\x04§:String = "x_deadmeat/x_interfaces/principale/trier.png";
      
      public static var §\x07\x04\x07\b\x07\x06\x06\x03\x03\x01\x04\x07§:String = "<font size=\'11\'>\n<G>• ";
      
      public static var §\x01\x05\b\x05\x04\x03\x03\x07\x04\x02\x01\x06§:String = "x_deadmeat/x_interfaces/monde/monde.jpg";
      
      public static var §\x06\x06\b\x03\x05\x07\b\x04\b\x07\b\x01\x03§:int = 4132 + -3645;
      
      public static var §\b\x04\x01\x02\b\x05\x01\x06\x05\x01\x07\x06§:String = "$TitreProjetsRecherche";
      
      public static var §\b\x05\x06\x03\x06\x04\b\x03\x02\x03\x03\x02§:String = "1000";
      
      public static var §\x07\x02\x05\x03\x04\x01\x02\x01\x02\x07\x01\x03§:String = "disable asynchronous mode";
      
      public static var §\b\x03\x04\x03\x03\x05\x07\x01\x06\x01\x02\x02\x02§:String = ",5,5";
      
      public static var §\x06\b\x03\b\x01\x05\b\x01\x07\x03\x01\x05§:String = "spawn";
      
      public static var §\x07\x03\x06\x03\x02\b\b\x04\x03\x05\b§:String = "x_deadmeat/x_interfaces/divers/magasin.png";
      
      public static var §\x05\x02\x03\x02\x03\b\b\x07\x03\x06\x07\x03§:String = "%)";
      
      public static var §\x02\x07\x06\x06\x03\x04\x07\x03\x02\x06\x07\b\x06§:String = "x_deadmeat/x_interfaces/cinematique/";
      
      public static var §\x05\x02\x02\x02\b\x03\x02\x05\x05\x07\x06\x03\x01§:String = "$Haut";
      
      public static var §\b\x03\x06\x01\x06\x03\x04\x03\b\x07\x06§:String = "0-9\\-";
      
      public static var §\x03\x03\x05\x07\x02\b\x06\x03\x01\x06\b\x06§:String = "$ETB_7";
      
      public static var §\x07\b\x04\x03\x06\x07\x01\x02\x02\x02\b\x02\x01§:String = "+25%";
      
      public static var §\x05\x04\x04\x01\x02\x06\x05\x07\x05\x06\x04\x02\x04§:String = "$ETM_4";
      
      public static var §\x05\x05\x03\b\x06\x03\b\x03\x07\x07\b\b§:String = "CHLOE_THORN";
      
      public static var §\x04\x07\x01\b\x07\x03\x04\x07\x03\x03\b\x01\x04§:String = "amb_cinematique";
      
      public static var §\x02\b\x06\x01\x06\x05\x01\b\x05\x04\x05§:int = 9490 + -9117;
      
      public static var §\x04\x05\x03\b\x03\x02\x03\x04\x05\x01\x03§:String = "x_deadmeat/x_campement/fond1.jpg";
      
      public static var §\x04\x01\x05\x03\x03\x01\x01\x07\x07\x07\x07§:String = "$TutoRepos_2";
      
      public static var §\x06\b\x06\b\x04\x05\b\x05\x03\x03\x03\x06§:String = "$HaloFeu";
      
      public static var §\x03\x01\x07\x06\x02\x01\x01\x06\x03\x04\x03\x06§:String = "$GainNiveau";
      
      public static var §\x03\x02\x06\b\x02\b\x05\x01\x06\x05\x04§:String = "x_deadmeat/x_interfaces/divers/boussole2.png";
      
      public static var §\x01\x02\x01\x05\x05\x06\x06\x07\x01\x07\x03§:String = "x_deadmeat/x_interfaces/divers/jauge-froid.png";
      
      public static var §\x07\x04\x06\x04\x06\x04\b\x05\x03\x06\x02\x07\x05§:String = "<font size=\'11\'><G>[";
      
      public static var §\x04\x06\x01\b\x04\x04\x05\b\b\x02\x03\x03§:String = "]</N></font>\n";
      
      public static var §\x01\b\x05\x04\x05\x05\x03\x03\x02\x01\x04\x06§:int = 6862 + -6577;
      
      public static var §\x06\x03\b\x04\x06\b\x01\x06\b\b\b\x03\x05§:String = "$objectif.";
      
      public static var §\x07\x06\x03\b\x07\x06\x06\x04\b\b\x01§:String = "\n<B>";
      
      public static var §\x01\b\x06\x06\x04\b\x07\x06\x06\x06\x03\x03§:String = "x_deadmeat/x_interfaces/principale/fond_menace.png";
      
      public static var §\x01\x06\x07\x04\x06\b\x01\x02\x01\x02\x01\b\x02§:String = "\n<V><font size=\'11\'>  + ";
      
      public static var §\x04\x04\x05\x01\x04\x01\x07\x01\x01\x07\x07\x03\x03§:String = "x_deadmeat/x_interfaces/x_symptomes/_";
      
      public static var §\x06\x05\b\x04\x05\x04\x04\x02\x03\x01\x02\x03\x03§:String = "\n<font color=\'#FF8B6B\'>• ";
      
      public static var §\x06\x01\x03\x04\x02\x05\x05\x02\x05\x03\x05\x06§:String = "$LibelleAventures";
      
      public static var §\b\x03\x04\b\x02\x07\b\x06\x06\x07\x01\x05\x07§:String = "$TitreFenetreAventuresExpeditions";
      
      public static var §\x07\x06\x06\x04\x01\x03\x03\x06\x05\x03\x02\x04\x03§:String = " »";
      
      public static var §\x04\x06\x02\x01\x06\x06\x04\x04\x06\x04\b\x07§:String = "$NouvelleZone";
      
      public static var §\x01\x07\x05\x05\x04\x05\x06\x03\x04\x03\b\b\b§:String = "tuto_conteneur";
      
      public static var §\x05\b\x04\b\x06\b\x03\x04\x02\x07\b\x01§:String = "instance";
      
      public static var §\x01\x06\b\x02\x06\x05\x06\x07\x01\x03\x04\x07\x06§:String = "_Arme";
      
      public static var §\x05\x05\x04\x03\x02\x07\x06\x01\b\x07\x03\x02§:String = "<font size=\'11\'><font color=\'#48AEEC\'>\n";
      
      public static var §\x04\b\x04\x04\x06\x02\x01\x03\x04\x04\b§:String = "$Destruction";
      
      public static var §\x06\b\x04\x05\x06\b\x01\x02\b\x07\x01\x02§:String = "$FX_8";
      
      public static var §\x05\x03\b\x02\x01\x07\x02\x07\x05\x06\x06\x03§:String = "$EditeurIDRepereZoneNommee";
      
      public static var §\b\b\x04\x04\b\x05\x07\x07\x02\x05\x01§:String = "$EditeurConfirmerSuppressionScript";
      
      public static var §\x06\x07\x03\b\x07\x05\x02\x03\x07\x03\x04§:String = "noScale";
      
      public static var §\x06\x02\x01\x02\x01\x05\x03\x03\x05\x02\x05\b\x04§:String = "Add elemental area \n<N>(<V>CTRL</V> to remove)";
      
      public static var §\b\b\x05\x03\x04\x02\x07\x03\x06\x04\x06\x05§:String = "Rotate left";
      
      public static var §\x04\b\x03\x04\x07\x05\x04\x01\x07\x03\x03§:String = "rotation1";
      
      public static var §\x01\x04\x04\x07\x02\x02\b\x01\x05\x06\x02\x07§:String = "Horizontal flip <V>(B)";
      
      public static var §\b\x04\x02\b\x03\x04\x01\x07\x06\x02\x06\x05\x07§:String = "x_deadmeat/editeur/outils/taille.png";
      
      public static var §\x02\x03\x07\x01\x04\x05\b\x05\x01\x02\x02\x05§:String = "$EditeurDensiteMaxSpawn";
      
      public static var §\x03\x06\x06\x05\x01\x03\x05\x01\x05\x04\x01\x03§:String = "$EditeurTitreImportTraductions";
      
      public static var §\x07\x05\x04\x01\x07\x06\x05\x01\x06\b\x01\x06§:String = "CZ";
      
      public static var §\b\x02\x07\x06\x02\x01\x02\b\x05\x04\x07§:String = "<V>Mode copie couleur : OFF";
      
      public static var §\x02\x06\x02\x06\x06\x01\x02\x06\x06\b\x01\x07§:String = "Duree AStar : ";
      
      public static var §\x02\x06\x07\x02\x04\x02\x01\b\x07\b\x07\x04§:String = "Info décors introuvable [";
      
      public static var §\x05\b\b\x04\x06\x05\x04\x01\x07\x04\x01\x02\x01§:String = "collisionable";
      
      public static var §\x01\x02\x02\x03\x01\x04\b\x03\x02\x04\b§:String = "famfamfam/anchor.png";
      
      public static var §\x03\x05\x05\x03\x06\x03\x06\x07\x01\x02\x04\x06§:String = "$CadrillageSpawn";
      
      public static var §\b\x01\x02\x04\x07\b\x03\x04\x05\x02\x02\x06\x01§:String = "campement_nuit";
      
      public static var §\x01\x07\x07\x04\x03\x06\x06\x01\x06\x06\x02\b\x03§:String = "x_deadmeat/x_pictos/d_";
      
      public static var §\x05\x07\x07\x01\x07\x06\x01\x06\x05\x01\x03\x01§:String = "$PDM_1";
      
      public static var §\x04\x04\x02\x05\x06\x05\b\x02\x02\x05\x01\x01\x04§:String = "Chapeaux_01.swf";
      
      public static var §\x05\x06\x03\b\x07\x03\x07\x06\x03\x07\x04\x07§:String = "$Action_AfficherCacherInterfaces";
      
      public static var §\x02\x07\x05\x04\x06\x07\x05\b\x02\x05\x06§:String = "$Action_InterfaceSmiley";
      
      public static var §\x04\x02\x01\x01\x07\b\x02\x03\x02\x03\x04§:Number = (8401 + -6601) / (7657 + -7647);
      
      public static var §\x03\x07\x07\x07\x05\x04\x03\b\x06\x05\b\x06§:String = "MESSAGE DEADMEAT INCONNU : 105,";
      
      public static var §\x04\x02\x04\x01\x07\x01\x04\x01\x06\x01\x07\x03\x04§:String = "<font size=\'12\'><V>\n<i>« ";
      
      public static var §\x01\x04\b\x05\x02\x02\x04\x05\x03\x07\x04\x05§:String = "$CouleurCheveux";
      
      public static var §\x07\x03\x02\x01\x04\x02\x02\x03\x03\x05\x06\x05\x02§:String = ".nom";
      
      public static var §\x07\x02\b\x03\b\x01\x03\x05\x06\x04\b\x03\x02§:String = "Chargement de la bibliothèque : ";
      
      public static var §\x07\x04\b\x06\x06\x04\x05\x07\b\x03\x04\x05\b§:String = "AnimCourse";
      
      public static var §\x03\x01\x02\b\b\b\x07\x01\x03\b\x05§:String = "multi_";
      
      public static var §\b\x01\x05\x07\b\x01\x03\b\x06\x01\x06\x06§:String = "lua_";
      
      public static var §\x04\x01\x06\x06\b\x04\x01\x06\x04\x04\x04§:String = " true";
      
      public static var §\x07\x06\x02\x02\x01\x02\x03\x03\b\x02\x06\x07§:String = "[Tutorial]";
      
      public static var §\x02\x07\b\x03\b\x04\x07\x02\x04\x06\x03§:String = "\n<J>Exception pour [";
      
      public static var §\x02\x07\x02\x05\x01\x07\x06\x07\x06\x01\x04\x06§:String = "youtube.com";
      
      public static var §\x04\b\x02\x03\x01\b\x01\x05\x05\x05\x03§:String = "$Demande_Ban";
      
      public static var §\x03\x05\x07\b\x05\x04\x03\x03\x02\x05\x06\x01§:String = "<font color=\'#B993CA\'>• ";
      
      public static var §\x07\b\x07\b\b\b\x01\x01\x04\b\x04\x06§:String = "$Deco_Joueur_Tribu";
      
      public static var §\x05\b\x02\x05\x05\x05\b\x06\x01\x04\x02\x01\x03§:String = "kreds";
      
      public static var §\x04\x04\b\x03\x01\x05\x02\b\x04\x01\x06\x02\x03§:String = "<G>-<R>";
      
      public static var §\x02\x03\x06\x06\x02\b\x02\x07\x01\x03\b\x07\x02§:String = "b";
      
      public static var §\b\x06\x07\x07\x05\x03\x03\b\x04\x02\x03\x05§:int = 6262 + 38178;
      
      public static var §\x05\x01\b\x07\x06\x06\x01\x06\x01\x07\x06§:String = "] --> ";
      
      public static var §\b\x05\x05\b\x01\x07\x01\b\x03\x01\x05\x04§:String = "# MapCrew";
      
      public static var §\x06\x04\x02\x04\x05\x07\x06\x01\x02\x05\x01\x03§:String = "$erreur.tribulle2.limiteAmisAtteinte";
      
      public static var §\x04\x03\x04\x07\x04\x01\x02\x02\x02\b\x07\x05\x02§:String = "$Refuser";
      
      public static var §\x02\b\x06\x07\x06\x03\x04\x06\x07\b\x02\x07§:String = "$Coeur";
      
      public static var §\x02\x05\x01\b\b\x06\x02\x06\b\x04\x05\b§:String = "$TexteSoopa";
      
      public static var §\x03\x01\x04\x05\x01\x01\x06\x07\x01\b\x05\x07§:String = "$2";
      
      public static var §\x03\x07\x01\x02\x01\b\x05\x07\x03\x07\b\x07§:String = "onYouTubeIframeAPIReady";
      
      public static var §\b\x06\x07\x02\x07\x01\x07\x03\x02\x06\b\x05§:String = "returnValue";
      
      public static var §\x03\x05\x05\b\x05\x04\x05\x04\x04\b\b§:String = "Hrvatski";
      
      public static var §\x03\x02\x03\x02\x02\x02\x06\x06\x01\x06\x04\x05§:String = "ph";
      
      public static var §\x02\b\x05\b\x03\x05\x02\x05\x05\x01\x04\b\x07§:String = "nl";
      
      public static var §\x07\b\x02\x05\x07\b\x04\x06\x02\x01\b\x06§:String = "Русский";
      
      public static var §\x01\x05\x02\x07\b\x02\x07\b\x06\x05\x07\x05§:String = "Polski";
      
      public static var §\x02\x04\x04\x01\b\x03\x07\x05\x04\x06\x06\x02§:String = "pt-br";
      
      public static var §\b\x03\x01\x02\x04\x01\x01\x02\x02\x04\x01§:String = "authentifierSurFB";
      
      public static var §\x07\x07\x01\x05\x02\x06\x02\x06\x05\b\x02\x02§:String = "retrieve";
      
      public static var §\x05\x06\x05\x04\x05\x06\x07\x01\b\b\x05§:String = "$1";
      
      public static var §\x03\x07\x03\x01\b\x01\x04\x01\x04\x05\x02\x01§:String = "Mac";
      
      public static var §\x05\x05\x07\x05\x03\x03\x04\x07\x01\x06\b\x04§:String = "x_transformice/x_interface/";
      
      public static var §\x05\x04\b\x05\b\x02\x06\x04\x01\x04\x03\b§:String = "$GetSteam4";
      
      public static var §\x05\x01\x03\x07\x07\x04\x07\x02\x03\x07\x04\x01§:Number = (9658 + -9568) / (5946 + -5936);
      
      public static var §\x02\x03\x06\x04\b\x03\x02\x01\x03\x04\x03\x03\x06§:String = " more";
      
      public static var §\x06\x07\x03\x03\x02\x04\b\x03\x05\x02\x02\x02\x01§:String = "« ";
      
      public static var §\x05\x04\x02\x02\x04\b\x03\x05\x06\x05\x07\x06\b§:String = "$popup.tribu.quitter.etiquette";
      
      public static var §\x04\x07\b\x05\x07\x02\x03\x06\x02\x05\x02§:String = "$ChangerCodeMaison";
      
      public static var §\x07\x07\x01\x07\x04\x03\b\x04\x03\b\x03\x02§:String = "$popup.tribu.exclureMembre.titre";
      
      public static var §\x05\x06\x03\x04\x05\b\x03\x04\x01\x03\x03\x04§:String = "fr/";
      
      public static var §\x05\x05\x02\x04\x04\x03\x07\x02\x07\x04\x03§:String = "$DemarchageMail";
      
      public static var §\x05\x07\x03\b\x05\x02\x01\x03\b\b\x02§:String = "$Menu_1";
      
      public static var §\x01\x01\x05\b\x01\b\x06\x02\x07\x01\x02\x04\x04§:int = 1254 + -504;
      
      public static var §\x06\b\x06\x03\x02\x01\x02\x04\x01\x07\x02\x01\x07§:String = "$C_SourisSauvées";
      
      public static var §\x04\x02\x03\b\x02\x06\x04\x06\x06\x02\x02§:String = "\\s*[:：]\\s*%1";
      
      public static var §\b\x07\x06\x03\b\x07\b\b\b\x02\x02§:int = 1601 + 418;
      
      public static var §\x03\x04\x06\x06\x05\x01\b\x06\x04\x06\b§:String = "   <PT>[";
      
      public static var §\b\x03\x02\x03\x06\x05\x02\x07\x01\x03\x07\x06§:String = "   <font color=\'#";
      
      public static var §\b\x06\x06\x05\x07\x04\b\x07\x06\x06\x03§:String = "•";
      
      public static var §\x06\x02\b\x04\x05\x01\x03\b\x06\x04\x02\x04§:String = "shiftKey";
      
      public static var §\x02\x06\x03\x04\x04\x01\x05\x05\x02\x07\x03\x04\x01§:String = "w";
      
      public static var §\x01\b\x07\x01\x06\x02\x04\x01\x07\b\x05\x04\x04§:String = "bootcamp";
      
      public static var §\x03\x02\x05\x01\x05\x03\x06\x02\x06\x04\x04§:String = "<N>Transformice<BL>";
      
      public static var §\x02\x03\x04\x05\x07\x06\b\x03\x03\b\x06§:String = "x_transformice/x_interface/google/auth_google.png";
      
      public static var §\x07\b\x07\x06\x02\x04\x03\x02\x05\x04\x04\x03§:String = "$Jouer_Invite";
      
      public static var §\x03\x06\x01\x02\x07\x03\b\x05\x05\b\x06\x06\x01§:String = "$MDP_Chiffre";
      
      public static var §\b\x03\x06\x01\x06\x04\x07\x04\x02\x06\x04\x02\x07§:String = "https://discord.gg/transformice";
      
      public static var §\x05\x07\x01\x01\x02\x05\x04\x03\x06\x07\b\b§:String = "$E_Retour";
      
      public static var §\x04\x04\x04\x03\x02\x01\x06\x04\x02\x07\x02\x01§:String = "x_aj";
      
      public static var §\x07\x01\x02\x05\x06\x04\x01\x05\x06\b\x07§:String = "><G>]</G>";
      
      public static var §\b\x06\x04\x07\x03\x03\x06\x02\b\x03\x01\x05\x04§:String = "ier";
      
      public static var §\x02\x04\b\b\x06\x01\x01\x06\x06\x03\x04\x01\x02§:String = "as";
      
      public static var §\x02\x04\x07\x01\x05\b\x04\x03\b\x05\x04\x06§:String = "</J>";
      
      public static var §\b\x02\x07\x07\x07\x04\x07\x03\x01\b\x03\x07\x04§:String = "$SalonAvecModeAie";
      
      public static var §\x03\x06\x07\x03\x07\x05\x05\x02\x03\x01\x01§:String = "<J>Micelabs <VP>";
      
      public static var §\x04\b\x01\x03\x04\x03\x03\b\x05\x04\b\x04\x01§:Number = (4671 + 10774) / (6740 + -6640);
      
      public static var §\x01\x05\b\b\x01\x02\x06\x02\x01\x01\b\x06\x05§:int = 9843 + -9263;
      
      public static var §\x01\x03\b\x03\b\x06\x05\x01\x03\x05\x04§:String = "$Mois_";
      
      public static var §\x01\x02\x07\x07\x02\x07\b\x06\x07\x02\x02\x05§:String = "<N><font size=\'12\'>";
      
      public static var §\x06\x06\x02\x07\x03\x04\x02\x06\x06\x04\x04\x01§:String = "<R>-</R>";
      
      public static var §\x01\x04\b\x04\b\x03\x07\x01\x04\x01\x06§:String = "discord@";
      
      public static var §\x05\b\x02\x05\x04\x03\x04\x02\x03\x06\x02§:String = "x_commun/x_calendriersucces/sceau-patte-aventures.png";
      
      public static var §\b\x04\x06\x05\x06\x01\x03\x07\x02\b\x03§:Number = (7823 + -7803) / (5518 + -5508);
      
      public static var §\x05\x05\b\b\x05\x03\x07\x06\x06\x06\x05\b\x02§:String = "enterFr";
      
      public static var §\b\x06\x05\x02\x02\x07\b\x05\x03\x06\x03§:String = "F3";
      
      public static var §\x04\x07\x04\x05\x01\x06\x04\x03\x02\x02\x04\x02§:String = "Numpad 8";
      
      public static var §\x06\x07\x03\x05\b\x03\x03\x02\x05\x05\x05\x04§:String = "Numpad 7";
      
      public static var §\x02\x05\x06\x07\x03\x02\x02\x03\x01\x04\x01\x05§:String = "E";
      
      public static var §\x02\x06\x03\x01\x06\x07\x03\x02\x06\x01\x04\x01§:String = "Tab";
      
      public static var §\x02\x05\x01\x03\x01\x07\x06\x06\x03\x04\x02\x04\b§:int = 1002 + 1014;
      
      public static var §\x03\x01\x07\b\x01\x04\x03\x02\b\b\x07\x05§:String = "/sba";
      
      public static var §\x06\x05\x07\x04\x02\x02\x05\x02\x06\x02\x03\x05§:String = "shareable";
      
      public static var §\x01\x03\x05\x06\x01\x06\x02\x07\x05\x05\x01§:String = "</T> ms";
      
      public static var §\x07\x06\x07\x03\x06\x07\x06\x02\x02\x04\x01\x06\x01§:String = "onInitialisationGAPITerminee";
      
      public static var §\x02\x03\x03\x06\x01\x02\x05\x04\x06\x05\x05\x03§:int = 6094 + -5889;
      
      public static var §\x07\x07\x05\x06\b\b\x03\x03\x06\x02\x07§:int = 3805 + -3604;
      
      public static var §\b\x01\x06\x02\x03\x04\x07\x03\x03\x03\x07\x04\x03§:int = 1240 + -1101;
      
      public static var §\x04\x02\x01\b\x01\b\x07\x01\x01\x04\b§:int = 7492 + -7367;
      
      public static var §\x04\x06\x07\x07\x05\x01\x05\x07\x02\x01\x01\x04\x06§:int = 9304 + -9249;
      
      public static var §\x05\x03\x07\x03\x04\x06\b\x02\x02\x07\x06§:int = 4156 + -3931;
      
      public static var §\x03\x06\x02\x04\x07\x07\x07\x02\x04\b\x01\x05\x05§:int = 4979 + -4783;
      
      public static var §\x02\x04\x01\x01\x01\b\x01\x01\x01\b\x05§:int = 1813 + -1665;
      
      public static var §\x01\x05\x02\b\x03\x02\x02\x06\x07\x05\x07§:int = 9624 + -9367;
      
      public static var §\x07\b\x02\x05\x07\x03\x07\x01\b\x06\x06\x05\x01§:String = "$editeur.vitesseBonusSortie";
      
      public static var §\x02\x06\b\x05\x07\x03\x07\x02\x01\x04\x01\x05§:String = "$editeur.cible";
      
      public static var §\b\x02\x03\b\x07\x05\x07\x06\x03\x02\b\b\x07§:String = "DS";
      
      public static var §\b\x05\x03\x07\x06\x06\x04\x03\b\x03\x05§:String = "defilante";
      
      public static var §\x02\x04\x03\x01\x01\x05\x03\x04\x04\x03\x07\b§:String = "LIMITE_O";
      
      public static var §\x07\x03\x04\x06\x04\x07\x01\x03\x07\x06\x02\x05§:String = "$Prix";
      
      public static var §\x02\x03\x04\x01\x01\x03\x07\x05\x07\b\x04\x05\x05§:String = "WmiPrvSE.exe                  6424 Services                   0     7ÿ228 Ko\t\t\tjava.exe                      6256 Console                    1    24ÿ432 Ko\t\t\tconhost.exe                   3656 Console                    1     3ÿ660 Ko\t\t\tadl.exe                       6272 Console                    1    24ÿ888 Ko\t\t\tconhost.exe                   6292 Console                    1     3ÿ632 Ko\t\t\ttasklist.exe                  5912 Console                    1     5ÿ468 Ko\t\t\tconhost.exe                   6052 Console                    1     3ÿ624 Ko";
      
      public static var §\x02\b\x05\x03\x05\x03\b\x01\x04\x04\x01\x01\x04§:int = 5535 + -5392;
      
      public static var §\x02\x06\x04\x07\b\x03\x04\x04\x04\x04\x04§:String = "Test ? ";
      
      public static var §\b\x04\b\x07\x06\x06\x04\x01\x02\b\b\x01\x03§:String = "#E88F4F";
      
      public static var §\x06\b\x06\x06\x07\x02\x01\x03\b\b\x02\x04§:String = "#CAA4CF";
      
      public static var §\x05\x02\x01\b\x05\x04\b\b\x05\b\x07\x03\x02§:String = "N2";
      
      public static var §\x03\x01\x02\x06\x06\x03\x04\x05\x01\x04\x07\b§:String = "#CB546B";
      
      public static var §\x05\x04\x06\x07\x04\x06\x06\x01\x06\x01\x03\x04§:String = "$OC_Concentration";
      
      public static var §\x05\b\x03\x02\x04\x03\x02\x02\x05\x07\x05\x06§:String = "Totem";
      
      public static var §\b\x02\x06\x03\x01\x05\x06\x03\x04\x06\x05\x07\x04§:String = "$Rune";
      
      public static var §\x03\x03\x01\x04\x01\b\x05\x06\x01\x06\x01§:int = 1116 + -1098;
      
      public static var §\b\x04\x06\b\x01\x05\x07\x02\x05\x02\x04\x02\x04§:String = "$Boulet";
      
      public static var §\b\x05\x04\x05\x04\x02\x06\x05\b\x03\x05§:String = "$Balle_Lourde";
      
      public static var §\b\x07\x04\b\x05\x07\b\x04\x05\x05\x01§:String = "$Grosse_Caisse";
      
      public static var §\x02\x02\x03\x03\x05\x03\b\x03\b\x03\x05\x07§:int = 7594 + -7141;
      
      public static var §\b\x06\x04\b\x03\x02\x02\x03\b\b\x02§:int = 345 + 97;
      
      public static var §\x02\b\x04\x01\x06\x06\b\x06\x04\x01\x01\x06§:int = 8270 + -7830;
      
      public static var §\x04\x03\x05\x06\x04\x04\x04\x06\x05\b\x04§:String = "password";
      
      public static var §\b\x04\x05\x05\x05\b\b\x03\x01\x07\x04§:String = "$AideBouboum";
      
      public static var §\x06\x06\x07\x02\b\x06\x04\x01\b\x06\x01\x06\x02§:String = "oot";
      
      public static var §\x01\x03\x02\b\x06\x06\x07\x04\x02\x05\b§:String = "x_";
      
      public static var §\x02\x03\x03\x06\x05\x01\x06\x06\x07\x04\x03\b\x06§:String = "$Entrainement";
      
      public static var §\x07\x01\x01\x04\x06\x02\b\x07\b\x02\x07§:int = 9640 + -9574;
      
      public static var §\x07\x02\x05\x02\x05\x07\x03\x07\x06\x03\x01\x02\x02§:String = "_Transformice";
      
      public static var §\x01\x05\x06\x01\x07\x06\x02\x03\b\x02\b\x03§:String = "getQualifiedDefinitionNames";
      
      public static var §\x02\x04\x02\x03\b\x07\x04\x07\x06\x07\x04\x04\x07§:String = "kikou";
      
      public static var §\b\b\x01\x06\x04\x05\x05\x03\x05\x06\x05\x05§:int = 5102 + -5087;
      
      public static var §\x07\x04\x05\x06\x02\x06\x07\x04\x02\x06\x04\b\b§:String = "en";
      
      public function §\x04\x01\x03\x03\x05\x04\x03\x03\x07\x04\x06§()
      {
         super();
      }
      
      public static function §\x06\x06\x01\x06\x04\x02\x05\x07\x05\x03\x01\x01\x07§() : int
      {
         return 3607 + -2748;
      }
      
      public static function §\x06\x02\x07\x01\x05\x07\x03\x01\b\x02\x05\x07\x03§() : Number
      {
         return (7550 + -7393) / (5200 + -5100);
      }
      
      public static function §\b\x02\x06\x07\b\x06\x01\x05\x05\x03\x06\x04\x01§() : Number
      {
         return (5459 + -5454) / (1266 + -1166);
      }
      
      public static function §\x04\x01\x05\x03\b\x03\x03\x04\x07\x05\x05\x01§() : int
      {
         return 3158 + 842;
      }
      
      public static function §\x04\x07\x04\b\x04\x02\b\x06\x04\x07\x03\x07\x03§() : int
      {
         return 2838 + -2804;
      }
      
      public static function §\x01\x02\b\x06\b\x04\x04\x05\b\x02\x07§() : int
      {
         return 8674 + -8476;
      }
      
      public static function §\b\x04\x01\b\x05\x01\x06\x06\x04\x05\x04\x07§() : int
      {
         return 641 + -441;
      }
      
      public static function §\x04\x03\x04\x01\x04\x02\x02\x01\x03\x04\x05\x02\x04§() : int
      {
         return 4121 + -4047;
      }
      
      public static function §\x03\b\x07\x07\x07\b\b\x03\x06\x02\x01\x01§() : int
      {
         return 9338 + -9167;
      }
      
      public static function §\x04\b\x05\b\x04\x07\x02\b\b\x07\x01\b\x01§() : int
      {
         return 5463 + -5305;
      }
      
      public static function §\x05\x02\x04\x05\x01\x02\x06\x06\x03\x03\b\x07§() : int
      {
         return 5701 + -5538;
      }
      
      public static function §\x01\x05\x07\x02\x02\x02\x03\x07\x03\b\x06\x01\x03§() : int
      {
         return 1846 + -1665;
      }
      
      public static function §\x04\x07\x01\x04\x02\x02\x05\x06\x05\x06\b\x05\x06§() : int
      {
         return 2584 + -2483;
      }
      
      public static function §\x04\x01\x06\x03\x07\x03\b\x01\x05\x03\b\x04§() : int
      {
         return 6222 + -6100;
      }
      
      public static function §\x01\x07\x01\x02\x02\x01\x02\x05\x04\x01\x02\x07§() : int
      {
         return 7438 + -7251;
      }
      
      public static function §\x06\x07\x02\x04\x03\x01\x07\x06\x02\x03\x04§() : int
      {
         return 7485 + -7346;
      }
      
      public static function §\x05\x02\x04\x06\x02\x06\b\x06\x04\x03\x06\x03\x06§() : int
      {
         return 5930 + -5919;
      }
      
      public static function §\b\b\b\x02\x05\x04\x05\x07\x03\b\x02§() : int
      {
         return 5125 + -5108;
      }
   }
}

